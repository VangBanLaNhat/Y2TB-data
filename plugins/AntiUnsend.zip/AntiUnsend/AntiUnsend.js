
function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function start(data, api, adv){
    var lang = global.lang.AntiUnsend;
    var l = global.config.bot_info.lang;
    try{
        var grinfo = await adv.getThreadInfo(data.threadID);
        var listadgr = normalizeAdminIDs(grinfo.adminIDs);
    } catch (err) {
        var listadgr = []
        console.error("AntiUnsend", err)
    }
    var rt = lang.noad[l];
    if (listadgr.indexOf(data.senderID) != -1) {
        if (global.data.antiunsend[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
            global.data.antiunsend[data.threadID] = false;
            rt = lang.off[l].replace("{0}", "Admin group")
        } else {
            global.data.antiunsend[data.threadID] = true;

            rt = lang.on[l].replace("{0}", "Admin group")
        }
    } else if (global.config.facebook.admin.indexOf(data.senderID) != -1) {
        if (global.data.antiunsend[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
            global.data.antiunsend[data.threadID] = false;
            rt = lang.off[l].replace("{0}", "Admin BotChat")
        } else {
            global.data.antiunsend[data.threadID] = true;

            rt = lang.on[l].replace("{0}", "Admin BotChat")
        }
    }
    api.sendMessage(rt , data.threadID, data.messageID);
}

function uns(data, api, adv){
    !global.aus ? global.aus = {}:"";
    !global.data.antiunsend ? global.data.antiunsend = {}:"";
    global.data.antiunsend[data.threadID] == undefined ? global.data.antiunsend[data.threadID] = true:"";
    switch (data.type) {
        case 'message_reply':
        case 'message':
            if(data.senderID != undefined && data.senderID != api.getCurrentUserID()) read(data, api)
            break;
        case "message_unsend":
            
            if(global.data.antiunsend[data.threadID] && global.aus[data.messageID] != undefined) send(data, api, adv);
            break
    }
}

function read(data){
    var atmurl = [];
    if (data.attachments.length > 0){
        for (var i=0; i<data.attachments.length; i++){
            atmurl.push(data.attachments[i].url);
        };
    }
    global.aus[data.messageID] = {
        body: data.body,
        attachments: atmurl
    }

}

async function send(data, api, adv){
    var shot = require('tinyurl');
    
    var lang = global.lang.AntiUnsend.send[global.config.bot_info.lang];
    var msgid = data.messageID;
    var dt = JSON.parse(JSON.stringify(global.aus[msgid]));
    delete global.aus[data.messageID];
    var uinfo = await adv.getUserInfo(data.senderID);
    var nameuser = uinfo.name;
    lang = lang.replace("{0}", nameuser);
    if (dt.body != "") {
        if (global.config.bot_info.lang == "vi_VN") lang = lang.replace("{1}", `-Nội dung: ${dt.body}\n`)
        else lang = lang.replace("{1}", `-Content: ${dt.body}\n`)
    } else {lang = lang.replace("{1}", ``)}
    if (dt.attachments.length >0){
        var list = "";
        for (var i=0; i<dt.attachments.length; i++){
            var sl = await shot.shorten(dt.attachments[i]);
            list += `${i+1}. ${sl}\n`
        };
        if (global.config.bot_info.lang == "vi_VN") lang = lang.replace("{2}", `-Tệp:\n${list}`)
        else lang = lang.replace("{2}", `-File:\n${list}`)
    } else {lang = lang.replace("{2}", ``)};
    
    api.sendMessage(lang , data.threadID);
}

module.exports = {
    start,
    uns,
}
