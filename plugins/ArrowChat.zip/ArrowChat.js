const fs = require('fs');
const path = require('path');
const axios = require('axios');

const HIDE_PREFIX = "\u200d\u200d\u200d\u200d\u200d\u200d\u200d\u200d\u200d\u200d";
const CACHE_DIR = path.join(__dirname, 'cache');

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

function ensureExists(dirPath, mask) {
    if (typeof mask !== 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(dirPath, {
            mode: mask,
            recursive: true
        });
    } catch (ex) {
        return {
            err: ex
        };
    }
}

function ensureArrowData() {
    if (!global.data.arrowchat || typeof global.data.arrowchat !== 'object') {
        global.data.arrowchat = {};
    }
}

function ensureThreadStore(threadID) {
    ensureArrowData();
    if (!global.data.arrowchat[threadID] || typeof global.data.arrowchat[threadID] !== 'object') {
        global.data.arrowchat[threadID] = {};
    }
    return global.data.arrowchat[threadID];
}

function normalizeAnswerList(value) {
    if (Array.isArray(value)) return value;
    if (value === undefined || value === null) return [];
    return [value];
}

function isAttachmentEntry(entry) {
    return !!(entry && typeof entry === 'object' && entry.type === 'attachment' && entry.path);
}

function resolveStoredPath(storedPath) {
    if (!storedPath || typeof storedPath !== 'string') return '';
    if (path.isAbsolute(storedPath)) return storedPath;
    return path.join(__dirname, storedPath);
}

function getAttachmentExt(attachment) {
    const map = {
        photo: '.jpg',
        animated_image: '.gif',
        video: '.mp4',
        audio: '.mp3',
        file: '.bin'
    };

    let ext = map[attachment.type] || '.bin';
    if (attachment.filename && typeof attachment.filename === 'string') {
        const nameExt = path.extname(attachment.filename);
        if (nameExt && nameExt.length <= 10) {
            ext = nameExt;
        }
    }
    return ext;
}

function isSupportedAttachment(attachment) {
    if (!attachment || typeof attachment !== 'object') return false;
    if (!attachment.url) return false;
    const allow = ['photo', 'animated_image', 'video', 'audio', 'file'];
    return allow.indexOf(attachment.type) !== -1;
}

function getReplyAttachments(data) {
    if (!data || data.type !== 'message_reply' || !data.messageReply) return [];
    if (!Array.isArray(data.messageReply.attachments)) return [];
    return data.messageReply.attachments;
}

function cleanupAnswerAttachments(answerList) {
    const list = normalizeAnswerList(answerList);
    for (const entry of list) {
        if (!isAttachmentEntry(entry)) continue;
        const attachmentPath = resolveStoredPath(entry.path);
        try {
            if (attachmentPath && fs.existsSync(attachmentPath)) {
                fs.unlinkSync(attachmentPath);
            }
        } catch (_) { }
    }
}

function cleanupThreadAttachments(threadID) {
    const threadStore = global.data.arrowchat && global.data.arrowchat[threadID];
    if (!threadStore || typeof threadStore !== 'object') return;

    for (const key in threadStore) {
        cleanupAnswerAttachments(threadStore[key]);
    }
}

function buildAttachmentLabel(entry) {
    const typeMap = {
        photo: 'photo',
        animated_image: 'gif',
        video: 'video',
        audio: 'audio',
        file: 'file'
    };
    const type = typeMap[entry.attachmentType] || 'file';
    const filename = entry.filename || path.basename(entry.path || '') || 'unknown';
    return `[${type}: ${filename}]`;
}

async function downloadAttachment(url, destination) {
    const response = await axios({
        method: 'get',
        url,
        responseType: 'stream',
        timeout: 120000
    });

    await new Promise((resolve, reject) => {
        const writer = fs.createWriteStream(destination);
        response.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
        response.data.on('error', reject);
    });
}

function replaceAll(string, arg, repl) {
    let out = String(string || '');
    while (out.indexOf(arg) !== -1) {
        out = out.replace(arg, repl);
    }
    return out;
}

function random(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

async function add(data, api, e2ee, adv) {
    const lang = global.lang.ArrowChat;
    const l = global.config.bot_info.lang;

    const msg = (data.body || '').trim();
    const threadStore = ensureThreadStore(data.threadID);

    if (msg.indexOf('=>') !== -1) {
        const splitMsg = msg.split('=>');
        const ask = (splitMsg.shift() || '').trim().toLowerCase();
        const ansText = splitMsg.join('=>').trim();

        if (!ask || !ansText) {
            return adv.reply(replaceAll(lang.addf[l], '{0}', global.config.facebook.prefix));
        }

        const answerList = ansText
            .split('|')
            .map((item) => item.trim())
            .filter(Boolean);

        if (!answerList.length) {
            return adv.reply(replaceAll(lang.addf[l], '{0}', global.config.facebook.prefix));
        }

        threadStore[ask] = normalizeAnswerList(threadStore[ask]);
        for (const answer of answerList) {
            threadStore[ask].push(answer);
        }

        return adv.reply(lang.addt[l]
                .replace('{0}', ask)
                .replace('{1}', JSON.stringify(threadStore[ask])));
    }

    const ask = msg.toLowerCase();
    if (!ask) {
        return adv.reply(replaceAll(lang.addf[l], '{0}', global.config.facebook.prefix));
    }

    const replyAttachments = getReplyAttachments(data);
    if (!replyAttachments.length) {
        const replyMsg = lang.replyf && lang.replyf[l]
            ? replaceAll(lang.replyf[l], '{0}', global.config.facebook.prefix)
            : replaceAll(lang.addf[l], '{0}', global.config.facebook.prefix);
        return adv.reply(replyMsg);
    }

    const supportAttachments = replyAttachments.filter(isSupportedAttachment);
    if (!supportAttachments.length) {
        return adv.reply(lang.atf && lang.atf[l] ? lang.atf[l] : replaceAll(lang.addf[l], '{0}', global.config.facebook.prefix));
    }

    threadStore[ask] = normalizeAnswerList(threadStore[ask]);
    const threadCache = path.join(CACHE_DIR, String(data.threadID));
    ensureExists(threadCache);

    let successCount = 0;
    for (let i = 0; i < supportAttachments.length; i++) {
        const attachment = supportAttachments[i];
        const ext = getAttachmentExt(attachment);
        const fileName = `${Date.now()}_${i}_${Math.random().toString(36).slice(2, 8)}${ext}`;
        const savePath = path.join(threadCache, fileName);

        try {
            await downloadAttachment(attachment.url, savePath);
            threadStore[ask].push({
                type: 'attachment',
                path: path.relative(__dirname, savePath).replace(/\\/g, '/'),
                attachmentType: attachment.type || 'file',
                filename: attachment.filename || fileName
            });
            successCount += 1;
        } catch (err) {
            console.error('ArrowChat save attachment', err);
            try {
                if (fs.existsSync(savePath)) fs.unlinkSync(savePath);
            } catch (_) { }
        }
    }

    if (!successCount) {
        return adv.reply(lang.atsf && lang.atsf[l] ? lang.atsf[l] : lang.delf[l]);
    }

    const addAttachmentMsg = lang.adda && lang.adda[l]
        ? lang.adda[l].replace('{0}', ask).replace('{1}', String(successCount))
        : lang.addt[l].replace('{0}', ask).replace('{1}', `${successCount} attachment`);
    return adv.reply(addAttachmentMsg);
}

function list(data, api, e2ee, adv) {
    const lang = global.lang.ArrowChat;
    const l = global.config.bot_info.lang;

    if (!global.data.arrowchat || !global.data.arrowchat[data.threadID]) {
        return adv.reply(lang.ndt[l]);
    }

    let out = '';
    let num = 0;
    const threadStore = global.data.arrowchat[data.threadID];

    for (const keyword in threadStore) {
        const answerList = normalizeAnswerList(threadStore[keyword]);
        if (!answerList.length) continue;

        const display = answerList
            .map((entry) => {
                if (typeof entry === 'string') return entry;
                if (isAttachmentEntry(entry)) return buildAttachmentLabel(entry);
                return '';
            })
            .filter(Boolean)
            .join(', ');

        if (!display) continue;
        num += 1;
        out += `${num}. ${keyword}: ${display}\n`;
    }

    if (!out.trim()) {
        return adv.reply(lang.ndt[l]);
    }

    return adv.reply(lang.list[l].replace('{0}', out.trim()));
}

function del(data, api, e2ee, adv) {
    const lang = global.lang.ArrowChat;
    const l = global.config.bot_info.lang;

    if (!global.data.arrowchat || !global.data.arrowchat[data.threadID]) {
        return adv.reply(lang.ndt[l]);
    }

    const msg = (data.body || '').trim().toLowerCase();
    if (!msg) {
        return adv.reply(lang.nmsg[l]);
    }

    if (!global.data.arrowchat[data.threadID][msg]) {
        return adv.reply(lang.delf[l]);
    }

    cleanupAnswerAttachments(global.data.arrowchat[data.threadID][msg]);
    delete global.data.arrowchat[data.threadID][msg];

    if (Object.keys(global.data.arrowchat[data.threadID]).length === 0) {
        delete global.data.arrowchat[data.threadID];
    }

    return adv.reply(lang.delt[l].replace('{0}', msg));
}

async function delall(data, api, e2ee, adv) {
    const lang = global.lang.ArrowChat;
    const l = global.config.bot_info.lang;

    if (!global.data.arrowchat || !global.data.arrowchat[data.threadID]) {
        return adv.reply(lang.ndt[l]);
    }

    let listadgr = [];
    try {
        const grinfo = await api.getThreadInfo(data.threadID);
        listadgr = normalizeAdminIDs(grinfo.adminIDs);
    } catch (err) {
        console.error('ArrowChat', err);
    }

    if (listadgr.indexOf(String(data.senderID)) !== -1) {
        cleanupThreadAttachments(data.threadID);
        delete global.data.arrowchat[data.threadID];
        return adv.reply(lang.delall[l].replace('{0}', 'Admin group'));
    }

    if (Array.isArray(global.config.facebook.admin) && global.config.facebook.admin.indexOf(String(data.senderID)) !== -1) {
        cleanupThreadAttachments(data.threadID);
        delete global.data.arrowchat[data.threadID];
        return adv.reply(lang.delall[l].replace('{0}', 'Admin BotChat'));
    }

    return adv.reply(lang.noad[l]);
}

function chathook(data, api, e2ee, adv) {
    if (!data || data.senderID === global.botid) return;
    if (data.type !== 'message' && data.type !== 'message_reply') return;
    if (!data.body || typeof data.body !== 'string') return;
    if (data.body.indexOf(global.config.facebook.prefix) === 0) return;
    if (!global.data.arrowchat || !global.data.arrowchat[data.threadID]) return;

    const key = data.body.toLowerCase();
    const answerList = normalizeAnswerList(global.data.arrowchat[data.threadID][key]);
    if (!answerList.length) return;

    const selected = answerList[random(0, answerList.length)];

    if (typeof selected === 'string') {
        return adv.reply(HIDE_PREFIX + selected);
    }

    if (!isAttachmentEntry(selected)) return;
    const attachmentPath = resolveStoredPath(selected.path);
    if (!attachmentPath || !fs.existsSync(attachmentPath)) {
        const fallback = answerList.find((item) => typeof item === 'string' && item.trim());
        if (fallback) {
            return adv.reply(HIDE_PREFIX + fallback);
        }
        return;
    }

    return adv.reply({
        attachment: fs.createReadStream(attachmentPath)
    }, (err) => {
        if (!err) return;
        const fallback = answerList.find((item) => typeof item === 'string' && item.trim());
        if (fallback) {
            adv.reply(HIDE_PREFIX + fallback);
        }
    });
}

module.exports = {
    add,
    list,
    del,
    delall,
    chathook
};
