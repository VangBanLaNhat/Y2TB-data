
function getThreadListAsync(api, limit, timestamp, tags) {
    return new Promise((resolve, reject) => {
        api.getThreadList(limit, timestamp, tags, (err, list) => {
            if (err) return reject(err);
            resolve(Array.isArray(list) ? list : []);
        });
    });
}

async function fetchPendingThreads(api) {
    const pending = await getThreadListAsync(api, 100, null, ["PENDING"]);
    const other = await getThreadListAsync(api, 100, null, ["OTHER"]);
    return other.concat(pending);
}

function pending(data, api, adv){
	const {pluginName, rlang} = adv;
	//if(data.isGroup) return api.sendMessage(rlang("inbox"), data.threadID, data.messageID);
	if(global.config.facebook.admin.indexOf(data.senderID) == -1) return api.sendMessage(rlang("noPer"), data.threadID, data.messageID);
    !global.temp.threadPending ? global.temp.threadPending = {}:"";
    if(global.temp.threadPending.MID) {
        api.unsendMessage(global.temp.threadPending.MID);
        global.temp.threadPending = {};
    }
	
    fetchPendingThreads(api)
        .then((list) => {
            global.temp.threadPending = {
                UID: data.senderID,
                list
            };
            send(data, api, adv);
        })
        .catch((error) => {
            console.error(pluginName, error);
            api.sendMessage(String(error), data.threadID, data.messageID);
        });
}

function send(data, api, adv){
	let {rlang, replaceMap} = adv;
    let listStr = "";
    for(let i in global.temp.threadPending.list){
        console.log(global.temp.threadPending.list[i]);
        listStr += "\n"+(Number(i)+1)+". "+global.temp.threadPending.list[i].name
    }
    
    let map = {
        "{list}": listStr
    };
	
	api.sendMessage(replaceMap(rlang("listPending"), map), data.threadID, (e, a)=>{
        if(e) return console.error("Connection", e);
        global.temp.threadPending.MID = a.messageID;
    }, data.messageID);
}

function chathook(data, api, adv){
    if(data.type != "message_reply" || !global.temp.threadPending || !global.temp.threadPending.MID) return;
    if(data.messageReply.messageID != global.temp.threadPending.MID) return;

    const {rlang} = adv;
    let msg = (data.body.split(" ")); msg[0] = msg[0].toLowerCase();
    console.log(msg[0]);
    let rt = rlang("connect").replaceAll("{0}", global.config.bot_info.botname) + rlang("help").replaceAll("{0}", global.config.facebook.prefix);
    let done = [];
    let out = [];

    if(msg[0] == "all"){
        for(let i of global.temp.threadPending.list){
            api.sendMessage(rt, i.threadID, (e)=>{
                if(e){
                    api.deleteThread(i.threadID).catch(error => {
                        console.error(error.message);
                    });
                    console.error("Connected", `Can't connected to ${i.threadID} with error: ${e}`)
                } else {
                    console.log("Connected", `Connected to ${i.threadID} success!`);
                }
            }).catch(error => {
                console.error(error.message);
            });
            
            done.push(i.name);
        }
    } else {
        for(let i in msg) msg[i] = Number(msg[i]);
        
        for(let j in global.temp.threadPending.list){
            let i = global.temp.threadPending.list[j];
            
            if(msg.indexOf(Number(j)+1) != -1){
                api.sendMessage(rt, i.threadID, (e)=>{
                    if(e){
                        api.deleteThread(i.threadID).catch(error => {
                            console.error(error.message);
                        });
                        console.error("Connected", `Can't connected to ${i.threadID} with error: ${e}`)
                    } else {
                        console.log("Connected", `Connected to ${i.threadID} success!`);
                    }
                }).catch(error => {
                    console.error(error.message);
                });

                done.push(i.name);
            } else {
                    api.removeUserFromGroup(global.botid, i.threadID).catch(error => {
                        console.error(error.message);
                    });
                    api.deleteThread(i.threadID).catch(error => {
                        console.error(error.message);
                    });;
                out.push(i.name);
            }
        }
    }

    let res = "";

    if(done.length > 0){
        let list = "";
        for(let i in done) list += "\n" + (Number(i)+1) + ". " + done[i];
        res += rlang("listDone").replaceAll("{list}", list) + "\n\n";
    }

    if(out.length > 0){
        let list = "";
        for(let i in out) list += "\n" + (Number(i)+1) + ". " + out[i];
        res += rlang("listOut").replaceAll("{list}", list);
    }

    api.sendMessage(res, data.threadID, ()=>{
        if(global.temp.threadPending.MID) {
            api.unsendMessage(global.temp.threadPending.MID);
            global.temp.threadPending = {};
        }
    }, data.messageID);
}

function connect(api, adv){
    if(adv.config.auto_connect){
        setInterval(function () {
            var lang = global.lang.Connected;
            var la = global.config.bot_info.lang;
            try{
            fetchPendingThreads(api).then((l) => {
                for(let thread of l){
                    var rt = lang.connect[la].replace("{0}", global.config.bot_info.botname) + lang.help[la].replace("{0}", global.config.facebook.prefix);

                    api.sendMessage(rt , thread.threadID, (e)=>{
                        if(e){
                            api.deleteThread(thread.threadID);
                            console.error("Connected", `Can't connected to ${thread.threadID} with error: ${e}`)
                        }else console.log("Connected", `Connected to ${thread.threadID} success!`)
                    }).catch(error => {
                        console.error(error.message);
                    });
                }
            }).catch((error) => {
                console.error("Connected", error);
            });
            }catch(e){}
        }, adv.config.time_auto_connect*60*1000);
    }
}

module.exports = {
	pending,
    chathook,
    connect,
}
