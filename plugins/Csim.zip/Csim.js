async function csim(data, api, e2ee, adv){
    const fetch = require("node-fetch");
    const path = require("path");
    !global.data.csim?global.data.csim = {}:"";
    !global.data.csim[data.threadID]?global.data.csim[data.threadID] = false:"";
    
    var msg = data.body
    if(msg == "on"){
        global.data.csim[data.threadID] = true;
        adv.reply(global.lang.Csim.simOn[global.config.bot_info.lang]);
    }
    else if(msg == "off"){
        global.data.csim[data.threadID] = false;
        adv.reply(global.lang.Csim.simOff[global.config.bot_info.lang]);
    }
    else{
        let lang = global.config.bot_info.lang.split("_")[1].toLowerCase() == "vn" ? "vn" : global.config.bot_info.lang.split("_")[0];
        var datajs = await fetch("https://api.simsimi.vn/v2/simtalk", {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            method: "POST",
            body: `text=${msg}&lc=${lang}&key=${adv.config.api_key_premium}`
        })
        var json = await datajs.json();

        var s = json.message != "Tôi không biết làm thế nào để trả lời. Dạy tôi câu trả lời." ? json.message : msg;
        s = s != "I do not know how to answer. Teach me the answer." ? s : msg;
        s = s != "Required parameter is not present" ? s : msg;
        s = s != "Tôi không biết làm thế nào để trả lời. Dạy tôi câu trả lời" ? s : "Lói cái dell gì thế ?";
        
        var rt = global.lang.Csim.simReturn[global.config.bot_info.lang].replace("{0}", s);
        if (s != undefined) {
            adv.reply(rt);
	    }
    }
}

async function chathook(data, api, e2ee, adv){
    !global.data.csim?global.data.csim = {}:"";
    if(data.type == "message" && global.data.csim[data.threadID] && data.body != `${global.config.facebook.prefix}csim off` && data.body.indexOf(global.config.facebook.prefix) != 0){
        const fetch = require("node-fetch");
        
        let lang = global.config.bot_info.lang.split("_")[1].toLowerCase() == "vn" ? "vn" : global.config.bot_info.lang.split("_")[0];
        var msg = data.body
        var datajs = await fetch("https://api.simsimi.vn/v2/simtalk", {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            method: "POST",
            body: `text=${msg}&lc=${lang}&key=${adv.config.api_key_premium}`
        })
        var json = await datajs.json();

        var s = json.message != "Tôi không biết làm thế nào để trả lời. Dạy tôi câu trả lời." ? json.message : msg;
        s = s != "I do not know how to answer. Teach me the answer." ? s : msg;
        s = s != "Required parameter is not present" ? s : msg;
        s = s != "Tôi không biết làm thế nào để trả lời. Dạy tôi câu trả lời" ? s : "Lói cái dell gì thế ?";

        var rt = global.lang.Csim.simReturn[global.config.bot_info.lang].replace("{0}", s);
        if (s != undefined) {
            adv.reply(rt);
	    }
    }
}

module.exports = {
    csim,
    chathook,
};
