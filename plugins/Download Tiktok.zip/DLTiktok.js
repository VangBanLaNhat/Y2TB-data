
async function main(data, api, e2ee, adv) {
    const Tiktok = require("@tobyg74/tiktok-api-dl")
    const { rlang, replaceMap } = adv;

    try {
        const axios = require('axios');
        const fs = require('fs-extra');
        const path = require('path');
        const link = data.args[1];

        let lang = global.lang["Download Tiktok"];
        let code = global.config.bot_info.lang;

        if (!link) return adv.reply(lang.nolink[code]);
        var res = await Tiktok.Downloader(link, {
            version: "v1",
            showOriginalResponse: true
        });

        if (res.status == "error") return adv.reply(lang.nolink[code]);

        if (res.resultNotParsed.music.playUrl[0] == res.resultNotParsed.content.video.play_addr.uri) {
            imageType(data, api, e2ee, adv, link);
            return;
        }
        await videoType(data, api, e2ee, adv, res);
    } catch (err) {
        console.error(err);
        adv.reply(err)
    };
};

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function auto(data, api, e2ee, adv) {
    let {
        rlang,
        config,
        getThreadInfo
    } = adv;

    //if (global.config.facebook.admin.indexOf(data.senderID) == -1) return adv.reply(rlang("noPermision"));

    if (global.config.facebook.admin.indexOf(data.senderID) == -1) {
        let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs);
        let check = adminL.indexOf(String(data.senderID)) != -1;
        if (!check) return adv.reply(rlang("noPermision"));
    }

    if (global.data.autodown[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
        global.data.autodown[data.threadID] = false; adv.reply(rlang("turnOff"))
    } else {
        global.data.autodown[data.threadID] = true; adv.reply(rlang("turnOn"))
    }
}

async function bruh(data, api, e2ee, adv) {
    if (data.type != "message") return;

    let {
        rlang,
        config,
        replaceMap
    } = adv;

    !global.data.autodown ? global.data.autodown = {} : '';
    global.data.autodown[data.threadID] == undefined ? global.data.autodown[data.threadID] = config.autodown : '';

    if (!global.data.autodown[data.threadID]) return;
    if (data.body.indexOf(global.config.facebook.prefix) == 0) return;
    const Tiktok = require("@tobyg74/tiktok-api-dl")
    regEx_tiktok = /(^https:\/\/)((vm|vt|www|v)\.)?(tiktok|douyin)\.com\//

    for (let cc of data.args) {
        let brah = new RegExp(regEx_tiktok).test(cc);
        if (brah == true && rlang("urlTruee") != '') adv.reply(replaceMap(rlang("urlTruee"), {
            "{link}": cc
        }));
    }
    for (let cc of data.args) {

        let brah = new RegExp(regEx_tiktok).test(cc);
        if (brah == true) {
            let res;
            try {
                res = await Tiktok.Downloader(cc, {
                    version: "v1",
                    showOriginalResponse: true
                });
            } catch (e) {
                return console.warn("Auto Download", e);
            }

            if (!res.resultNotParsed) continue;

            // if (res.data.type == "image") {
            //     await imageType(data, api, e2ee, adv, res);
            //     continue;
            // }
            if (res.resultNotParsed.music.playUrl[0] == res.resultNotParsed.content.video.play_addr.uri) {
                imageType(data, api, e2ee, adv, cc);
                continue;
            }

            await videoType(data, api, e2ee, adv, res);
        }
    }

}

async function imageType(data, api, e2ee, adv, link) {
    const Tiktok = require("@tobyg74/tiktok-api-dl")
    const path = require("path");
    const streamBuffers = require("stream-buffers");
    const axios = require('axios');
    const fetch = require("node-fetch");
    const fs = require("fs");

    let vers = "v1";
    let res = await Tiktok.Downloader(link, {
        version: vers,
        showOriginalResponse: true
    });
    // console.log(res.resultNotParsed.content.image_post_info.images[1].display_image.url_list)
    // console.log("1")
    // if (res.status == "error") {
    //     vers = "v2";
    //     res = await TiktokDownloader.Downloader(link, {
    //                 version: vers
    //             });
    //     console.log(vers, res);
    // }

    // if (res.status == "error" || res.result.images[0] == undefined) {
    //     vers = "v3";
    //     res = await TiktokDownloader.Downloader(link, {
    //                 version: vers
    //             });
    //     console.log(vers, res);
    // }

    let {
        rlang,
        config,
        replaceMap
    } = adv;
    if (!res.resultNotParsed.statistics) res.resultNotParsed.statistics = {};
    var nameidea = res.resultNotParsed.content.desc;
    var name = res.resultNotParsed.author.nickname;
    var username = res.resultNotParsed.author.username;
    var views = res.resultNotParsed.statistics.playCount;
    var loves = res.resultNotParsed.statistics.diggCount;
    var comments = res.resultNotParsed.statistics.commentCount;
    var shares = res.resultNotParsed.statistics.shareCount;
    var favorite = res.resultNotParsed.statistics.collectCount;
    var downloadC = res.resultNotParsed.statistics.downloadCount;

    let map = {
        "{nameidea}": nameidea,
        "{name}": name,
        "{username}": username,
        "{views}": views,
        "{loves}": loves,
        "{comments}": comments,
        "{shares}": shares,
        "{downloadC}": downloadC,
        "{favorite}": favorite
    }
    let img = [],
        listFile = [];

    for (let i in res.resultNotParsed.content.image_post_info.images) {
        let x = res.resultNotParsed.content.image_post_info.images[i].display_image.url_list[0];
        let fetchimage = await fetch(x);
        let buffer = await fetchimage.buffer();
        let imagesx = new streamBuffers.ReadableStreamBuffer({
            frequency: 10,
            chunkSize: 1024
        });
        imagesx.path = path.join(__dirname, "cache", "tiktok", data.messageID + encodeURI(x) + ".jpg");
        img.push(path.join(__dirname, "cache", "tiktok", data.messageID + encodeURI(x) + ".jpg"));
        imagesx.put(buffer);
        imagesx.stop();

        listFile.push(imagesx);
    }
    const response = await axios({
        method: 'get',
        url: res.resultNotParsed.music.playUrl[0],
        responseType: 'stream'
    });

    let time = Date.parse(new Date());
    let dir = path.join(__dirname, "cache", "tiktok", data.messageID + time + ".mp3")
    ensureExists(path.join(__dirname, "cache", "tiktok"))

    let stream = response.data.pipe(fs.createWriteStream(dir));

    stream.on("finish", () => {
        adv.reply({
            body: replaceMap(rlang("Done"), map),
            attachment: listFile
        }, (e, a) => {
            for (let i of img) {
                try {
                    fs.unlinkSync(i);
                } catch (_) { };
            }
            adv.reply(({
                attachment: fs.createReadStream(dir)
            }), () => fs.unlinkSync(dir));
        });

    });
}

async function videoType(data, api, e2ee, adv, res) {
    const fs = require('fs-extra');
    const path = require('path');
    const axios = require('axios');
    let {
        rlang,
        config,
        replaceMap
    } = adv;
    var nameidea = res.resultNotParsed.content.desc;
    var name = res.resultNotParsed.author.nickname;
    var username = res.resultNotParsed.author.username;
    var views = res.resultNotParsed.statistics.playCount;
    var loves = res.resultNotParsed.statistics.diggCount;
    var comments = res.resultNotParsed.statistics.commentCount;
    var shares = res.resultNotParsed.statistics.shareCount;
    var favorite = res.resultNotParsed.statistics.collectCount;
    var downloadC = res.resultNotParsed.statistics.downloadCount;

    const response = await axios({
        method: 'get',
        url: res.resultNotParsed.content.video.play_addr.url_list[0],
        responseType: 'stream'
    });
    let time = Date.parse(new Date());
    //if(res.data.video == res.data.audio) {adv.reply("Ảnh cái cc bố ko hỗ trợ ok!"); return;}
    let dir = path.join(__dirname,
        "cache",
        "tiktok",
        time + ".mp4")
    ensureExists(path.join(__dirname,
        "cache",
        "tiktok"))

    let stream = response.data.pipe(fs.createWriteStream(dir));
    let map = {
        "{nameidea}": nameidea,
        "{name}": name,
        "{username}": username,
        "{views}": views,
        "{loves}": loves,
        "{comments}": comments,
        "{shares}": shares,
        "{downloadC}": downloadC,
        "{favorite}": favorite
    }
    stream.on("finish",
        () => {
            adv.reply(({
                body: replaceMap(rlang("Done"), map),
                attachment: fs.createReadStream(dir)
            }), () => fs.unlinkSync(dir));
        });
}

function ensureExists(path, mask) {
    var fs = require('fs');
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(path, {
            mode: mask,
            recursive: true
        });
        return;
    } catch (ex) {
        return {
            err: ex
        };
    }
}

module.exports = {
    main,
    auto,
    bruh,
}
