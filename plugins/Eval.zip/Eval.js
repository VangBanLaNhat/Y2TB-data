function temp(){}

function outeval(data, api, e2ee, adv){
    if(data.type == "message" || data.type == "message_reply" || data.type == "e2ee_message"){
        if(!data || !data.body) return;
        if(!Array.isArray(data.args)) {
            data.args = String(data.body).split(" ");
        }
        if(!data.args.length) return;
        if(data.args[0].indexOf(`${global.config.facebook.prefix}eval`) == 0){
            data.body = String(data.body).replace(`${global.config.facebook.prefix}eval`, "");
            var check = false;
            for (var i=0; i<global.config.facebook.admin.length; i++){
                if (global.config.facebook.admin[i]==data.senderID.replace("@msgr", "")) {
                    check = true;
                }
            }
            if (check) {
                try{
                    var rt = eval(data.body);
                    console.log(data.threadID);
                    if(typeof rt == "object"){
                        adv.send(JSON.stringify(rt, null, 4));
                    } else {
                        adv.send(rt+"");
                    }
                    console.log(rt)
                }catch(err){
                    console.log(err)
                    adv.send(err.toString());
                }
            }else{
                adv.send("No permission!");
            }
        }
    }
}


module.exports = {
    outeval,
    temp,
};
