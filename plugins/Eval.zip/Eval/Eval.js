function temp(){}

function outeval(data, api, adv){
    if(data.type == "message" || data.type == "message_reply" || data.type == "e2ee_message"){
        if(data.args[0].indexOf(`${global.config.facebook.prefix}eval`) == 0){
            data.body = data.body.replace(`${global.config.facebook.prefix}eval`, "");
            var check = false;
            for (var i=0; i<global.config.facebook.admin.length; i++){
                if (global.config.facebook.admin[i]==data.senderID.replace("@msgr", "")) {
                    check = true;
                }
            }
            if (check) {
                try{
                    var rt = eval(data.body);
                    console.log(data.threadID);
                    if(typeof rt == "object"){
                        api.sendMessage(JSON.stringify(rt, null, 4), data.threadID);
                    } else {
                        api.sendMessage(rt+"", data.threadID);
                    }
                    console.log(rt)
                }catch(err){
                    console.log(err)
                    api.sendMessage(err.toString() , data.threadID);
                }
            }else{
                api.sendMessage("No permission!" , data.threadID);
            }
        }
    }
}


module.exports = {
    outeval,
    temp,
};
