
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { alldown, ndown, fbdown2 } = require("@neelegirly/downloader");

async function main(data, api, e2ee, adv, link) {
    const target = link ? link : data.args[1];
    if (!target) return adv.reply(adv.rlang("nolink"));

    try {
        const info = await resolveFacebookMedia(target, adv && adv.config ? adv.config : {});
        const videoUrl = extractFacebookVideoUrl(info);

        if (!videoUrl) {
            if (link) return;
            return adv.reply(extractErrorMessage(info) || adv.rlang("nolink"));
        }

        const response = await axios({
            method: "get",
            url: videoUrl,
            responseType: "stream"
        });

        const time = Date.now();
        const dir = path.join(__dirname, "cache", "fbdl", `${data.messageID}${time}.mp4`);
        ensureExists(path.join(__dirname, "cache", "fbdl"));

        const stream = response.data.pipe(fs.createWriteStream(dir));
        const map = {
            "{title}": extractFacebookTitle(info)
        };

        stream.on("finish", () => {
            adv.reply({
                body: adv.replaceMap(adv.rlang("Done"), map),
                attachment: fs.createReadStream(dir)
            }, () => fs.unlinkSync(dir));
        });
    } catch (error) {
        if (link) return;
        adv.reply(error.message || String(error));
        console.error(error);
    }
}

async function resolveFacebookMedia(url, config) {
    if (config && config.fbKey) {
        const keyResult = await fbdown2(url, config.fbKey);
        if (keyResult && keyResult.status) return keyResult;
    }

    const allResult = await alldown(url);
    if (allResult && allResult.status) return allResult;

    return ndown(url);
}

function firstUrl(candidates) {
    for (const value of candidates) {
        if (typeof value === "string" && value.startsWith("http")) return value;
    }
    return null;
}

function pickFromArray(data) {
    if (!Array.isArray(data) || !data.length) return null;

    const hd = data.find((item) => item && typeof item === "object" && /hd/i.test(item.resolution || ""));
    const pick = hd || data[0];
    if (!pick || typeof pick !== "object") return null;

    return firstUrl([pick.url, pick.link, pick.downloadUrl]);
}

function extractFacebookVideoUrl(info) {
    if (!info || typeof info !== "object") return null;
    const data = info.data !== undefined ? info.data : info;

    if (Array.isArray(data)) return pickFromArray(data);
    if (!data || typeof data !== "object") return null;

    return firstUrl([
        data.high,
        data.hd,
        data["Download High Quality"],
        data.video,
        data.video_hd,
        data.low,
        data.sd,
        data["Download Low Quality"],
        data.video_sd,
        data.url
    ]);
}

function extractFacebookTitle(info) {
    if (!info || typeof info !== "object") return "Facebook video";
    const data = info.data !== undefined ? info.data : info;

    if (Array.isArray(data)) {
        for (const item of data) {
            if (item && typeof item === "object" && typeof item.title === "string" && item.title.trim()) {
                return item.title.trim();
            }
        }
        return "Facebook video";
    }

    return (data && data.title) || info.title || "Facebook video";
}

function extractErrorMessage(info) {
    if (!info || typeof info !== "object") return null;
    return info.msg || info.error || null;
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function fbauto(data, api, e2ee, {rlang, replaceMap, getThreadInfo}) { 
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) { 
         let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs); 
         let check = adminL.indexOf(String(data.senderID)) != -1; 
         if(!check) return adv.reply(rlang("noPer")); 
     } 
     if(global.data.facebook.autodown[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
         global.data.facebook.autodown[data.threadID] = false;
         return adv.reply(rlang("autoOff"));
     }
  
     global.data.facebook.autodown[data.threadID] = true;
     adv.reply(rlang("autoOn")); 
 }

async function autoDown(data, api, e2ee, adv) {
    !global.data.facebook ? global.data.facebook = {}:"";
    !global.data.facebook.autodown ? global.data.facebook.autodown = 
    {}:"";
    global.data.facebook.autodown[data.threadID] == undefined ? global.data.facebook.autodown[data.threadID] = true:"";
    
    if((data.type != "message" && data.type != "message_reply") || !global.data.facebook.autodown[data.threadID] || data.body.indexOf(global.config.facebook.prefix) == 0) return;
    
    let mapLink = ["fb.com", "facebook.com", "fb.watch"];
    
    let args = data.body.split(" ");
    
    for(let i of args) {
        let ch = false;
        for(let j of mapLink) if(i.indexOf(j) != -1) {
            ch = true;
            break;
        }
        
        if(!ch) continue;
        
        main(data, api, e2ee, adv, i);
        await new Promise((t)=>setTimeout(t, 1000));
    }
}

function nul(){}

function ensureExists(path, mask) { 
     var fs = require('fs'); 
   if (typeof mask != 'number') { 
     mask = 0o777; 
   } 
   try { 
     fs.mkdirSync(path, { 
       mode: mask, 
       recursive: true 
     }); 
     return; 
   } catch (ex) { 
     return { 
       err: ex 
     }; 
   } 
 }

module.exports = {
    main,
    fbauto,
    autoDown
}
