
// Shared state - initialized during onload
let apiKeys = null;
let currentApiKeyIndex = 0;
let genAI = null;
let model = null;
let chatSessions = new Map();

function loadApiKeys(cacheDir, apiKeyFile) {
    const fs = require("fs");
    const defaultApiKeys = [
        "APIKEY 1",
        "APIKEY 2",
        "APIKEY..."
    ];
    
    try {
        const data = fs.readFileSync(apiKeyFile, "utf8");
        return JSON.parse(data);
    } catch (error) {
        console.warn("API key file not found, using default API key.");
        const initialData = {
            apiKeys: defaultApiKeys,
            requestCounts: defaultApiKeys.map(() => 0),
            currentApiKeyIndex: 0,
        };
        fs.writeFileSync(apiKeyFile, JSON.stringify(initialData, null, 2), "utf8");
        return initialData;
    }
}

function saveApiKeys(apiKeyFile) {
    const fs = require("fs");
    fs.writeFileSync(apiKeyFile, JSON.stringify(apiKeys, null, 2), "utf8");
}

function getApiKey() {
    return apiKeys.apiKeys[currentApiKeyIndex];
}
 
function createChatSession(modelName = "gemini-2.0-flash-lite") {
    if (!genAI) {
        console.error("Cannot create chat session: genAI is null");
        return null;
    }
    
    let currentModel = createModel(modelName);
    if (!currentModel) {
        console.error("Cannot create chat session: model is null");
        return null;
    }
    
    try {
        let session = currentModel.startChat({
            generationConfig: {
                temperature: 1,
                topP: 0.95,
                topK: 40,
                maxOutputTokens: 8192,
                responseMimeType: "text/plain",
            },
            history: [],
        });
        session.modelName = modelName;
        return session;
    } catch (error) {
        console.error("Error creating chat session:", error);
        return null;
    }
}

function createModel(modelName = "gemini-2.0-flash-lite") {
    return genAI.getGenerativeModel({
        model: modelName,
        systemInstruction: "YOUR INSTRUCTION",
    });
}

function updateApiKeyUsage(apiKeyFile) {
    apiKeys.requestCounts[currentApiKeyIndex]++;

    if (apiKeys.requestCounts[currentApiKeyIndex] >= 1500) {
        console.log("Reached 1500 request limit for current API key. Switching to new API key.");
        apiKeys.requestCounts[currentApiKeyIndex] = 0;
        currentApiKeyIndex = (currentApiKeyIndex + 1) % apiKeys.apiKeys.length;
        console.log(`Using new API key: ${apiKeys.apiKeys[currentApiKeyIndex]}`);
        
        const { GoogleGenerativeAI } = require("@google/generative-ai");
        genAI = new GoogleGenerativeAI(getApiKey());
        model = createModel();
    }
    saveApiKeys(apiKeyFile);
}

function loadStatus(statusFile) {
    const fs = require("fs");
    try {
        const data = fs.readFileSync(statusFile, "utf8");
        return JSON.parse(data);
    } catch (error) {
        console.warn("Status file not found, creating new file.");
        fs.writeFileSync(statusFile, "{}", "utf8");
        return {};
    }
}

function saveStatus(statusFile) {
    const fs = require("fs");
    fs.writeFileSync(statusFile, JSON.stringify(global.data.geminiStatus, null, 2), "utf8");
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function status(data, api, e2ee, adv) {
    const path = require("path");
    const cacheDir = path.join(__dirname, "/cache/gemini");
    const statusFile = path.join(cacheDir, "status.json");
    
    let { rlang, config, getThreadInfo } = adv;

    if (global.config.facebook.admin.indexOf(data.senderID) == -1) {
        let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs);
        let check = adminL.indexOf(String(data.senderID)) != -1;
        if (!check) return adv.reply(rlang("noPermission"));
    }

    const threadID = data.threadID;
    let currentStatus = global.data.geminiStatus[threadID] || false;

    if (data.args[1] && data.args[1].toLowerCase() == "off") {
        if (!global.data.geminiStatus[threadID]) {
            return adv.reply(rlang("isOff"));
        }
        global.data.geminiStatus[threadID] = false;
        chatSessions.delete(threadID);
        adv.reply(rlang("turnOff"));
        saveStatus(statusFile);
    } else {
        if (currentStatus) {
            return adv.reply(rlang("isOn"));
        } else {
            global.data.geminiStatus[threadID] = true;
            
            if (!genAI) {
                adv.reply("Gemini is not fully initialized yet, but status is set to ON.");
            } else if (!chatSessions.has(threadID)) {
                chatSessions.set(threadID, createChatSession());
            }
            
            adv.reply(rlang("turnOn"));
            saveStatus(statusFile);
        }
    }
}

async function cmd1(data, api, e2ee, adv) {
    const path = require("path");
    const cacheDir = path.join(__dirname, "/cache/gemini");
    const apiKeyFile = path.join(cacheDir, "gemini.json");
    
    let { rlang } = adv;
    
    let messageContent = data.body || "";
    let modelName = "gemini-2.0-flash-lite";

    // Allow user to specify default model by flag
    const modelMatch = messageContent.match(/(?:-m|--model)\s+([a-zA-Z0-9.-]+)/);
    if (modelMatch) {
        modelName = modelMatch[1];
        messageContent = messageContent.replace(modelMatch[0], "").trim();
    }
    
    if (messageContent == "") return adv.reply(rlang("askContent"));

    // Check if Gemini is initialized
    if (!genAI) {
        adv.reply("Gemini API is initializing, please try again in a moment.");
        return;
    }

    const threadID = data.threadID;
    let chatSession;
    
    try {
        chatSession = chatSessions.get(threadID);
        
        if (!chatSession || chatSession.modelName !== modelName) {
            chatSession = createChatSession(modelName);
            chatSessions.set(threadID, chatSession);
        }

        const result = await chatSession.sendMessage(messageContent);
        adv.reply(result.response.text());
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        adv.reply(rlang("errorMessage"));
    } finally {
        updateApiKeyUsage(apiKeyFile);
    }
}

function fileToGenerativePart(filepath, mimeType) {
    const fs = require('fs');
    return {
        inlineData: {
            data: Buffer.from(fs.readFileSync(filepath)).toString("base64"),
            mimeType,
        },
    };
}

async function downloadImage(url, filePath) {
    const fs = require('fs');
    const axios = require('axios');
    const response = await axios({ url, method: 'GET', responseType: 'stream' });
    const writer = fs.createWriteStream(filePath);
    response.data.pipe(writer);
    await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
    });
}

async function chathook(data, api, e2ee, adv) {
    const fs = require('fs');
    const path = require('path');
    const axios = require('axios');
    
    // Early exit conditions
    if (data.type !== "message") return;
    if (!genAI) return;

    const cacheDir = path.join(__dirname, "/cache/gemini");
    const apiKeyFile = path.join(cacheDir, "gemini.json");
    
    let { rlang, config, replaceMap } = adv;

    !global.data.geminiStatus ? global.data.geminiStatus = {} : '';
    global.data.geminiStatus[data.threadID] === undefined ? global.data.geminiStatus[data.threadID] = config.geminiStatus : '';

    if (!global.data.geminiStatus[data.threadID]) return;
    if (data.body.indexOf(global.config.facebook.prefix) === 0) return;

    const threadID = data.threadID;
    
    let messageContent = data.body || "";
    let modelName = "gemini-2.0-flash-lite";

    const modelMatch = messageContent.match(/(?:-m|--model)\s+([a-zA-Z0-9.-]+)/);
    if (modelMatch) {
        modelName = modelMatch[1];
        messageContent = messageContent.replace(modelMatch[0], "").trim();
    }
    
    let chatSession = chatSessions.get(threadID);

    if (!chatSession || chatSession.modelName !== modelName) {
        try {
            chatSession = createChatSession(modelName);
            chatSessions.set(threadID, chatSession);
        } catch (error) {
            console.error("Error creating chat session:", error);
            return;
        }
    }
    
    if (data.attachments && data.attachments.length > 0) {
        const attachment = data.attachments[0];
        const link = attachment.url;
        let dir;
        let mimeType;

        if (attachment.type === "photo") {
            dir = path.join(__dirname, "cache", "gemini", "gemini.jpg");
            mimeType = "image/jpg";
        } else if (attachment.type === "video") {
            dir = path.join(__dirname, "cache", "gemini", "gemini.mp4");
            mimeType = "video/mp4";
        } else if (attachment.type === "audio") {
             dir = path.join(__dirname, "cache", "gemini", "gemini.mp3");
             mimeType = "audio/mp3";
        } else {
            return; 
        }
        
        ensureExists(path.join(__dirname, "cache", "gemini"));
        try {
            await downloadImage(link, dir);
            const prompt = messageContent;
            const attachmentPart = fileToGenerativePart(dir, mimeType);
            
            const result = await chatSession.sendMessage([prompt, attachmentPart]);
            adv.reply(result.response.text());
        } catch (error) {
            console.error("Error calling Gemini API:", error);
            adv.reply(rlang("errorMessage"));
        } finally {
            updateApiKeyUsage(apiKeyFile);
        }
        return;
    }

    const messageS = messageContent;
    try {
        const result = await chatSession.sendMessage(messageS);
        adv.reply(result.response.text());
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        adv.reply(rlang("errorMessage"));
    } finally {
        updateApiKeyUsage(apiKeyFile);
    }
}

function onload(info) {
    try {
        const fs = require("fs");
        const path = require("path");
        
        // Setup cache directory
        const cacheDir = path.join(__dirname, "/cache/gemini");
        const apiKeyFile = path.join(cacheDir, "gemini.json");
        const statusFile = path.join(cacheDir, "status.json");
        
        // Create cache directory
        ensureExists(cacheDir);
        
        // Initialize API keys
        apiKeys = loadApiKeys(cacheDir, apiKeyFile);
        currentApiKeyIndex = 0;
        
        try {
            // Import the Gemini API library
            const { GoogleGenerativeAI } = require("@google/generative-ai");
            
            // Initialize Gemini
            genAI = new GoogleGenerativeAI(getApiKey());
            model = createModel();
            
            // Load status and create chat sessions
            global.data.geminiStatus = loadStatus(statusFile);

            for (const threadID in global.data.geminiStatus) {
                if (global.data.geminiStatus[threadID]) {
                    try {
                        chatSessions.set(threadID, createChatSession());
                    } catch (error) {
                        console.error(`Error creating chat session for thread ${threadID}:`, error);
                    }
                }
            }
        } catch (error) {
            console.error("Failed to initialize Gemini API:", error);
            console.error("Please make sure @google/generative-ai is installed correctly.");
        }
    } catch (error) {
        console.error("Error in onload function:", error);
    }
}

function ensureExists(path, mask) {
    const fs = require('fs');
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(path, {
            mode: mask,
            recursive: true
        });
        return;
    } catch (ex) {
        return {
            err: ex
        };
    }
}

module.exports = {
    cmd1,
    status,
    chathook,
    onload,
};