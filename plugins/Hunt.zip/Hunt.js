const SPECIES = {
    common: [
        { name: "Chuột", emoji: "🐭" },
        { name: "Thỏ", emoji: "🐰" },
        { name: "Ếch", emoji: "🐸" },
        { name: "Chim", emoji: "🐦" }
    ],
    uncommon: [
        { name: "Cáo", emoji: "🦊" },
        { name: "Sói", emoji: "🐺" },
        { name: "Rùa", emoji: "🐢" }
    ],
    rare: [
        { name: "Rồng con", emoji: "🐉" },
        { name: "Kỳ lân nhỏ", emoji: "🦄" },
        { name: "Rắn bạc", emoji: "🐍" }
    ],
    epic: [
        { name: "Đại bàng sấm", emoji: "🦅" },
        { name: "Long thú", emoji: "🐲" }
    ],
    legendary: [
        { name: "Phượng hoàng", emoji: "🔥" },
        { name: "Sói mặt trăng", emoji: "🌙" }
    ],
    mythic: [
        { name: "Thần thú", emoji: "✨" },
        { name: "Rồng tinh vân", emoji: "🌌" }
    ]
};

const PRICE_RANGES = {
    common: [50, 120],
    uncommon: [150, 300],
    rare: [400, 800],
    epic: [1000, 1800],
    legendary: [3000, 6000],
    mythic: [10000, 20000]
};

const SHOP_ITEMS = {
    bait: {
        name: "Mồi thơm",
        price: 300,
        desc: "Tăng nhẹ chất lượng thú bắt được."
    },
    lucky_charm: {
        name: "Bùa may mắn",
        price: 800,
        desc: "Tăng nhẹ tỉ lệ thú hiếm."
    },
    trap: {
        name: "Bẫy đôi",
        price: 1200,
        desc: "Lần hunt tiếp theo bắt thêm 1 thú."
    }
};

// Messaging helpers
function isE2EEThread(adv, threadID) {
    if (!adv || !adv.e2ee || typeof adv.e2ee.isE2EEThread !== "function") return false;
    return adv.e2ee.isE2EEThread(threadID);
}

function safeReply(data, api, adv, text, callback) {
    const threadID = data ? data.threadID : null;
    const messageID = data ? data.messageID : null;
    if (!threadID) {
        if (typeof callback === "function") callback(new Error("Missing threadID"));
        return;
    }

    if (isE2EEThread(adv, threadID) && adv && adv.e2ee && typeof adv.e2ee.sendText === "function") {
        adv.e2ee.sendText(threadID, text, messageID)
            .then(res => { if (typeof callback === "function") callback(null, res); })
            .catch(err => { if (typeof callback === "function") callback(err); });
        return;
    }

    if (adv && adv.ctx && typeof adv.ctx.reply === "function") {
        try {
            return adv.ctx.reply(text, callback);
        } catch (e) {
            // fallback
        }
    }
    if (adv && typeof adv.reply === "function") {
        try {
            return adv.reply(text, callback);
        } catch (e) {
            // fallback
        }
    }
    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](text, threadID, callback, messageID);
        } catch (e) {
            // fallback
        }
    }
    if (typeof callback === "function") callback(new Error("No reply method available"));
}

function safeSend(data, api, adv, text, callback) {
    const threadID = data ? data.threadID : null;
    if (!threadID) {
        if (typeof callback === "function") callback(new Error("Missing threadID"));
        return;
    }

    if (isE2EEThread(adv, threadID) && adv && adv.e2ee && typeof adv.e2ee.sendText === "function") {
        adv.e2ee.sendText(threadID, text)
            .then(res => { if (typeof callback === "function") callback(null, res); })
            .catch(err => { if (typeof callback === "function") callback(err); });
        return;
    }

    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](text, threadID, callback);
        } catch (e) {
            // fallback
        }
    }

    return safeReply(data, api, adv, text, callback);
}

function safeEdit(api, adv, messageID, text, fallbackData) {
    const threadID = fallbackData ? fallbackData.threadID : null;
    if (!threadID || isE2EEThread(adv, threadID)) {
        return safeReply(fallbackData, api, adv, text);
    }
    if (api && typeof api.editMessage === "function" && messageID) {
        try {
            api.editMessage(text, messageID, (err) => {
                if (err) {
                    safeReply(fallbackData, api, adv, text);
                }
            });
        } catch (e) {
            safeReply(fallbackData, api, adv, text);
        }
    } else {
        safeReply(fallbackData, api, adv, text);
    }
}

function safeUnsend(api, adv, messageID, callback) {
    if (!messageID) {
        if (typeof callback === "function") callback(new Error("Missing messageID"));
        return;
    }

    if (adv && adv.ctx && typeof adv.ctx.unsend === "function") {
        try {
            adv.ctx.unsend(messageID);
            if (typeof callback === "function") callback(null);
            return;
        } catch (e) {
            // fallback
        }
    }

    if (adv && typeof adv.unsend === "function") {
        try {
            adv.unsend(messageID);
            if (typeof callback === "function") callback(null);
            return;
        } catch (e) {
            // fallback
        }
    }

    if (api && typeof api["unsend" + "Message"] === "function") {
        try {
            api["unsend" + "Message"](messageID, (err) => {
                if (typeof callback === "function") callback(err);
            });
            return;
        } catch (e) {
            if (typeof callback === "function") callback(e);
        }
    }

    if (typeof callback === "function") callback(new Error("No unsend method available"));
}

function sendTempReply(data, api, adv, text, ms, callback) {
    safeReply(data, api, adv, text, (err, info) => {
        if (err) {
            if (typeof callback === "function") callback(err);
            return;
        }

        let msgID = null;
        if (info) {
            if (typeof info === "string") msgID = info;
            else if (info.messageID) msgID = info.messageID;
            else if (info.messageId) msgID = info.messageId;
        }

        if (msgID) {
            setTimeout(() => {
                safeUnsend(api, adv, msgID, callback);
            }, ms);
        } else {
            if (typeof callback === "function") callback(new Error("Could not extract message ID"));
        }
    });
}

// Localization helper
function t(adv, key, map, fallback) {
    let text = "";
    if (adv && typeof adv.rlang === "function") {
        try {
            text = adv.rlang(key);
        } catch (e) {
            // fallback
        }
    }
    if (!text && adv && adv.lang && adv.lang[key]) {
        const locale = adv.iso639 || "vi_VN";
        text = adv.lang[key][locale] || adv.lang[key]["en_US"];
    }
    if (!text) {
        text = fallback || "";
    }
    if (adv && typeof adv.replaceMap === "function" && map) {
        try {
            return adv.replaceMap(text, map);
        } catch (e) {
            // fallback
        }
    }
    if (map) {
        for (let k in map) {
            text = text.replace(new RegExp(k, "g"), map[k]);
        }
    }
    return text;
}

function getLocalizedRarity(adv, rarity) {
    const raw = t(adv, "rarityNames", null, "common=common|uncommon=uncommon|rare=rare|epic=epic|legendary=legendary|mythic=mythic");
    const pairs = raw.split("|");
    for (let p of pairs) {
        const parts = p.split("=");
        if (parts[0] === rarity) return parts[1];
    }
    return rarity;
}

function getLocalizedItemName(adv, itemId) {
    const raw = t(adv, "itemNames", null, "bait=Bait|lucky_charm=Lucky Charm|trap=Double Trap");
    const pairs = raw.split("|");
    for (let p of pairs) {
        const parts = p.split("=");
        if (parts[0] === itemId) return parts[1];
    }
    return itemId;
}

function getLocalizedItemDesc(adv, itemId) {
    const raw = t(adv, "itemDescriptions", null, "bait=Slightly improves hunt quality.|lucky_charm=Slightly increases rare pet chance.|trap=Adds one extra pet to the next hunt.");
    const pairs = raw.split("|");
    for (let p of pairs) {
        const parts = p.split("=");
        if (parts[0] === itemId) return parts[1];
    }
    return "";
}

// Economy Integration helpers
function ensureEconomyUser(userID) {
    if (!global.data) global.data = {};
    if (!global.data.economy) global.data.economy = {};
    if (!global.data.economy[userID]) {
        global.data.economy[userID] = { coin: 0 };
    }
    if (typeof global.data.economy[userID].coin !== "number") {
        global.data.economy[userID].coin = Number(global.data.economy[userID].coin) || 0;
    }
}

function getBalance(userID) {
    ensureEconomyUser(userID);
    return global.data.economy[userID].coin;
}

function addMoney(userID, amount) {
    if (typeof amount !== "number" || !isFinite(amount) || amount <= 0) return false;
    ensureEconomyUser(userID);
    global.data.economy[userID].coin += Math.floor(amount);
    return true;
}

function removeMoney(userID, amount) {
    if (typeof amount !== "number" || !isFinite(amount) || amount <= 0) return false;
    ensureEconomyUser(userID);
    if (global.data.economy[userID].coin < amount) return false;
    global.data.economy[userID].coin -= Math.floor(amount);
    return true;
}

function canAfford(userID, amount) {
    if (typeof amount !== "number" || !isFinite(amount) || amount < 0) return false;
    ensureEconomyUser(userID);
    return global.data.economy[userID].coin >= amount;
}

function moneyIcon() {
    return (global.data.economyConfig && global.data.economyConfig.icon) || "💰";
}

function formatMoney(amount) {
    return amount + moneyIcon();
}

// Hunt Storage helpers
function ensureHuntPlayer(userID) {
    if (!global.data) global.data = {};
    if (!global.data.hunt) {
        global.data.hunt = {
            players: {},
            pets: {},
            nextPetId: 1
        };
    }
    if (!global.data.hunt.players) global.data.hunt.players = {};
    if (!global.data.hunt.pets) global.data.hunt.pets = {};
    if (!global.data.hunt.nextPetId) global.data.hunt.nextPetId = 1;

    if (!global.data.hunt.players[userID]) {
        global.data.hunt.players[userID] = {
            inventory: {
                bait: 0,
                lucky_charm: 0,
                trap: 0
            },
            petIds: [],
            stats: {
                hunts: 0,
                battles: 0,
                sold: 0
            },
            cooldowns: {
                hunt: 0,
                battle: 0
            }
        };
    }

    const player = global.data.hunt.players[userID];
    if (!player.inventory) player.inventory = { bait: 0, lucky_charm: 0, trap: 0 };
    if (player.inventory.bait === undefined) player.inventory.bait = 0;
    if (player.inventory.lucky_charm === undefined) player.inventory.lucky_charm = 0;
    if (player.inventory.trap === undefined) player.inventory.trap = 0;
    if (!player.petIds) player.petIds = [];
    if (!player.stats) player.stats = { hunts: 0, battles: 0, sold: 0 };
    if (player.stats.hunts === undefined) player.stats.hunts = 0;
    if (player.stats.battles === undefined) player.stats.battles = 0;
    if (player.stats.sold === undefined) player.stats.sold = 0;
    if (!player.cooldowns) player.cooldowns = { hunt: 0, battle: 0 };
    if (player.cooldowns.hunt === undefined) player.cooldowns.hunt = 0;
    if (player.cooldowns.battle === undefined) player.cooldowns.battle = 0;

    return player;
}

// Utility functions
function getPrefix() {
    return (global.config && global.config.facebook && global.config.facebook.prefix) || "|";
}

function getArgs(data) {
    if (data && Array.isArray(data.args)) return data.args;
    if (data && typeof data.body === "string") {
        return data.body.trim().split(/\s+/);
    }
    return [];
}

function secondsLeft(lastTime, cooldownSeconds) {
    const elapsed = (Date.now() - lastTime) / 1000;
    const left = cooldownSeconds - elapsed;
    return left > 0 ? Math.ceil(left) : 0;
}

function clampInt(value, min, max, fallback) {
    const parsed = parseInt(value, 10);
    if (isNaN(parsed)) return fallback;
    return Math.max(min, Math.min(max, parsed));
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function weightedPick(entries) {
    let total = 0;
    for (let k in entries) total += entries[k];
    let r = Math.random() * total;
    for (let k in entries) {
        r -= entries[k];
        if (r <= 0) return k;
    }
    return Object.keys(entries)[0];
}

function rarityRank(rarity) {
    const ranks = {
        common: 1,
        uncommon: 2,
        rare: 3,
        epic: 4,
        legendary: 5,
        mythic: 6
    };
    return ranks[rarity] || 0;
}

function getBestPet(player) {
    if (!player || !player.petIds || player.petIds.length === 0) return null;
    const pets = player.petIds.map(id => global.data.hunt.pets[id]).filter(Boolean);
    if (pets.length === 0) return null;

    pets.sort((a, b) => {
        const rankA = rarityRank(a.rarity);
        const rankB = rarityRank(b.rarity);
        if (rankA !== rankB) return rankB - rankA;
        return b.sellPrice - a.sellPrice;
    });
    return pets[0];
}

function chooseRarity(hasLuckyCharm) {
    let weights = {
        common: 60,
        uncommon: 25,
        rare: 10,
        epic: 4,
        legendary: 0.9,
        mythic: 0.1
    };
    if (hasLuckyCharm) {
        weights = {
            common: 60,
            uncommon: 25,
            rare: 15,
            epic: 8,
            legendary: 2.7,
            mythic: 0.5
        };
    }
    return weightedPick(weights);
}

function generatePet(rarity, hasBait, ownerID) {
    let actualRarity = rarity;
    if (hasBait) {
        if (rarity === "common" && Math.random() < 0.5) {
            actualRarity = "uncommon";
        } else if (rarity === "uncommon" && Math.random() < 0.3) {
            actualRarity = "rare";
        }
    }

    const speciesList = SPECIES[actualRarity];
    const spec = speciesList[randomInt(0, speciesList.length - 1)];
    const priceRange = PRICE_RANGES[actualRarity];
    const sellPrice = randomInt(priceRange[0], priceRange[1]);

    const petId = global.data.hunt.nextPetId++;
    const pet = {
        id: petId,
        ownerID: ownerID,
        speciesId: spec.name,
        name: spec.name,
        emoji: spec.emoji,
        rarity: actualRarity,
        sellPrice: sellPrice,
        caughtAt: Date.now(),
        locked: false
    };

    global.data.hunt.pets[petId] = pet;
    return pet;
}

// Commands Implementation
function checkEconomy(data, api, adv) {
    if (!global.data || !global.data.economy) {
        safeReply(data, api, adv, t(adv, "economyMissing", null, "Plugin Economy chưa được cài đặt nên không thể sử dụng tính năng săn thú."));
        return false;
    }
    return true;
}

function hunt(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const nowTime = Date.now();
    const lastTime = player.cooldowns.hunt || 0;
    const cooldownLeft = secondsLeft(lastTime, 15);

    if (cooldownLeft > 0) {
        return safeReply(data, api, adv, t(adv, "huntCooldown", { "{seconds}": String(cooldownLeft) }, `❌ Vui lòng chờ ${cooldownLeft}s trước khi săn tiếp.`));
    }

    player.cooldowns.hunt = nowTime;

    let hasTrap = false;
    let hasBait = false;
    let hasLuckyCharm = false;

    if (player.inventory.trap > 0) {
        player.inventory.trap--;
        hasTrap = true;
    }
    if (player.inventory.bait > 0) {
        player.inventory.bait--;
        hasBait = true;
    }
    if (player.inventory.lucky_charm > 0) {
        player.inventory.lucky_charm--;
        hasLuckyCharm = true;
    }

    safeReply(data, api, adv, t(adv, "huntSearching", null, "🐾 Đang tìm kiếm thú..."), (err, info) => {
        setTimeout(() => {
            const caught = [];
            const rarity1 = chooseRarity(hasLuckyCharm);
            const pet1 = generatePet(rarity1, hasBait, data.senderID);
            caught.push(pet1);
            player.petIds.push(pet1.id);

            if (hasTrap) {
                const rarity2 = chooseRarity(hasLuckyCharm);
                const pet2 = generatePet(rarity2, hasBait, data.senderID);
                caught.push(pet2);
                player.petIds.push(pet2.id);
            }

            let bonus = Math.random() < 0.4 ? randomInt(20, 100) : 0;
            if (bonus > 0) {
                addMoney(data.senderID, bonus);
            }

            player.stats.hunts++;

            const petText = caught.map(p => `#${p.id} ${p.emoji} ${p.name} [${getLocalizedRarity(adv, p.rarity)}] - Giá bán: ${formatMoney(p.sellPrice)}`).join("\n");
            
            let resultText = "";
            if (bonus > 0) {
                resultText = t(adv, "huntResult", {
                    "{pets}": petText,
                    "{bonus}": formatMoney(bonus),
                    "{balance}": formatMoney(getBalance(data.senderID))
                }, "🐾 Bạn đã săn được:\n{pets}\n\nTiền thưởng: {bonus}\nSố dư: {balance}");
            } else {
                resultText = t(adv, "huntResultNoBonus", {
                    "{pets}": petText,
                    "{balance}": formatMoney(getBalance(data.senderID))
                }, "🐾 Bạn đã săn được:\n{pets}\n\nSố dư: {balance}");
            }

            let msgID = null;
            if (info) {
                if (typeof info === "string") msgID = info;
                else if (info.messageID) msgID = info.messageID;
                else if (info.messageId) msgID = info.messageId;
            }

            safeEdit(api, adv, msgID, resultText, data);
        }, 1700);
    });
}

function zoo(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const petIds = player.petIds || [];
    const pets = petIds.map(id => global.data.hunt.pets[id]).filter(Boolean);

    if (pets.length === 0) {
        return safeReply(data, api, adv, t(adv, "zooEmpty", { "{prefix}": getPrefix() }, `🦴 Bạn chưa có thú nào. Dùng ${getPrefix()}hunt để bắt thú đầu tiên.`));
    }

    pets.sort((a, b) => a.id - b.id);

    const args = getArgs(data);
    let page = 1;
    if (args[1] !== undefined) {
        page = parseInt(args[1], 10);
        if (isNaN(page) || page < 1) page = 1;
    }

    const totalPages = Math.ceil(pets.length / 10);
    if (page > totalPages) page = totalPages;
    if (page < 1) page = 1;

    const start = (page - 1) * 10;
    const pagePets = pets.slice(start, start + 10);

    const listText = pagePets.map(p => {
        let line = t(adv, "zooLine", {
            "{id}": String(p.id),
            "{emoji}": p.emoji,
            "{name}": p.name,
            "{rarity}": getLocalizedRarity(adv, p.rarity),
            "{price}": formatMoney(p.sellPrice)
        }, "#{id} {emoji} {name} [{rarity}] - Giá bán: {price}");
        if (p.locked) line += " 🔒";
        return line;
    }).join("\n");

    const header = t(adv, "zooHeader", {
        "{page}": String(page),
        "{totalPages}": String(totalPages),
        "{total}": String(pets.length)
    }, "🐾 Vườn thú của bạn - Trang {page}/{totalPages}\nTổng số: {total} thú");

    const footer = t(adv, "zooFooter", { "{prefix}": getPrefix() }, `Dùng ${getPrefix()}zoo <trang> để xem trang khác.`);

    const resultText = `${header}\n${listText}\n\n${footer}`;
    safeReply(data, api, adv, resultText);
}

function sellpet(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    if (args[1] === undefined) {
        return safeReply(data, api, adv, t(adv, "sellUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}sellpet <id|all>`));
    }

    const player = ensureHuntPlayer(data.senderID);
    const target = args[1].trim().toLowerCase();

    if (target === "all") {
        const petIds = player.petIds || [];
        const pets = petIds.map(id => global.data.hunt.pets[id]).filter(Boolean);
        const unlockedPets = pets.filter(p => !p.locked);

        if (unlockedPets.length === 0) {
            return safeReply(data, api, adv, t(adv, "sellAllNoPets", null, "Bạn không có thú nào có thể bán."));
        }

        let totalEarned = 0;
        for (let p of unlockedPets) {
            totalEarned += p.sellPrice;
            delete global.data.hunt.pets[p.id];
            player.stats.sold++;
        }

        player.petIds = pets.filter(p => p.locked).map(p => p.id);
        addMoney(data.senderID, totalEarned);

        return safeReply(data, api, adv, t(adv, "sellAllSuccess", {
            "{count}": String(unlockedPets.length),
            "{total}": formatMoney(totalEarned),
            "{balance}": formatMoney(getBalance(data.senderID))
        }, `💸 Đã bán {count} thú và nhận {total}.\nSố dư hiện tại: {balance}`));
    } else {
        const petId = parseInt(target, 10);
        if (isNaN(petId) || petId <= 0) {
            return safeReply(data, api, adv, t(adv, "sellInvalidPet", { "{id}": target }, `Không tìm thấy thú #{id}.`));
        }

        const pet = global.data.hunt.pets[petId];
        if (!pet || pet.ownerID !== data.senderID) {
            return safeReply(data, api, adv, t(adv, "sellNotOwner", { "{id}": String(petId) }, `Bạn không sở hữu thú #{id}.`));
        }

        if (pet.locked) {
            return safeReply(data, api, adv, t(adv, "sellLocked", { "{id}": String(petId) }, `Thú #{id} đang bị khóa nên không thể bán.`));
        }

        const price = pet.sellPrice;
        addMoney(data.senderID, price);
        player.stats.sold++;

        player.petIds = player.petIds.filter(id => id !== petId);
        delete global.data.hunt.pets[petId];

        return safeReply(data, api, adv, t(adv, "sellOneSuccess", {
            "{id}": String(pet.id),
            "{emoji}": pet.emoji,
            "{name}": pet.name,
            "{price}": formatMoney(price),
            "{balance}": formatMoney(getBalance(data.senderID))
        }, `💸 Đã bán #{id} {emoji} {name} với giá {price}.\nSố dư hiện tại: {balance}`));
    }
}

function huntinv(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const invText = t(adv, "inventory", {
        "{baitName}": getLocalizedItemName(adv, "bait"),
        "{bait}": String(player.inventory.bait),
        "{luckyName}": getLocalizedItemName(adv, "lucky_charm"),
        "{lucky}": String(player.inventory.lucky_charm),
        "{trapName}": getLocalizedItemName(adv, "trap"),
        "{trap}": String(player.inventory.trap)
    }, "🎒 Túi đồ săn thú của bạn:\n- {baitName}: {bait}\n- {luckyName}: {lucky}\n- {trapName}: {trap}");

    safeReply(data, api, adv, invText);
}

function huntshop(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    let shopText = t(adv, "shopHeader", null, "🛒 Cửa hàng săn thú:") + "\n";
    for (let k in SHOP_ITEMS) {
        const item = SHOP_ITEMS[k];
        shopText += t(adv, "shopLine", {
            "{id}": k,
            "{name}": getLocalizedItemName(adv, k),
            "{price}": formatMoney(item.price),
            "{desc}": getLocalizedItemDesc(adv, k)
        }, "- {id}: {name} - {price}\n  {desc}") + "\n";
    }
    shopText += `\nGõ ${getPrefix()}huntbuy <itemId> [số lượng] để mua.`;
    safeReply(data, api, adv, shopText);
}

function huntbuy(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const itemId = args[1];
    if (!itemId || !SHOP_ITEMS[itemId]) {
        return safeReply(data, api, adv, t(adv, "buyInvalidItem", { "{itemId}": String(itemId) }, `Vật phẩm \`{itemId}\` không tồn tại trong cửa hàng.`));
    }

    let qty = 1;
    if (args[2] !== undefined) {
        qty = parseInt(args[2], 10);
        if (isNaN(qty) || qty < 1 || qty > 20) {
            return safeReply(data, api, adv, t(adv, "buyInvalidQuantity", null, "Số lượng phải là số nguyên từ 1 đến 20."));
        }
    }

    const item = SHOP_ITEMS[itemId];
    const totalCost = item.price * qty;

    if (!canAfford(data.senderID, totalCost)) {
        const missing = totalCost - getBalance(data.senderID);
        return safeReply(data, api, adv, t(adv, "buyNoMoney", { "{missing}": formatMoney(missing) }, `Bạn không đủ tiền. Còn thiếu {missing}.`));
    }

    removeMoney(data.senderID, totalCost);
    const player = ensureHuntPlayer(data.senderID);
    player.inventory[itemId] = (player.inventory[itemId] || 0) + qty;

    safeReply(data, api, adv, t(adv, "buySuccess", {
        "{quantity}": String(qty),
        "{name}": getLocalizedItemName(adv, itemId),
        "{total}": formatMoney(totalCost),
        "{balance}": formatMoney(getBalance(data.senderID))
    }, `✅ Đã mua {quantity}x {name} với giá {total}.\nSố dư: {balance}`));
}

function petbattle(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const pet = getBestPet(player);

    if (!pet) {
        return safeReply(data, api, adv, t(adv, "battleNoPet", { "{prefix}": getPrefix() }, `Bạn chưa có thú nào để chiến đấu. Dùng ${getPrefix()}hunt để bắt thú trước.`));
    }

    const nowTime = Date.now();
    const lastTime = player.cooldowns.battle || 0;
    const cooldownLeft = secondsLeft(lastTime, 60);

    if (cooldownLeft > 0) {
        return safeReply(data, api, adv, t(adv, "battleCooldown", { "{seconds}": String(cooldownLeft) }, `⚔️ Vui lòng chờ ${cooldownLeft}s trước khi chiến đấu tiếp.`));
    }

    player.cooldowns.battle = nowTime;
    player.stats.battles++;

    const chances = {
        common: 0.45,
        uncommon: 0.50,
        rare: 0.58,
        epic: 0.65,
        legendary: 0.75,
        mythic: 0.85
    };

    const winChance = chances[pet.rarity] || 0.45;
    const isWin = Math.random() < winChance;

    if (isWin) {
        const rewards = {
            common: [100, 200],
            uncommon: [200, 350],
            rare: [400, 700],
            epic: [800, 1300],
            legendary: [2000, 3500],
            mythic: [5000, 9000]
        };
        const range = rewards[pet.rarity] || [100, 200];
        const reward = randomInt(range[0], range[1]);
        addMoney(data.senderID, reward);

        safeReply(data, api, adv, t(adv, "battleWin", {
            "{emoji}": pet.emoji,
            "{name}": pet.name,
            "{rarity}": getLocalizedRarity(adv, pet.rarity),
            "{reward}": formatMoney(reward),
            "{balance}": formatMoney(getBalance(data.senderID))
        }, "⚔️ {emoji} {name} [{rarity}] đã thắng trận!\nPhần thưởng: {reward}\nSố dư: {balance}"));
    } else {
        safeReply(data, api, adv, t(adv, "battleLose", {
            "{emoji}": pet.emoji,
            "{name}": pet.name,
            "{rarity}": getLocalizedRarity(adv, pet.rarity)
        }, "⚔️ {emoji} {name} [{rarity}] đã thua trận. Bạn không mất tiền."));
    }
}

function lockpet(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petId = parseInt(args[1], 10);
    if (isNaN(petId) || petId <= 0) {
        return safeReply(data, api, adv, t(adv, "sellInvalidPet", { "{id}": args[1] }, "Không tìm thấy thú #{id}."));
    }

    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "sellNotOwner", { "{id}": String(petId) }, "Bạn không sở hữu thú #{id}."));
    }

    pet.locked = true;
    safeReply(data, api, adv, `🔒 Đã khóa thú cưng #${pet.id} ${pet.emoji} ${pet.name}. Không thể bán khi đang khóa.`);
}

function unlockpet(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petId = parseInt(args[1], 10);
    if (isNaN(petId) || petId <= 0) {
        return safeReply(data, api, adv, t(adv, "sellInvalidPet", { "{id}": args[1] }, "Không tìm thấy thú #{id}."));
    }

    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "sellNotOwner", { "{id}": String(petId) }, "Bạn không sở hữu thú #{id}."));
    }

    pet.locked = false;
    safeReply(data, api, adv, `🔓 Đã mở khóa thú cưng #${pet.id} ${pet.emoji} ${pet.name}. Giờ bạn có thể bán pet này.`);
}

module.exports = {
    hunt,
    zoo,
    sellpet,
    huntinv,
    huntshop,
    huntbuy,
    petbattle,
    lockpet,
    unlockpet
};
