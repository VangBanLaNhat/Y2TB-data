const SPECIES = {
    common: [
        { name: "Chuột", emoji: "🐭" },
        { name: "Thỏ", emoji: "🐰" },
        { name: "Ếch", emoji: "🐸" },
        { name: "Chim", emoji: "🐦" }
    ],
    uncommon: [
        { name: "Cáo", emoji: "🦊" },
        { name: "Sói", emoji: "🐺" },
        { name: "Rùa", emoji: "🐢" }
    ],
    rare: [
        { name: "Rồng con", emoji: "🐉" },
        { name: "Kỳ lân nhỏ", emoji: "🦄" },
        { name: "Rắn bạc", emoji: "🐍" }
    ],
    epic: [
        { name: "Đại bàng sấm", emoji: "🦅" },
        { name: "Long thú", emoji: "🐲" }
    ],
    legendary: [
        { name: "Phượng hoàng", emoji: "🔥" },
        { name: "Sói mặt trăng", emoji: "🌙" }
    ],
    mythic: [
        { name: "Thần thú", emoji: "✨" },
        { name: "Rồng tinh vân", emoji: "🌌" }
    ]
};

const PRICE_RANGES = {
    common: [50, 120],
    uncommon: [150, 300],
    rare: [400, 800],
    epic: [1000, 1800],
    legendary: [3000, 6000],
    mythic: [10000, 20000]
};

// Messaging helpers
function isE2EEThread(adv, threadID) {
    if (!adv || !adv.e2ee || typeof adv.e2ee.isE2EEThread !== "function") return false;
    return adv.e2ee.isE2EEThread(threadID);
}

function safeReply(data, api, adv, text, callback) {
    const threadID = data ? data.threadID : null;
    const messageID = data ? data.messageID : null;
    if (!threadID) {
        if (typeof callback === "function") callback(new Error("Missing threadID"));
        return;
    }

    if (isE2EEThread(adv, threadID) && adv && adv.e2ee && typeof adv.e2ee.sendText === "function") {
        adv.e2ee.sendText(threadID, text, messageID)
            .then(res => { if (typeof callback === "function") callback(null, res); })
            .catch(err => { if (typeof callback === "function") callback(err); });
        return;
    }

    if (adv && adv.ctx && typeof adv.ctx.reply === "function") {
        try {
            return adv.ctx.reply(text, callback);
        } catch (e) {
            // fallback
        }
    }
    if (adv && typeof adv.reply === "function") {
        try {
            return adv.reply(text, callback);
        } catch (e) {
            // fallback
        }
    }
    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](text, threadID, callback, messageID);
        } catch (e) {
            // fallback
        }
    }
    if (typeof callback === "function") callback(new Error("No reply method available"));
}

function safeSend(data, api, adv, text, callback) {
    const threadID = data ? data.threadID : null;
    if (!threadID) {
        if (typeof callback === "function") callback(new Error("Missing threadID"));
        return;
    }

    if (isE2EEThread(adv, threadID) && adv && adv.e2ee && typeof adv.e2ee.sendText === "function") {
        adv.e2ee.sendText(threadID, text)
            .then(res => { if (typeof callback === "function") callback(null, res); })
            .catch(err => { if (typeof callback === "function") callback(err); });
        return;
    }

    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](text, threadID, callback);
        } catch (e) {
            // fallback
        }
    }

    return safeReply(data, api, adv, text, callback);
}

function safeEdit(api, adv, messageID, text, fallbackData) {
    const threadID = fallbackData ? fallbackData.threadID : null;
    if (!threadID || isE2EEThread(adv, threadID)) {
        return safeReply(fallbackData, api, adv, text);
    }
    if (api && typeof api.editMessage === "function" && messageID) {
        try {
            api.editMessage(text, messageID, (err) => {
                if (err) {
                    safeReply(fallbackData, api, adv, text);
                }
            });
        } catch (e) {
            safeReply(fallbackData, api, adv, text);
        }
    } else {
        safeReply(fallbackData, api, adv, text);
    }
}

function safeUnsend(api, adv, messageID, callback) {
    if (!messageID) {
        if (typeof callback === "function") callback(new Error("Missing messageID"));
        return;
    }

    if (adv && adv.ctx && typeof adv.ctx.unsend === "function") {
        try {
            adv.ctx.unsend(messageID);
            if (typeof callback === "function") callback(null);
            return;
        } catch (e) {
            // fallback
        }
    }

    if (adv && typeof adv.unsend === "function") {
        try {
            adv.unsend(messageID);
            if (typeof callback === "function") callback(null);
            return;
        } catch (e) {
            // fallback
        }
    }

    if (api && typeof api["unsend" + "Message"] === "function") {
        try {
            api["unsend" + "Message"](messageID, (err) => {
                if (typeof callback === "function") callback(err);
            });
            return;
        } catch (e) {
            if (typeof callback === "function") callback(e);
        }
    }

    if (typeof callback === "function") callback(new Error("No unsend method available"));
}

function sendTempReply(data, api, adv, text, ms, callback) {
    safeReply(data, api, adv, text, (err, info) => {
        if (err) {
            if (typeof callback === "function") callback(err);
            return;
        }

        let msgID = null;
        if (info) {
            if (typeof info === "string") msgID = info;
            else if (info.messageID) msgID = info.messageID;
            else if (info.messageId) msgID = info.messageId;
        }

        if (msgID) {
            setTimeout(() => {
                safeUnsend(api, adv, msgID, callback);
            }, ms);
        } else {
            if (typeof callback === "function") callback(new Error("Could not extract message ID"));
        }
    });
}

// Localization helper
function t(adv, key, map, fallback) {
    let text = "";
    if (adv && typeof adv.rlang === "function") {
        try {
            text = adv.rlang(key);
        } catch (e) {
            // fallback
        }
    }
    if (!text && adv && adv.lang && adv.lang[key]) {
        const locale = adv.iso639 || "vi_VN";
        text = adv.lang[key][locale] || adv.lang[key]["en_US"];
    }
    if (!text) {
        text = fallback || "";
    }
    if (adv && typeof adv.replaceMap === "function" && map) {
        try {
            return adv.replaceMap(text, map);
        } catch (e) {
            // fallback
        }
    }
    if (map) {
        for (let k in map) {
            text = text.split(k).join(map[k]);
        }
    }
    return text;
}

function getLocalizedRarity(adv, rarity) {
    const raw = t(adv, "rarityNames", null, "common=common|uncommon=uncommon|rare=rare|epic=epic|legendary=legendary|mythic=mythic");
    const pairs = raw.split("|");
    for (let p of pairs) {
        const parts = p.split("=");
        if (parts[0] === rarity) return parts[1];
    }
    return rarity;
}

function getLocalizedItemName(adv, itemId) {
    const raw = t(adv, "itemNames", null, "bait=Bait|lucky_charm=Lucky Charm|trap=Double Trap|lootbox_common=Common Box|lootbox_rare=Rare Box|lootbox_epic=Epic Box");
    const pairs = raw.split("|");
    for (let p of pairs) {
        const parts = p.split("=");
        if (parts[0] === itemId) return parts[1];
    }
    return itemId;
}

function getLocalizedItemDesc(adv, itemId) {
    const raw = t(adv, "itemDescriptions", null, "bait=Slightly improves hunt quality.|lucky_charm=Slightly increases rare pet chance.|trap=Adds one extra pet to the next hunt.|lootbox_common=Open for coins, shards, or common/uncommon weapons.|lootbox_rare=Open for coins, shards, or uncommon/rare/epic weapons.|lootbox_epic=Open for coins, shards, or high-tier weapons.");
    const pairs = raw.split("|");
    for (let p of pairs) {
        const parts = p.split("=");
        if (parts[0] === itemId) return parts[1];
    }
    return "";
}

// Economy Integration helpers
function ensureEconomyUser(userID) {
    if (!global.data) global.data = {};
    if (!global.data.economy) global.data.economy = {};
    if (!global.data.economy[userID]) {
        global.data.economy[userID] = { coin: 0 };
    }
    if (typeof global.data.economy[userID].coin !== "number") {
        global.data.economy[userID].coin = Number(global.data.economy[userID].coin) || 0;
    }
}

function getBalance(userID) {
    ensureEconomyUser(userID);
    return global.data.economy[userID].coin;
}

function addMoney(userID, amount) {
    if (typeof amount !== "number" || !isFinite(amount) || amount <= 0) return false;
    ensureEconomyUser(userID);
    global.data.economy[userID].coin += Math.floor(amount);
    return true;
}

function removeMoney(userID, amount) {
    if (typeof amount !== "number" || !isFinite(amount) || amount <= 0) return false;
    ensureEconomyUser(userID);
    if (global.data.economy[userID].coin < amount) return false;
    global.data.economy[userID].coin -= Math.floor(amount);
    return true;
}

function canAfford(userID, amount) {
    if (typeof amount !== "number" || !isFinite(amount) || amount < 0) return false;
    ensureEconomyUser(userID);
    return global.data.economy[userID].coin >= amount;
}

function moneyIcon() {
    return (global.data.economyConfig && global.data.economyConfig.icon) || "💰";
}

function formatMoney(amount) {
    return amount + moneyIcon();
}

function getArgs(data) {
    if (data && Array.isArray(data.args)) {
        return data.args.slice(1);
    }
    if (data && typeof data.body === "string" && data.body.trim()) {
        return data.body.trim().split(/\s+/);
    }
    return [];
}

function getPrefix() {
    return (global.config && global.config.facebook && global.config.facebook.prefix) || "/";
}

function secondsLeft(lastTime, cooldownSeconds) {
    const elapsed = Math.floor((Date.now() - lastTime) / 1000);
    return Math.max(0, cooldownSeconds - elapsed);
}

const LEVEL_CONFIG = {
    maxLevel: 100,
    baseExp: 100,
    growth: 1.18
};

function getExpRequiredForLevel(level) {
    return Math.floor(LEVEL_CONFIG.baseExp * Math.pow(LEVEL_CONFIG.growth, level - 1));
}

function addPetExp(pet, amount) {
    const oldLevel = pet.level || 1;
    let newLevel = oldLevel;
    let expGained = amount;
    let leveledUp = false;

    if (newLevel >= LEVEL_CONFIG.maxLevel) {
        pet.level = LEVEL_CONFIG.maxLevel;
        pet.exp = 0;
        return {
            oldLevel,
            newLevel,
            expGained,
            leveledUp: false,
            levelsGained: 0
        };
    }

    let currentExp = (pet.exp || 0) + amount;

    while (newLevel < LEVEL_CONFIG.maxLevel) {
        const req = getExpRequiredForLevel(newLevel);
        if (currentExp >= req) {
            currentExp -= req;
            newLevel++;
            leveledUp = true;
        } else {
            break;
        }
    }

    if (newLevel >= LEVEL_CONFIG.maxLevel) {
        newLevel = LEVEL_CONFIG.maxLevel;
        currentExp = 0;
    }

    pet.level = newLevel;
    pet.exp = currentExp;

    return {
        oldLevel,
        newLevel,
        expGained,
        leveledUp,
        levelsGained: newLevel - oldLevel
    };
}

// Hunt Storage helpers
function migrateHuntData() {
    if (!global.data) global.data = {};
    if (!global.data.hunt) {
        global.data.hunt = {
            players: {},
            pets: {},
            weapons: {},
            nextPetId: 1,
            nextWeaponId: 1
        };
    }
    if (!global.data.hunt.players) global.data.hunt.players = {};
    if (!global.data.hunt.pets) global.data.hunt.pets = {};
    if (!global.data.hunt.weapons) global.data.hunt.weapons = {};
    if (!global.data.hunt.nextPetId) global.data.hunt.nextPetId = 1;
    if (!global.data.hunt.nextWeaponId) {
        let maxId = 0;
        for (let wid in global.data.hunt.weapons) {
            const idNum = parseInt(wid, 10);
            if (!isNaN(idNum) && idNum > maxId) maxId = idNum;
        }
        global.data.hunt.nextWeaponId = maxId + 1;
    }

    // Migrate pets
    for (let petId in global.data.hunt.pets) {
        const pet = global.data.hunt.pets[petId];
        if (!pet) continue;
        if (pet.locked === undefined) pet.locked = false;
        if (pet.level === undefined || typeof pet.level !== "number" || isNaN(pet.level)) pet.level = 1;
        if (pet.exp === undefined || typeof pet.exp !== "number" || isNaN(pet.exp)) pet.exp = 0;
        if (pet.nickname === undefined) pet.nickname = "";
        if (!pet.battleStats) {
            pet.battleStats = { wins: 0, losses: 0 };
        }
        if (pet.battleStats.wins === undefined) pet.battleStats.wins = 0;
        if (pet.battleStats.losses === undefined) pet.battleStats.losses = 0;
        if (pet.equippedWeaponId === undefined) pet.equippedWeaponId = null;

        // Clean stale equipped weapon ID
        if (pet.equippedWeaponId) {
            const wep = global.data.hunt.weapons[pet.equippedWeaponId];
            if (!wep || wep.ownerID !== pet.ownerID) {
                pet.equippedWeaponId = null;
            }
        }
    }

    // Migrate players
    for (let userID in global.data.hunt.players) {
        const player = global.data.hunt.players[userID];
        if (!player) continue;
        if (!player.inventory) {
            player.inventory = {
                bait: 0, lucky_charm: 0, trap: 0,
                lootbox_common: 0, lootbox_rare: 0, lootbox_epic: 0, weapon_shard: 0
            };
        }
        if (player.inventory.bait === undefined) player.inventory.bait = 0;
        if (player.inventory.lucky_charm === undefined) player.inventory.lucky_charm = 0;
        if (player.inventory.trap === undefined) player.inventory.trap = 0;

        if (player.inventory.lootbox_common === undefined) player.inventory.lootbox_common = 0;
        if (player.inventory.lootbox_rare === undefined) player.inventory.lootbox_rare = 0;
        if (player.inventory.lootbox_epic === undefined) player.inventory.lootbox_epic = 0;
        if (player.inventory.weapon_shard === undefined) player.inventory.weapon_shard = 0;

        if (!player.petIds) player.petIds = [];
        if (!player.weaponIds) player.weaponIds = [];

        // Clean stale weapon IDs
        player.weaponIds = player.weaponIds.filter(wid => {
            const wep = global.data.hunt.weapons[wid];
            return wep && wep.ownerID === userID;
        });

        if (!player.team) player.team = [];
        if (player.team.length > 3) player.team = player.team.slice(0, 3);
        const ownedPetIds = new Set(player.petIds.map(String));
        player.team = player.team.filter(id => ownedPetIds.has(String(id)));

        if (!player.stats) {
            player.stats = { hunts: 0, battles: 0, sold: 0, wins: 0, losses: 0, boxesOpened: 0, weaponsUpgraded: 0 };
        }
        if (player.stats.hunts === undefined) player.stats.hunts = 0;
        if (player.stats.battles === undefined) player.stats.battles = 0;
        if (player.stats.sold === undefined) player.stats.sold = 0;
        if (player.stats.wins === undefined) player.stats.wins = 0;
        if (player.stats.losses === undefined) player.stats.losses = 0;
        if (player.stats.boxesOpened === undefined) player.stats.boxesOpened = 0;
        if (player.stats.weaponsUpgraded === undefined) player.stats.weaponsUpgraded = 0;

        if (!player.cooldowns) player.cooldowns = { hunt: 0, battle: 0 };
        if (player.cooldowns.hunt === undefined) player.cooldowns.hunt = 0;
        if (player.cooldowns.battle === undefined) player.cooldowns.battle = 0;
    }
}

function ensureHuntPlayer(userID) {
    migrateHuntData();
    if (!global.data.hunt.players[userID]) {
        global.data.hunt.players[userID] = {
            inventory: {
                bait: 0,
                lucky_charm: 0,
                trap: 0,
                lootbox_common: 0,
                lootbox_rare: 0,
                lootbox_epic: 0,
                weapon_shard: 0
            },
            petIds: [],
            weaponIds: [],
            team: [],
            stats: {
                hunts: 0,
                battles: 0,
                sold: 0,
                wins: 0,
                losses: 0,
                boxesOpened: 0,
                weaponsUpgraded: 0
            },
            cooldowns: {
                hunt: 0,
                battle: 0
            }
        };
    }
    const player = global.data.hunt.players[userID];
    if (!player.inventory) {
        player.inventory = {
            bait: 0, lucky_charm: 0, trap: 0,
            lootbox_common: 0, lootbox_rare: 0, lootbox_epic: 0, weapon_shard: 0
        };
    }
    if (player.inventory.lootbox_common === undefined) player.inventory.lootbox_common = 0;
    if (player.inventory.lootbox_rare === undefined) player.inventory.lootbox_rare = 0;
    if (player.inventory.lootbox_epic === undefined) player.inventory.lootbox_epic = 0;
    if (player.inventory.weapon_shard === undefined) player.inventory.weapon_shard = 0;
    if (!player.weaponIds) player.weaponIds = [];
    if (!player.stats) {
        player.stats = { hunts: 0, battles: 0, sold: 0, wins: 0, losses: 0, boxesOpened: 0, weaponsUpgraded: 0 };
    }
    if (player.stats.boxesOpened === undefined) player.stats.boxesOpened = 0;
    if (player.stats.weaponsUpgraded === undefined) player.stats.weaponsUpgraded = 0;
    return player;
}

// Utility functions
function clampInt(value, min, max, fallback) {
    const parsed = parseInt(value, 10);
    if (isNaN(parsed)) return fallback;
    return Math.max(min, Math.min(max, parsed));
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function weightedPick(entries) {
    let total = 0;
    for (let k in entries) total += entries[k];
    let r = Math.random() * total;
    for (let k in entries) {
        r -= entries[k];
        if (r <= 0) return k;
    }
    return Object.keys(entries)[0];
}

function rarityRank(rarity) {
    const ranks = {
        common: 1,
        uncommon: 2,
        rare: 3,
        epic: 4,
        legendary: 5,
        mythic: 6
    };
    return ranks[rarity] || 0;
}

function getBestPet(player) {
    if (!player || !player.petIds || player.petIds.length === 0) return null;
    const pets = player.petIds.map(id => global.data.hunt.pets[id]).filter(Boolean);
    if (pets.length === 0) return null;

    pets.sort((a, b) => {
        const rankA = rarityRank(a.rarity);
        const rankB = rarityRank(b.rarity);
        if (rankA !== rankB) return rankB - rankA;
        return b.sellPrice - a.sellPrice;
    });
    return pets[0];
}

function getPetDisplayName(pet) {
    if (pet.nickname && pet.nickname.trim()) {
        return pet.nickname.trim();
    }
    return pet.name;
}

function chooseRarity(hasLuckyCharm, teamRareBonus = 0) {
    let weights = {
        common: 60,
        uncommon: 25,
        rare: 10,
        epic: 4,
        legendary: 0.9,
        mythic: 0.1
    };
    if (hasLuckyCharm) {
        weights = {
            common: 60,
            uncommon: 25,
            rare: 15,
            epic: 8,
            legendary: 2.7,
            mythic: 0.5
        };
    }

    if (teamRareBonus > 0) {
        const bonus = Math.min(5, teamRareBonus);
        weights.common = Math.max(10, weights.common - bonus);
        weights.rare += bonus * 0.5;
        weights.epic += bonus * 0.3;
        weights.legendary += bonus * 0.15;
        weights.mythic += bonus * 0.05;
    }

    return weightedPick(weights);
}

function generatePet(rarity, hasBait, ownerID) {
    let actualRarity = rarity;
    if (hasBait) {
        if (rarity === "common" && Math.random() < 0.5) {
            actualRarity = "uncommon";
        } else if (rarity === "uncommon" && Math.random() < 0.3) {
            actualRarity = "rare";
        }
    }

    const speciesList = SPECIES[actualRarity];
    const spec = speciesList[randomInt(0, speciesList.length - 1)];
    const priceRange = PRICE_RANGES[actualRarity];
    const sellPrice = randomInt(priceRange[0], priceRange[1]);

    const petId = global.data.hunt.nextPetId++;
    const pet = {
        id: petId,
        ownerID: ownerID,
        speciesId: spec.name,
        name: spec.name,
        emoji: spec.emoji,
        rarity: actualRarity,
        sellPrice: sellPrice,
        caughtAt: Date.now(),
        locked: false,
        level: 1,
        exp: 0,
        nickname: "",
        battleStats: {
            wins: 0,
            losses: 0
        },
        equippedWeaponId: null
    };

    global.data.hunt.pets[petId] = pet;
    return pet;
}

// Phase 3 Weapon System Configurations
const WEAPON_TYPES = {
    claw: {
        emoji: "🗡️",
        viName: "Móng vuốt",
        enName: "Claw",
        statFocus: "attack"
    },
    shield: {
        emoji: "🛡️",
        viName: "Khiên",
        enName: "Shield",
        statFocus: "defense"
    },
    fang: {
        emoji: "🦷",
        viName: "Nanh",
        enName: "Fang",
        statFocus: "crit"
    },
    charm: {
        emoji: "🔮",
        viName: "Bùa",
        enName: "Charm",
        statFocus: "bonus"
    }
};

const WEAPON_RARITY_CONFIG = {
    common: {
        weight: 55,
        attack: [1, 3],
        defense: [1, 2],
        crit: [0, 1],
        coin: [0, 2],
        rare: [0, 0]
    },
    uncommon: {
        weight: 25,
        attack: [3, 6],
        defense: [2, 4],
        crit: [1, 2],
        coin: [1, 4],
        rare: [0, 1]
    },
    rare: {
        weight: 12,
        attack: [6, 10],
        defense: [4, 7],
        crit: [2, 4],
        coin: [3, 7],
        rare: [1, 2]
    },
    epic: {
        weight: 6,
        attack: [10, 16],
        defense: [7, 11],
        crit: [4, 7],
        coin: [6, 12],
        rare: [2, 4]
    },
    legendary: {
        weight: 1.8,
        attack: [16, 25],
        defense: [11, 18],
        crit: [7, 11],
        coin: [10, 18],
        rare: [4, 7]
    },
    mythic: {
        weight: 0.2,
        attack: [25, 40],
        defense: [18, 30],
        crit: [11, 18],
        coin: [18, 30],
        rare: [7, 12]
    }
};

const LOOTBOX_ITEMS = {
    lootbox_common: {
        price: 1200,
        viName: "Hộp thường",
        enName: "Common Box"
    },
    lootbox_rare: {
        price: 3500,
        viName: "Hộp hiếm",
        enName: "Rare Box"
    },
    lootbox_epic: {
        price: 9000,
        viName: "Hộp sử thi",
        enName: "Epic Box"
    }
};

// Expand SHOP_ITEMS
const SHOP_ITEMS = {
    bait: {
        name: "Mồi thơm",
        price: 300,
        desc: "Tăng nhẹ chất lượng thú bắt được."
    },
    lucky_charm: {
        name: "Bùa may mắn",
        price: 800,
        desc: "Tăng nhẹ tỉ lệ thú hiếm."
    },
    trap: {
        name: "Bẫy đôi",
        price: 1200,
        desc: "Lần hunt tiếp theo bắt thêm 1 thú."
    },
    lootbox_common: {
        name: "Hộp thường",
        price: 1200,
        desc: "Mở nhận vàng, mảnh hoặc vũ khí thường/uncommon."
    },
    lootbox_rare: {
        name: "Hộp hiếm",
        price: 3500,
        desc: "Mở nhận vàng, mảnh hoặc vũ khí uncommon/rare/epic."
    },
    lootbox_epic: {
        name: "Hộp sử thi",
        price: 9000,
        desc: "Mở nhận vàng, mảnh hoặc vũ khí rare/epic/legendary/mythic."
    }
};

function generateWeapon(rarity, ownerID) {
    const typeKeys = Object.keys(WEAPON_TYPES);
    const typeKey = typeKeys[randomInt(0, typeKeys.length - 1)];
    const typeObj = WEAPON_TYPES[typeKey];

    const rarityConfig = WEAPON_RARITY_CONFIG[rarity];

    let attack = randomInt(rarityConfig.attack[0], rarityConfig.attack[1]);
    let defense = randomInt(rarityConfig.defense[0], rarityConfig.defense[1]);
    let crit = randomInt(rarityConfig.crit[0], rarityConfig.crit[1]);
    let coin = randomInt(rarityConfig.coin[0], rarityConfig.coin[1]);
    let rare = randomInt(rarityConfig.rare[0], rarityConfig.rare[1]);

    if (typeObj.statFocus === "attack") attack = Math.ceil(attack * 1.3);
    else if (typeObj.statFocus === "defense") defense = Math.ceil(defense * 1.3);
    else if (typeObj.statFocus === "crit") crit = Math.ceil(crit * 1.3);
    else if (typeObj.statFocus === "bonus") {
        coin = Math.ceil(coin * 1.3);
        if (rare > 0) rare = Math.ceil(rare * 1.3);
    }

    const wepId = global.data.hunt.nextWeaponId++;
    const weapon = {
        id: wepId,
        ownerID,
        type: typeKey,
        name: typeObj.enName,
        emoji: typeObj.emoji,
        rarity,
        level: 1,
        exp: 0,
        attackBonus: attack,
        defenseBonus: defense,
        critBonus: crit,
        coinBonus: coin,
        rareBonus: rare,
        createdAt: Date.now(),
        locked: false
    };

    global.data.hunt.weapons[wepId] = weapon;
    return weapon;
}

function getLocalizedWeaponType(adv, typeKey) {
    const typeObj = WEAPON_TYPES[typeKey];
    if (!typeObj) return typeKey;
    const locale = (adv && adv.iso639) || "vi_VN";
    return locale === "vi_VN" ? typeObj.viName : typeObj.enName;
}

function getWeaponSellPrice(w) {
    const basePrices = {
        common: 200,
        uncommon: 500,
        rare: 1200,
        epic: 3000,
        legendary: 8000,
        mythic: 20000
    };
    const base = basePrices[w.rarity] || 200;
    return Math.floor(base + w.level * base * 0.08);
}

function formatWeaponStatsShort(w) {
    const parts = [];
    if (w.attackBonus) parts.push(`ATK +${w.attackBonus}`);
    if (w.defenseBonus) parts.push(`DEF +${w.defenseBonus}`);
    if (w.critBonus) parts.push(`CRIT +${w.critBonus}%`);
    if (w.coinBonus) parts.push(`COIN +${w.coinBonus}%`);
    if (w.rareBonus) parts.push(`RARE +${w.rareBonus}%`);
    return parts.length > 0 ? parts.join(", ") : "None";
}

// Commands Implementation
function checkEconomy(data, api, adv) {
    if (!global.data || !global.data.economy) {
        safeReply(data, api, adv, t(adv, "economyMissing", null, "Plugin Economy chưa được cài đặt nên không thể sử dụng tính năng săn thú."));
        return false;
    }
    return true;
}

function hunt(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    if (String(args[1] || "").toLowerCase() === "help") {
        return hunthelp(data, api, e2ee, adv);
    }

    const player = ensureHuntPlayer(data.senderID);
    const nowTime = Date.now();
    const lastTime = player.cooldowns.hunt || 0;
    const cooldownLeft = secondsLeft(lastTime, 15);

    if (cooldownLeft > 0) {
        return safeReply(data, api, adv, t(adv, "huntCooldown", { "{seconds}": String(cooldownLeft) }, `❌ Vui lòng chờ ${cooldownLeft}s trước khi săn tiếp.`));
    }

    player.cooldowns.hunt = nowTime;

    let hasTrap = false;
    let hasBait = false;
    let hasLuckyCharm = false;

    if (player.inventory.trap > 0) {
        player.inventory.trap--;
        hasTrap = true;
    }
    if (player.inventory.bait > 0) {
        player.inventory.bait--;
        hasBait = true;
    }
    if (player.inventory.lucky_charm > 0) {
        player.inventory.lucky_charm--;
        hasLuckyCharm = true;
    }

    let teamRareBonus = 0;
    if (Array.isArray(player.team) && player.team.length > 0) {
        const ownedSet = new Set(player.petIds.map(String));
        const teamPets = player.team.map(id => global.data.hunt.pets[id]).filter(p => p && ownedSet.has(String(p.id)));
        for (let p of teamPets) {
            if (p.equippedWeaponId) {
                const w = global.data.hunt.weapons[p.equippedWeaponId];
                if (w) {
                    teamRareBonus += w.rareBonus || 0;
                }
            }
        }
    }

    safeReply(data, api, adv, t(adv, "huntSearching", null, "🐾 Đang tìm kiếm thú..."), (err, info) => {
        setTimeout(() => {
            const caught = [];
            const rarity1 = chooseRarity(hasLuckyCharm, teamRareBonus);
            const pet1 = generatePet(rarity1, hasBait, data.senderID);
            caught.push(pet1);
            player.petIds.push(pet1.id);

            if (hasTrap) {
                const rarity2 = chooseRarity(hasLuckyCharm, teamRareBonus);
                const pet2 = generatePet(rarity2, hasBait, data.senderID);
                caught.push(pet2);
                player.petIds.push(pet2.id);
            }

            let bonus = Math.random() < 0.4 ? randomInt(20, 100) : 0;
            if (bonus > 0) {
                addMoney(data.senderID, bonus);
            }

            player.stats.hunts++;

            const petText = caught.map(p => `#${p.id} ${p.emoji} ${p.name} [${getLocalizedRarity(adv, p.rarity)}] - Giá bán: ${formatMoney(p.sellPrice)}`).join("\n");
            
            let resultText = "";
            if (bonus > 0) {
                resultText = t(adv, "huntResult", {
                    "{pets}": petText,
                    "{bonus}": formatMoney(bonus),
                    "{balance}": formatMoney(getBalance(data.senderID))
                }, "🐾 Bạn đã săn được:\n{pets}\n\nTiền thưởng: {bonus}\nSố dư: {balance}");
            } else {
                resultText = t(adv, "huntResultNoBonus", {
                    "{pets}": petText,
                    "{balance}": formatMoney(getBalance(data.senderID))
                }, "🐾 Bạn đã săn được:\n{pets}\n\nSố dư: {balance}");
            }

            let msgID = null;
            if (info) {
                if (typeof info === "string") msgID = info;
                else if (info.messageID) msgID = info.messageID;
                else if (info.messageId) msgID = info.messageId;
            }

            safeEdit(api, adv, msgID, resultText, data);
        }, 1700);
    });
}

function zoo(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const petIds = player.petIds || [];
    const pets = petIds.map(id => global.data.hunt.pets[id]).filter(Boolean);

    if (pets.length === 0) {
        return safeReply(data, api, adv, t(adv, "zooEmpty", { "{prefix}": getPrefix() }, `🦴 Bạn chưa có thú nào. Dùng ${getPrefix()}hunt để bắt thú đầu tiên.`));
    }

    pets.sort((a, b) => a.id - b.id);

    const args = getArgs(data);
    let page = 1;
    if (args[1] !== undefined) {
        page = parseInt(args[1], 10);
        if (isNaN(page) || page < 1) page = 1;
    }

    const totalPages = Math.ceil(pets.length / 10);
    if (page > totalPages) page = totalPages;
    if (page < 1) page = 1;

    const start = (page - 1) * 10;
    const pagePets = pets.slice(start, start + 10);

    const listText = pagePets.map(p => {
        const lockText = p.locked ? "🔒 " : "";
        const weaponMarker = p.equippedWeaponId ? "⚔️ " : "";
        const displayName = getPetDisplayName(p);
        return t(adv, "zooLine", {
            "{id}": String(p.id),
            "{lock}": lockText + weaponMarker,
            "{emoji}": p.emoji,
            "{name}": displayName,
            "{rarity}": getLocalizedRarity(adv, p.rarity),
            "{level}": String(p.level || 1),
            "{price}": formatMoney(p.sellPrice)
        }, `#{id} ${lockText}${weaponMarker}${p.emoji} ${displayName} [${getLocalizedRarity(adv, p.rarity)}] - Cấp ${p.level || 1} - bán ${formatMoney(p.sellPrice)}`);
    }).join("\n");

    const header = t(adv, "zooHeader", {
        "{page}": String(page),
        "{totalPages}": String(totalPages),
        "{total}": String(pets.length)
    }, "🐾 Vườn thú của bạn - Trang {page}/{totalPages}\nTổng số: {total} thú");

    const footer = t(adv, "zooFooter", { "{prefix}": getPrefix() }, `Dùng ${getPrefix()}zoo <trang> để xem trang khác.`);

    const resultText = `${header}\n${listText}\n\n${footer}`;
    safeReply(data, api, adv, resultText);
}

function sellpet(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    if (args[1] === undefined) {
        return safeReply(data, api, adv, t(adv, "sellUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}sellpet <id|all>`));
    }

    const player = ensureHuntPlayer(data.senderID);
    const target = args[1].trim().toLowerCase();

    if (target === "all") {
        const petIds = player.petIds || [];
        const pets = petIds.map(id => global.data.hunt.pets[id]).filter(Boolean);
        const unlockedPets = pets.filter(p => !p.locked);

        if (unlockedPets.length === 0) {
            return safeReply(data, api, adv, t(adv, "sellAllNoPets", null, "Bạn không có thú nào có thể bán."));
        }

        let totalEarned = 0;
        const soldIds = new Set(unlockedPets.map(p => String(p.id)));
        for (let p of unlockedPets) {
            totalEarned += p.sellPrice;
            if (p.equippedWeaponId) {
                p.equippedWeaponId = null;
            }
            delete global.data.hunt.pets[p.id];
            player.stats.sold++;
        }

        player.petIds = pets.filter(p => p.locked).map(p => p.id);
        if (player.team) {
            player.team = player.team.filter(id => !soldIds.has(String(id)));
        }
        addMoney(data.senderID, totalEarned);

        return safeReply(data, api, adv, t(adv, "sellAllSuccess", {
            "{count}": String(unlockedPets.length),
            "{total}": formatMoney(totalEarned),
            "{balance}": formatMoney(getBalance(data.senderID))
        }, `💸 Đã bán {count} thú và nhận {total}.\nSố dư hiện tại: {balance}`));
    } else {
        const petId = parseInt(target, 10);
        if (isNaN(petId) || petId <= 0) {
            return safeReply(data, api, adv, t(adv, "sellInvalidPet", { "{id}": target }, `Không tìm thấy thú #{id}.`));
        }

        const pet = global.data.hunt.pets[petId];
        if (!pet || pet.ownerID !== data.senderID) {
            return safeReply(data, api, adv, t(adv, "sellNotOwner", { "{id}": String(petId) }, `Bạn không sở hữu thú #{id}.`));
        }

        if (pet.locked) {
            return safeReply(data, api, adv, t(adv, "sellLocked", { "{id}": String(petId) }, `Thú #{id} đang bị khóa nên không thể bán.`));
        }

        const price = pet.sellPrice;
        if (pet.equippedWeaponId) {
            pet.equippedWeaponId = null;
        }

        addMoney(data.senderID, price);
        player.stats.sold++;

        player.petIds = player.petIds.filter(id => id !== petId);
        if (player.team) {
            player.team = player.team.filter(id => String(id) !== String(petId));
        }
        delete global.data.hunt.pets[petId];

        return safeReply(data, api, adv, t(adv, "sellOneSuccess", {
            "{id}": String(pet.id),
            "{emoji}": pet.emoji,
            "{name}": pet.name,
            "{price}": formatMoney(price),
            "{balance}": formatMoney(getBalance(data.senderID))
        }, `💸 Đã bán #{id} {emoji} {name} với giá {price}.\nSố dư hiện tại: {balance}`));
    }
}

function huntinv(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const invText = t(adv, "inventory", {
        "{baitName}": getLocalizedItemName(adv, "bait"),
        "{bait}": String(player.inventory.bait),
        "{luckyName}": getLocalizedItemName(adv, "lucky_charm"),
        "{lucky}": String(player.inventory.lucky_charm),
        "{trapName}": getLocalizedItemName(adv, "trap"),
        "{trap}": String(player.inventory.trap)
    }, "🎒 Túi đồ săn thú của bạn:\n- {baitName}: {bait}\n- {luckyName}: {lucky}\n- {trapName}: {trap}");

    safeReply(data, api, adv, invText);
}

function huntshop(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    let shopText = t(adv, "shopHeader", null, "🛒 Cửa hàng săn thú:") + "\n";
    for (let k in SHOP_ITEMS) {
        const item = SHOP_ITEMS[k];
        shopText += t(adv, "shopLine", {
            "{id}": k,
            "{name}": getLocalizedItemName(adv, k),
            "{price}": formatMoney(item.price),
            "{desc}": getLocalizedItemDesc(adv, k)
        }, "- {id}: {name} - {price}\n  {desc}") + "\n";
    }
    shopText += `\nGõ ${getPrefix()}huntbuy <itemId> [số lượng] để mua.`;
    safeReply(data, api, adv, shopText);
}

function huntbuy(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const itemId = args[1];
    if (!itemId || !SHOP_ITEMS[itemId]) {
        return safeReply(data, api, adv, t(adv, "buyInvalidItem", { "{itemId}": String(itemId) }, `Vật phẩm \`{itemId}\` không tồn tại trong cửa hàng.`));
    }

    let qty = 1;
    if (args[2] !== undefined) {
        qty = parseInt(args[2], 10);
        if (isNaN(qty) || qty < 1 || qty > 20) {
            return safeReply(data, api, adv, t(adv, "buyInvalidQuantity", null, "Số lượng phải là số nguyên từ 1 đến 20."));
        }
    }

    const item = SHOP_ITEMS[itemId];
    const totalCost = item.price * qty;

    if (!canAfford(data.senderID, totalCost)) {
        const missing = totalCost - getBalance(data.senderID);
        return safeReply(data, api, adv, t(adv, "buyNoMoney", { "{missing}": formatMoney(missing) }, `Bạn không đủ tiền. Còn thiếu {missing}.`));
    }

    removeMoney(data.senderID, totalCost);
    const player = ensureHuntPlayer(data.senderID);
    player.inventory[itemId] = (player.inventory[itemId] || 0) + qty;

    safeReply(data, api, adv, t(adv, "buySuccess", {
        "{quantity}": String(qty),
        "{name}": getLocalizedItemName(adv, itemId),
        "{total}": formatMoney(totalCost),
        "{balance}": formatMoney(getBalance(data.senderID))
    }, `✅ Đã mua {quantity}x {name} với giá {total}.\nSố dư: {balance}`));
}

function petbattle(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    let battlePets = [];
    if (Array.isArray(player.team) && player.team.length > 0) {
        const ownedSet = new Set(player.petIds.map(String));
        battlePets = player.team.map(id => global.data.hunt.pets[id]).filter(p => p && ownedSet.has(String(p.id)));
    }

    if (battlePets.length === 0) {
        const bestPet = getBestPet(player);
        if (bestPet) {
            battlePets = [bestPet];
        }
    }

    if (battlePets.length === 0) {
        return safeReply(data, api, adv, t(adv, "battleNoPet", { "{prefix}": getPrefix() }, `Bạn chưa có thú nào để chiến đấu. Dùng ${getPrefix()}hunt để bắt thú trước.`));
    }

    const nowTime = Date.now();
    const lastTime = player.cooldowns.battle || 0;
    const cooldownLeft = secondsLeft(lastTime, 60);

    if (cooldownLeft > 0) {
        return safeReply(data, api, adv, t(adv, "battleCooldown", { "{seconds}": String(cooldownLeft) }, `⚔️ Vui lòng chờ ${cooldownLeft}s trước khi chiến đấu tiếp.`));
    }

    player.cooldowns.battle = nowTime;
    player.stats.battles++;

    const rarityChances = {
        common: 45,
        uncommon: 50,
        rare: 58,
        epic: 65,
        legendary: 75,
        mythic: 85
    };

    let bestParticipatingPet = battlePets[0];
    let maxBaseChance = rarityChances[bestParticipatingPet.rarity] || 45;
    for (let p of battlePets) {
        const chance = rarityChances[p.rarity] || 45;
        if (chance > maxBaseChance) {
            maxBaseChance = chance;
            bestParticipatingPet = p;
        }
    }

    const levelBonus = Math.min(10, Math.floor(bestParticipatingPet.level / 10));
    const teamBonus = battlePets.length === 2 ? 3 : (battlePets.length === 3 ? 5 : 0);

    let totalAttackBonus = 0;
    let totalDefenseBonus = 0;
    let totalRareBonus = 0;
    let totalCritBonus = 0;
    let totalCoinBonus = 0;

    for (let p of battlePets) {
        if (p.equippedWeaponId) {
            const w = global.data.hunt.weapons[p.equippedWeaponId];
            if (w) {
                totalAttackBonus += w.attackBonus || 0;
                totalDefenseBonus += w.defenseBonus || 0;
                totalRareBonus += w.rareBonus || 0;
                totalCritBonus += w.critBonus || 0;
                totalCoinBonus += w.coinBonus || 0;
            }
        }
    }

    const weaponAttackBonus = Math.floor(totalAttackBonus / 5);
    const weaponDefenseBonus = Math.floor(totalDefenseBonus / 8);
    const weaponRareBonusSmall = Math.floor(totalRareBonus / 10);

    const winChancePercent = Math.max(5, Math.min(95, maxBaseChance + levelBonus + teamBonus + weaponAttackBonus + weaponDefenseBonus + weaponRareBonusSmall));
    const isWin = Math.random() < (winChancePercent / 100);

    const expAmount = isWin ? randomInt(35, 60) : randomInt(10, 25);
    let levelUpLines = "";
    for (let p of battlePets) {
        const res = addPetExp(p, expAmount);
        if (res.leveledUp) {
            levelUpLines += "\n" + t(adv, "petLevelUpLine", {
                "{name}": getPetDisplayName(p),
                "{level}": String(p.level)
            }, `🎉 ${getPetDisplayName(p)} đã lên cấp ${p.level}!`);
        }
        if (isWin) {
            p.battleStats.wins = (p.battleStats.wins || 0) + 1;
        } else {
            p.battleStats.losses = (p.battleStats.losses || 0) + 1;
        }
    }

    const partText = battlePets.map(p => {
        const displayName = getPetDisplayName(p);
        const rarityName = getLocalizedRarity(adv, p.rarity);
        let weaponInfoStr = "";
        if (p.equippedWeaponId) {
            const w = global.data.hunt.weapons[p.equippedWeaponId];
            if (w) {
                weaponInfoStr = ` [${w.emoji} Lvl ${w.level}]`;
            }
        }
        return `#${p.id} ${p.emoji} ${displayName} [${rarityName}] - Cấp ${p.level}${weaponInfoStr}`;
    }).join("\n");

    const participantsText = t(adv, "battleParticipants", { "{pets}": partText }, `Tham chiến:\n${partText}`);
    const expLineText = t(adv, "battleExpGain", { "{exp}": String(expAmount) }, `EXP nhận được: ${expAmount}`);

    if (isWin) {
        player.stats.wins = (player.stats.wins || 0) + 1;

        const rewards = {
            common: [100, 200],
            uncommon: [200, 350],
            rare: [400, 700],
            epic: [800, 1300],
            legendary: [2000, 3500],
            mythic: [5000, 9000]
        };
        const range = rewards[bestParticipatingPet.rarity] || [100, 200];
        let reward = randomInt(range[0], range[1]);

        if (totalCoinBonus > 0) {
            reward += Math.floor(reward * totalCoinBonus / 100);
        }

        let isCrit = false;
        const critChance = Math.min(35, totalCritBonus);
        if (critChance > 0 && Math.random() * 100 < critChance) {
            reward = Math.floor(reward * 1.5);
            isCrit = true;
        }

        const critText = isCrit ? ("\n" + t(adv, "critRewardLine", null, "💥 Chí mạng! Thưởng tiền được x1.5!")) : "";

        addMoney(data.senderID, reward);

        return safeReply(data, api, adv, t(adv, "battleTeamWin", {
            "{participants}": participantsText,
            "{expLine}": expLineText,
            "{reward}": formatMoney(reward),
            "{balance}": formatMoney(getBalance(data.senderID)),
            "{levelUps}": levelUpLines
        }, `⚔️ Đội hình của bạn đã thắng trận!\n\n${participantsText}\n\n${expLineText}\nPhần thưởng: ${formatMoney(reward)}${critText}\nSố dư: ${formatMoney(getBalance(data.senderID))}${levelUpLines}`));
    } else {
        player.stats.losses = (player.stats.losses || 0) + 1;

        return safeReply(data, api, adv, t(adv, "battleTeamLose", {
            "{participants}": participantsText,
            "{expLine}": expLineText,
            "{levelUps}": levelUpLines
        }, `⚔️ Đội hình của bạn đã thua trận.\n\n${participantsText}\n\n${expLineText}\nBạn không mất tiền.${levelUpLines}`));
    }
}

function petinfo(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petIdArg = args[1];
    if (!petIdArg) {
        return safeReply(data, api, adv, t(adv, "petInfoUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petinfo <petId>`));
    }

    const petId = parseInt(petIdArg, 10);
    if (isNaN(petId) || petId <= 0) {
        return safeReply(data, api, adv, t(adv, "petInfoNotFound", { "{id}": petIdArg }, `Không tìm thấy thú #{id}.`));
    }

    const player = ensureHuntPlayer(data.senderID);
    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "petInfoNotOwner", { "{id}": String(petId) }, `Bạn không sở hữu thú #{id}.`));
    }

    const reqExp = getExpRequiredForLevel(pet.level || 1);
    const displayName = getPetDisplayName(pet);
    const inTeam = (player.team || []).map(String).includes(String(pet.id))
        ? t(adv, "yesLabel", null, "Có")
        : t(adv, "noLabel", null, "Không");
    const lockStatus = pet.locked
        ? t(adv, "lockedLabel", null, "Đã khóa")
        : t(adv, "unlockedLabel", null, "Chưa khóa");

    let equippedWeaponStr = t(adv, "noneLabel", null, "Không có");
    if (pet.equippedWeaponId) {
        const w = global.data.hunt.weapons[pet.equippedWeaponId];
        if (w) {
            const stats = formatWeaponStatsShort(w);
            equippedWeaponStr = t(adv, "equippedWeaponLabel", {
                "{weaponName}": `${w.emoji} ${getLocalizedWeaponType(adv, w.type)}`,
                "{level}": String(w.level),
                "{stats}": stats
            }, `Vũ khí: {weaponName} [Cấp {level}] ({stats})`);
        }
    }

    const infoText = t(adv, "petInfo", {
        "{id}": String(pet.id),
        "{emoji}": pet.emoji,
        "{name}": displayName,
        "{speciesName}": pet.name,
        "{rarity}": getLocalizedRarity(adv, pet.rarity),
        "{level}": String(pet.level || 1),
        "{exp}": String(pet.exp || 0),
        "{requiredExp}": String(reqExp),
        "{price}": formatMoney(pet.sellPrice),
        "{lockStatus}": lockStatus,
        "{wins}": String(pet.battleStats.wins || 0),
        "{losses}": String(pet.battleStats.losses || 0),
        "{inTeam}": inTeam,
        "{equippedWeapon}": equippedWeaponStr
    }, `🐾 Thông tin thú\n\n#${pet.id} ${pet.emoji} ${displayName}\nTên gốc: ${pet.name}\nĐộ hiếm: ${getLocalizedRarity(adv, pet.rarity)}\nCấp: ${pet.level || 1}\nEXP: ${pet.exp || 0}/${reqExp}\nGiá bán: ${formatMoney(pet.sellPrice)}\nTrạng thái: ${lockStatus}\nThắng/Thua: ${pet.battleStats.wins || 0}/${pet.battleStats.losses || 0}\nĐội hình: ${inTeam}\nVũ khí: ${equippedWeaponStr}`);

    safeReply(data, api, adv, infoText);
}

function petrename(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petIdArg = args[1];
    const newNameArg = args.slice(2).join(" ").trim().replace(/\s+/g, " ");

    if (!petIdArg || !newNameArg) {
        return safeReply(data, api, adv, t(adv, "petRenameUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petrename <petId> <tên mới>`));
    }

    const petId = parseInt(petIdArg, 10);
    if (isNaN(petId) || petId <= 0) {
        return safeReply(data, api, adv, t(adv, "petInfoNotFound", { "{id}": petIdArg }, `Không tìm thấy thú #{id}.`));
    }

    const player = ensureHuntPlayer(data.senderID);
    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "petInfoNotOwner", { "{id}": String(petId) }, `Bạn không sở hữu thú #{id}.`));
    }

    if (newNameArg.length < 1 || newNameArg.length > 24 || newNameArg.includes("\n") || newNameArg.includes("\r")) {
        return safeReply(data, api, adv, t(adv, "petRenameInvalidName", null, "Tên thú phải dài từ 1 đến 24 ký tự và không được chứa dòng mới."));
    }

    pet.nickname = newNameArg;
    safeReply(data, api, adv, t(adv, "petRenameSuccess", {
        "{id}": String(pet.id),
        "{name}": newNameArg
    }, `✅ Đã đổi tên thú #{id} thành {name}.`));
}

function petlock(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petIdArg = args[1];
    if (!petIdArg) {
        return safeReply(data, api, adv, t(adv, "petLockUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petlock <petId>`));
    }

    const petId = parseInt(petIdArg, 10);
    if (isNaN(petId) || petId <= 0) {
        return safeReply(data, api, adv, t(adv, "petInfoNotFound", { "{id}": petIdArg }, `Không tìm thấy thú #{id}.`));
    }

    const player = ensureHuntPlayer(data.senderID);
    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "petInfoNotOwner", { "{id}": String(petId) }, `Bạn không sở hữu thú #{id}.`));
    }

    if (pet.locked) {
        return safeReply(data, api, adv, t(adv, "petLockAlready", { "{id}": String(petId) }, `Thú #{id} đã được khóa trước đó.`));
    }

    pet.locked = true;
    safeReply(data, api, adv, t(adv, "petLockSuccess", { "{id}": String(petId) }, `🔒 Đã khóa thú #{id}. Thú này sẽ không bị bán.`));
}

function petunlock(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petIdArg = args[1];
    if (!petIdArg) {
        return safeReply(data, api, adv, t(adv, "petUnlockUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petunlock <petId>`));
    }

    const petId = parseInt(petIdArg, 10);
    if (isNaN(petId) || petId <= 0) {
        return safeReply(data, api, adv, t(adv, "petInfoNotFound", { "{id}": petIdArg }, `Không tìm thấy thú #{id}.`));
    }

    const player = ensureHuntPlayer(data.senderID);
    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "petInfoNotOwner", { "{id}": String(petId) }, `Bạn không sở hữu thú #{id}.`));
    }

    if (!pet.locked) {
        return safeReply(data, api, adv, t(adv, "petUnlockAlready", { "{id}": String(petId) }, `Thú #{id} hiện không bị khóa.`));
    }

    pet.locked = false;
    safeReply(data, api, adv, t(adv, "petUnlockSuccess", { "{id}": String(petId) }, `🔓 Đã mở khóa thú #{id}.`));
}

function petteam(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const args = getArgs(data);
    const action = args[1] ? args[1].trim().toLowerCase() : "";

    if (!action) {
        const teamIds = player.team || [];
        const teamPets = teamIds.map(id => global.data.hunt.pets[id]).filter(p => p && p.ownerID === data.senderID);
        if (teamPets.length === 0) {
            return safeReply(data, api, adv, t(adv, "petTeamEmpty", { "{prefix}": getPrefix() }, `Bạn chưa thiết lập đội hình pet. Dùng ${getPrefix()}petteam set <petId1> [petId2] [petId3].`));
        }

        const lines = teamPets.map((p, idx) => {
            const displayName = getPetDisplayName(p);
            const rarityName = getLocalizedRarity(adv, p.rarity);
            return `${idx + 1}. #${p.id} ${p.emoji} ${displayName} [${rarityName}] - Cấp ${p.level}`;
        }).join("\n");

        return safeReply(data, api, adv, t(adv, "petTeamView", { "{team}": lines }, `⚔️ Đội hình pet của bạn:\n\n{team}`));
    }

    if (action === "set") {
        const teamArgs = args.slice(2);
        if (teamArgs.length === 0) {
            return safeReply(data, api, adv, t(adv, "petTeamSetUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petteam set <petId1> [petId2] [petId3]`));
        }

        const ids = teamArgs.map(x => parseInt(x, 10)).filter(x => !isNaN(x) && x > 0);
        if (ids.length === 0 || ids.length > 3) {
            return safeReply(data, api, adv, t(adv, "petTeamSetUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petteam set <petId1> [petId2] [petId3]`));
        }

        const uniqueIds = new Set(ids);
        if (uniqueIds.size !== ids.length) {
            return safeReply(data, api, adv, t(adv, "petTeamSetDuplicate", null, "Đội hình không được chứa pet trùng nhau."));
        }

        const ownedSet = new Set(player.petIds.map(String));
        for (let id of ids) {
            const pet = global.data.hunt.pets[id];
            if (!pet || !ownedSet.has(String(id)) || pet.ownerID !== data.senderID) {
                return safeReply(data, api, adv, t(adv, "petTeamSetInvalid", null, "Đội hình chứa thú không tồn tại hoặc không thuộc sở hữu của bạn."));
            }
        }

        player.team = ids;
        const teamPets = ids.map(id => global.data.hunt.pets[id]);
        const lines = teamPets.map((p, idx) => {
            const displayName = getPetDisplayName(p);
            const rarityName = getLocalizedRarity(adv, p.rarity);
            return `${idx + 1}. #${p.id} ${p.emoji} ${displayName} [${rarityName}] - Cấp ${p.level}`;
        }).join("\n");

        return safeReply(data, api, adv, t(adv, "petTeamSetSuccess", { "{team}": lines }, `✅ Đã cập nhật đội hình pet:\n\n{team}`));
    }

    if (action === "clear") {
        player.team = [];
        return safeReply(data, api, adv, t(adv, "petTeamClearSuccess", null, "✅ Đã xóa đội hình pet."));
    }

    if (action === "remove") {
        const petIdArg = args[2];
        if (!petIdArg) {
            return safeReply(data, api, adv, t(adv, "petTeamRemoveUsage", { "{prefix}": getPrefix() }, `Sai cú pháp. Dùng: ${getPrefix()}petteam remove <petId>`));
        }

        const petId = parseInt(petIdArg, 10);
        if (isNaN(petId) || petId <= 0) {
            return safeReply(data, api, adv, t(adv, "petInfoNotFound", { "{id}": petIdArg }, `Không tìm thấy thú #{id}.`));
        }

        if (!player.team || !player.team.map(String).includes(String(petId))) {
            return safeReply(data, api, adv, t(adv, "petTeamRemoveMissing", { "{id}": String(petId) }, `Thú #{id} không có trong đội hình.`));
        }

        player.team = player.team.filter(id => String(id) !== String(petId));
        return safeReply(data, api, adv, t(adv, "petTeamRemoveSuccess", { "{id}": String(petId) }, `✅ Đã xóa thú #{id} khỏi đội hình.`));
    }

    return safeReply(data, api, adv, t(adv, "petTeamSetUsage", { "{prefix}": getPrefix() }));
}

// Phase 3 Lootboxes and Weapons Commands
function lootbox(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const text = t(adv, "lootboxInventory", {
        "{common}": String(player.inventory.lootbox_common || 0),
        "{rare}": String(player.inventory.lootbox_rare || 0),
        "{epic}": String(player.inventory.lootbox_epic || 0),
        "{shards}": String(player.inventory.weapon_shard || 0)
    }, `🎁 Hộp của bạn:\n\n- Hộp thường: ${player.inventory.lootbox_common || 0}\n- Hộp hiếm: ${player.inventory.lootbox_rare || 0}\n- Hộp sử thi: ${player.inventory.lootbox_epic || 0}\n- Mảnh vũ khí: ${player.inventory.weapon_shard || 0}`);

    safeReply(data, api, adv, text);
}

function openbox(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    let boxId = args[1] ? args[1].trim().toLowerCase() : "";
    if (boxId === "common") boxId = "lootbox_common";
    else if (boxId === "rare") boxId = "lootbox_rare";
    else if (boxId === "epic") boxId = "lootbox_epic";

    if (!boxId) {
        return safeReply(data, api, adv, t(adv, "openBoxUsage", { "{prefix}": getPrefix() }));
    }

    if (!LOOTBOX_ITEMS[boxId]) {
        return safeReply(data, api, adv, t(adv, "openBoxInvalid", { "{boxId}": boxId }));
    }

    let qty = 1;
    if (args[2] !== undefined) {
        qty = parseInt(args[2], 10);
        if (isNaN(qty) || qty < 1 || qty > 10) {
            return safeReply(data, api, adv, t(adv, "openBoxInvalidQuantity"));
        }
    }

    const player = ensureHuntPlayer(data.senderID);
    const ownedBoxCount = player.inventory[boxId] || 0;
    if (ownedBoxCount < qty) {
        return safeReply(data, api, adv, t(adv, "openBoxNoBox"));
    }

    player.inventory[boxId] -= qty;

    let totalMoney = 0;
    let totalShards = 0;
    const itemsReceived = { bait: 0, lucky_charm: 0, trap: 0 };
    const weaponsReceived = [];

    for (let i = 0; i < qty; i++) {
        if (boxId === "lootbox_common") {
            const roll = Math.random() * 100;
            if (roll < 60) {
                totalMoney += randomInt(100, 500);
            } else if (roll < 85) {
                const itemKeys = ["bait", "lucky_charm", "trap"];
                const item = itemKeys[randomInt(0, 2)];
                itemsReceived[item]++;
            } else if (roll < 95) {
                totalShards += randomInt(1, 5);
            } else {
                const rarityRoll = Math.random() < 0.8 ? "common" : "uncommon";
                const weapon = generateWeapon(rarityRoll, data.senderID);
                player.weaponIds.push(weapon.id);
                weaponsReceived.push(weapon);
            }
        } else if (boxId === "lootbox_rare") {
            const roll = Math.random() * 100;
            if (roll < 40) {
                totalMoney += randomInt(500, 1500);
            } else if (roll < 65) {
                totalShards += randomInt(3, 10);
            } else if (roll < 85) {
                const itemKeys = ["bait", "lucky_charm", "trap"];
                const item = itemKeys[randomInt(0, 2)];
                itemsReceived[item]++;
            } else {
                const rarityRoll = weightedPick({ uncommon: 70, rare: 25, epic: 5 });
                const weapon = generateWeapon(rarityRoll, data.senderID);
                player.weaponIds.push(weapon.id);
                weaponsReceived.push(weapon);
            }
        } else if (boxId === "lootbox_epic") {
            const roll = Math.random() * 100;
            if (roll < 30) {
                totalMoney += randomInt(1500, 4000);
            } else if (roll < 55) {
                totalShards += randomInt(8, 20);
            } else if (roll < 75) {
                const rarityRoll = Math.random() < 0.75 ? "rare" : "epic";
                const weapon = generateWeapon(rarityRoll, data.senderID);
                player.weaponIds.push(weapon.id);
                weaponsReceived.push(weapon);
            } else if (roll < 90) {
                const weapon = generateWeapon("legendary", data.senderID);
                player.weaponIds.push(weapon.id);
                weaponsReceived.push(weapon);
            } else {
                if (Math.random() < 0.1) {
                    const weapon = generateWeapon("mythic", data.senderID);
                    player.weaponIds.push(weapon.id);
                    weaponsReceived.push(weapon);
                } else {
                    totalShards += randomInt(20, 40);
                }
            }
        }
    }

    if (totalMoney > 0) {
        addMoney(data.senderID, totalMoney);
    }
    if (totalShards > 0) {
        player.inventory.weapon_shard = (player.inventory.weapon_shard || 0) + totalShards;
    }
    for (let k in itemsReceived) {
        if (itemsReceived[k] > 0) {
            player.inventory[k] = (player.inventory[k] || 0) + itemsReceived[k];
        }
    }

    player.stats.boxesOpened += qty;

    const locale = (adv && adv.iso639) || "vi_VN";
    const boxName = locale === "vi_VN" ? LOOTBOX_ITEMS[boxId].viName : LOOTBOX_ITEMS[boxId].enName;

    const itemsParts = [];
    for (let k in itemsReceived) {
        if (itemsReceived[k] > 0) {
            itemsParts.push(`${itemsReceived[k]}x ${getLocalizedItemName(adv, k)}`);
        }
    }
    const itemsText = itemsParts.length > 0 ? itemsParts.join(", ") : (locale === "vi_VN" ? "Không" : "None");

    const weaponsParts = weaponsReceived.map(w => `${w.emoji} [${getLocalizedRarity(adv, w.rarity)}]`);
    const weaponsText = weaponsParts.length > 0 ? weaponsParts.join(", ") : (locale === "vi_VN" ? "Không" : "None");

    const resultText = t(adv, "openBoxResult", {
        "{quantity}": String(qty),
        "{boxName}": boxName,
        "{money}": formatMoney(totalMoney),
        "{shards}": String(totalShards),
        "{items}": itemsText,
        "{weapons}": weaponsText
    }, `🎁 Kết quả mở {quantity}x {boxName}:\n\n- Tiền nhận: {money}\n- Mảnh nhận: {shards}\n- Vật phẩm nhận: {items}\n- Vũ khí nhận: {weapons}`);

    safeReply(data, api, adv, resultText);
}

function weapons(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const player = ensureHuntPlayer(data.senderID);
    const weaponIds = player.weaponIds || [];
    const playerWeapons = weaponIds.map(id => global.data.hunt.weapons[id]).filter(Boolean);

    if (playerWeapons.length === 0) {
        return safeReply(data, api, adv, t(adv, "weaponsEmpty"));
    }

    playerWeapons.sort((a, b) => a.id - b.id);

    const args = getArgs(data);
    let page = 1;
    if (args[1] !== undefined) {
        page = parseInt(args[1], 10);
        if (isNaN(page) || page < 1) page = 1;
    }

    const totalPages = Math.ceil(playerWeapons.length / 10);
    if (page > totalPages) page = totalPages;
    if (page < 1) page = 1;

    const start = (page - 1) * 10;
    const pageWeapons = playerWeapons.slice(start, start + 10);

    const equippedWeaponIds = new Set();
    const petIds = player.petIds || [];
    for (let petId of petIds) {
        const pet = global.data.hunt.pets[petId];
        if (pet && pet.equippedWeaponId) {
            equippedWeaponIds.add(String(pet.equippedWeaponId));
        }
    }

    const listText = pageWeapons.map(w => {
        const lockText = w.locked ? "🔒 " : "";
        const equippedText = equippedWeaponIds.has(String(w.id)) ? "⚔️ " : "";
        const statLine = formatWeaponStatsShort(w);
        const name = getLocalizedWeaponType(adv, w.type);

        return t(adv, "weaponsLine", {
            "{id}": String(w.id),
            "{lock}": lockText,
            "{equipped}": equippedText,
            "{emoji}": w.emoji,
            "{name}": name,
            "{rarity}": getLocalizedRarity(adv, w.rarity),
            "{level}": String(w.level),
            "{stats}": statLine
        }, `#${w.id} ${lockText}${equippedText}${w.emoji} ${name} [${getLocalizedRarity(adv, w.rarity)}] - Cấp ${w.level} - ${statLine}`);
    }).join("\n");

    const header = t(adv, "weaponsHeader", {
        "{page}": String(page),
        "{totalPages}": String(totalPages)
    }, `🧰 Vũ khí của bạn - Trang {page}/{totalPages}\n`);

    safeReply(data, api, adv, `${header}\n${listText}`);
}

function weaponinfo(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const wepIdArg = args[1];
    if (!wepIdArg) {
        return safeReply(data, api, adv, t(adv, "weaponInfoUsage", { "{prefix}": getPrefix() }));
    }

    const wepId = parseInt(wepIdArg, 10);
    if (isNaN(wepId) || wepId <= 0) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": wepIdArg }));
    }

    const weapon = global.data.hunt.weapons[wepId];
    if (!weapon) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": String(wepId) }));
    }

    if (weapon.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotOwner", { "{id}": String(wepId) }));
    }

    let equippedPetName = t(adv, "noneLabel", null, "Không");
    const player = ensureHuntPlayer(data.senderID);
    const petIds = player.petIds || [];
    for (let petId of petIds) {
        const pet = global.data.hunt.pets[petId];
        if (pet && String(pet.equippedWeaponId) === String(wepId)) {
            equippedPetName = `#${pet.id} ${pet.emoji} ${getPetDisplayName(pet)}`;
            break;
        }
    }

    const lockStatus = weapon.locked
        ? t(adv, "lockedLabel", null, "Đã khóa")
        : t(adv, "unlockedLabel", null, "Chưa khóa");

    const nextCost = weapon.level >= 20 ? 0 : Math.floor(5 * Math.pow(1.25, weapon.level - 1));
    const costText = weapon.level >= 20
        ? (t(adv, "noneLabel", null, "Không"))
        : t(adv, "weaponUpgradeCost", { "{cost}": String(nextCost) }, `${nextCost} mảnh vũ khí`);

    const statsText = t(adv, "weaponStatsLine", {
        "{attack}": String(weapon.attackBonus || 0),
        "{defense}": String(weapon.defenseBonus || 0),
        "{crit}": String(weapon.critBonus || 0),
        "{coin}": String(weapon.coinBonus || 0),
        "{rare}": String(weapon.rareBonus || 0)
    }, `ATK +{attack}, DEF +{defense}, CRIT +{crit}%, COIN +{coin}%, RARE +{rare}%`);

    const infoText = t(adv, "weaponInfo", {
        "{id}": String(weapon.id),
        "{emoji}": weapon.emoji,
        "{type}": getLocalizedWeaponType(adv, weapon.type),
        "{name}": weapon.name,
        "{rarity}": getLocalizedRarity(adv, weapon.rarity),
        "{level}": String(weapon.level),
        "{stats}": statsText,
        "{lockStatus}": lockStatus,
        "{equippedPet}": equippedPetName,
        "{upgradeCost}": costText
    });

    safeReply(data, api, adv, infoText);
}

function equipweapon(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petIdArg = args[1];
    const wepIdArg = args[2];

    if (!petIdArg || !wepIdArg) {
        return safeReply(data, api, adv, t(adv, "equipWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const petId = parseInt(petIdArg, 10);
    const wepId = parseInt(wepIdArg, 10);

    if (isNaN(petId) || isNaN(wepId)) {
        return safeReply(data, api, adv, t(adv, "equipWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const player = ensureHuntPlayer(data.senderID);
    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "equipWeaponInvalidPet", { "{id}": String(petId) }));
    }

    const weapon = global.data.hunt.weapons[wepId];
    if (!weapon || weapon.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "equipWeaponInvalidWeapon", { "{id}": String(wepId) }));
    }

    const petIds = player.petIds || [];
    for (let pid of petIds) {
        const p = global.data.hunt.pets[pid];
        if (p && String(p.equippedWeaponId) === String(wepId) && p.id !== petId) {
            return safeReply(data, api, adv, t(adv, "equipWeaponAlreadyEquipped", { "{id}": String(wepId) }));
        }
    }

    pet.equippedWeaponId = weapon.id;
    safeReply(data, api, adv, t(adv, "equipWeaponSuccess", {
        "{weaponId}": String(wepId),
        "{petId}": String(petId)
    }));
}

function unequipweapon(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const petIdArg = args[1];
    if (!petIdArg) {
        return safeReply(data, api, adv, t(adv, "unequipWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const petId = parseInt(petIdArg, 10);
    if (isNaN(petId)) {
        return safeReply(data, api, adv, t(adv, "unequipWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const player = ensureHuntPlayer(data.senderID);
    const pet = global.data.hunt.pets[petId];
    if (!pet || pet.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "equipWeaponInvalidPet", { "{id}": String(petId) }));
    }

    if (!pet.equippedWeaponId) {
        return safeReply(data, api, adv, t(adv, "unequipWeaponNone", { "{id}": String(petId) }));
    }

    pet.equippedWeaponId = null;
    safeReply(data, api, adv, t(adv, "unequipWeaponSuccess", { "{id}": String(petId) }));
}

function upgradeweapon(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const wepIdArg = args[1];
    if (!wepIdArg) {
        return safeReply(data, api, adv, t(adv, "upgradeWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const wepId = parseInt(wepIdArg, 10);
    if (isNaN(wepId)) {
        return safeReply(data, api, adv, t(adv, "upgradeWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const player = ensureHuntPlayer(data.senderID);
    const weapon = global.data.hunt.weapons[wepId];
    if (!weapon || weapon.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": String(wepId) }));
    }

    if (weapon.level >= 20) {
        return safeReply(data, api, adv, t(adv, "upgradeWeaponMaxLevel", { "{id}": String(wepId) }));
    }

    let times = 1;
    if (args[2] !== undefined) {
        times = parseInt(args[2], 10);
        if (isNaN(times) || times < 1 || times > 10) {
            times = 1;
        }
    }

    let totalCost = 0;
    let currentLevel = weapon.level;
    let upgradedLevels = 0;

    while (upgradedLevels < times && currentLevel < 20) {
        const cost = Math.floor(5 * Math.pow(1.25, currentLevel - 1));
        if ((player.inventory.weapon_shard || 0) < totalCost + cost) {
            break;
        }
        totalCost += cost;
        currentLevel++;
        upgradedLevels++;
    }

    if (upgradedLevels === 0) {
        const nextCost = Math.floor(5 * Math.pow(1.25, weapon.level - 1));
        const missing = nextCost - (player.inventory.weapon_shard || 0);
        return safeReply(data, api, adv, t(adv, "upgradeWeaponNoShard", {
            "{missing}": String(missing),
            "{id}": String(wepId)
        }));
    }

    player.inventory.weapon_shard -= totalCost;

    const isHighRarity = ["epic", "legendary", "mythic"].includes(weapon.rarity);
    for (let i = 0; i < upgradedLevels; i++) {
        weapon.level++;
        weapon.attackBonus += isHighRarity ? 2 : 1;
        weapon.defenseBonus += 1;
        if (weapon.level % 3 === 0) {
            weapon.critBonus += 1;
            weapon.coinBonus += 1;
        }
        if (weapon.level % 4 === 0 && isHighRarity) {
            weapon.rareBonus += 1;
        }
    }

    player.stats.weaponsUpgraded += upgradedLevels;

    const statsText = t(adv, "weaponStatsLine", {
        "{attack}": String(weapon.attackBonus || 0),
        "{defense}": String(weapon.defenseBonus || 0),
        "{crit}": String(weapon.critBonus || 0),
        "{coin}": String(weapon.coinBonus || 0),
        "{rare}": String(weapon.rareBonus || 0)
    });

    safeReply(data, api, adv, t(adv, "upgradeWeaponSuccess", {
        "{id}": String(wepId),
        "{level}": String(weapon.level),
        "{cost}": String(totalCost),
        "{stats}": statsText
    }));
}

function sellweapon(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    if (args[1] === undefined) {
        return safeReply(data, api, adv, t(adv, "sellWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const player = ensureHuntPlayer(data.senderID);
    const target = args.slice(1).join(" ").trim().toLowerCase();

    if (target === "all common" || target === "all uncommon") {
        const targetRarity = target === "all common" ? "common" : "uncommon";
        const weaponIds = player.weaponIds || [];
        const playerWeapons = weaponIds.map(id => global.data.hunt.weapons[id]).filter(Boolean);

        const equippedWeaponIds = new Set();
        const petIds = player.petIds || [];
        for (let petId of petIds) {
            const pet = global.data.hunt.pets[petId];
            if (pet && pet.equippedWeaponId) {
                equippedWeaponIds.add(String(pet.equippedWeaponId));
            }
        }

        const sellable = playerWeapons.filter(w => w.rarity === targetRarity && !w.locked && !equippedWeaponIds.has(String(w.id)));

        if (sellable.length === 0) {
            return safeReply(data, api, adv, t(adv, "sellWeaponBulkEmpty", {
                "{rarity}": getLocalizedRarity(adv, targetRarity)
            }));
        }

        let totalEarned = 0;
        const soldIds = new Set(sellable.map(w => String(w.id)));

        for (let w of sellable) {
            const price = getWeaponSellPrice(w);
            totalEarned += price;
            delete global.data.hunt.weapons[w.id];
        }

        player.weaponIds = player.weaponIds.filter(id => !soldIds.has(String(id)));
        addMoney(data.senderID, totalEarned);

        return safeReply(data, api, adv, t(adv, "sellWeaponBulkSuccess", {
            "{count}": String(sellable.length),
            "{rarity}": getLocalizedRarity(adv, targetRarity),
            "{total}": formatMoney(totalEarned)
        }));
    } else {
        const wepId = parseInt(target, 10);
        if (isNaN(wepId) || wepId <= 0) {
            return safeReply(data, api, adv, t(adv, "sellWeaponInvalid", { "{id}": target }));
        }

        const weapon = global.data.hunt.weapons[wepId];
        if (!weapon || weapon.ownerID !== data.senderID) {
            return safeReply(data, api, adv, t(adv, "sellWeaponInvalid", { "{id}": String(wepId) }));
        }

        if (weapon.locked) {
            return safeReply(data, api, adv, t(adv, "sellWeaponLocked", { "{id}": String(wepId) }));
        }

        const petIds = player.petIds || [];
        let isEquipped = false;
        for (let petId of petIds) {
            const pet = global.data.hunt.pets[petId];
            if (pet && String(pet.equippedWeaponId) === String(wepId)) {
                isEquipped = true;
                break;
            }
        }

        if (isEquipped) {
            return safeReply(data, api, adv, t(adv, "sellWeaponEquipped", { "{id}": String(wepId) }));
        }

        const price = getWeaponSellPrice(weapon);
        addMoney(data.senderID, price);

        player.weaponIds = player.weaponIds.filter(id => id !== wepId);
        delete global.data.hunt.weapons[wepId];

        return safeReply(data, api, adv, t(adv, "sellWeaponSuccess", {
            "{id}": String(wepId),
            "{price}": formatMoney(price)
        }));
    }
}

function lockweapon(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const wepIdArg = args[1];
    if (!wepIdArg) {
        return safeReply(data, api, adv, t(adv, "lockWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const wepId = parseInt(wepIdArg, 10);
    if (isNaN(wepId) || wepId <= 0) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": wepIdArg }));
    }

    const weapon = global.data.hunt.weapons[wepId];
    if (!weapon || weapon.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": String(wepId) }));
    }

    if (weapon.locked) {
        return safeReply(data, api, adv, t(adv, "lockWeaponAlready", { "{id}": String(wepId) }));
    }

    weapon.locked = true;
    safeReply(data, api, adv, t(adv, "lockWeaponSuccess", { "{id}": String(wepId) }));
}

function unlockweapon(data, api, e2ee, adv) {
    if (!checkEconomy(data, api, adv)) return;
    if (!data || !data.senderID) return;

    const args = getArgs(data);
    const wepIdArg = args[1];
    if (!wepIdArg) {
        return safeReply(data, api, adv, t(adv, "unlockWeaponUsage", { "{prefix}": getPrefix() }));
    }

    const wepId = parseInt(wepIdArg, 10);
    if (isNaN(wepId) || wepId <= 0) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": wepIdArg }));
    }

    const weapon = global.data.hunt.weapons[wepId];
    if (!weapon || weapon.ownerID !== data.senderID) {
        return safeReply(data, api, adv, t(adv, "weaponInfoNotFound", { "{id}": String(wepId) }));
    }

    if (!weapon.locked) {
        return safeReply(data, api, adv, t(adv, "unlockWeaponAlready", { "{id}": String(wepId) }));
    }

    weapon.locked = false;
    safeReply(data, api, adv, t(adv, "unlockWeaponSuccess", { "{id}": String(wepId) }));
}

function hunthelp(data, api, e2ee, adv) {
    return safeReply(data, api, adv, t(adv, "huntHelp", null, "🐾 Hunt - Command list"));
}

module.exports = {
    hunt,
    zoo,
    sellpet,
    huntinv,
    huntshop,
    huntbuy,
    petbattle,
    lockpet: petlock,
    unlockpet: petunlock,
    petlock,
    petunlock,
    petinfo,
    petrename,
    petteam,
    hunthelp,

    lootbox,
    openbox,
    weapons,
    weaponinfo,
    equipweapon,
    unequipweapon,
    upgradeweapon,
    sellweapon,
    lockweapon,
    unlockweapon
};
