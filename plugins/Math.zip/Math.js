
async function math (data, api, e2ee) {
    var axios = require("axios");
	var msg = data.body;
	if (msg == "") {
		adv.reply("Lỗi: Phương trình không được để trống!");
	} else {
		var dataa = JSON.parse(require('sync-request')("GET", "https://coccoc.com/composer/math?q=" + encodeURIComponent(msg)).body.toString());
  console.log(dataa);
		if (!dataa.math.hasOwnProperty("variants")) {
			adv.reply("Lỗi: Không phải phương trình!");
		} else if (!dataa.math.variants.length) {
			adv.reply("Lỗi: Phương trình không có lời giải!");
		} else {
			var response = "";
			response += "Phương trình: " + dataa.math.variants[0].texImage.replaced_formula;
			response += "\r\nĐáp án: " + (dataa.math.variants[0].answers[0].replaced_formula != "" ? dataa.math.variants[0].answers[0].replaced_formula : dataa.math.variants[0].answers[0].description);
			if (dataa.math.variants[0].answers[0].replaced_formula != "") {
				adv.reply(response);
			} else {
				var rt = {
						body: response,
						attachment: (await axios({
						    url: dataa.math.variants[0].answers[0].answer_url,
                            method: "GET", 
                            responseType: "stream"
                        })).data
					}
				console.log(rt)
				adv.reply(rt);
			}
		}
	}
}

module.exports = {
	math,
}