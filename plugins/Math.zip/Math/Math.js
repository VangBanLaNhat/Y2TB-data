
async function math (data, api) {
    var axios = require("axios");
	var msg = data.body;
	if (msg == "") {
		api.sendMessage("Lỗi: Phương trình không được để trống!", data.threadID, data.messageID);
	} else {
		var dataa = JSON.parse(require('sync-request')("GET", "https://coccoc.com/composer/math?q=" + encodeURIComponent(msg)).body.toString());
  console.log(dataa);
		if (!dataa.math.hasOwnProperty("variants")) {
			api.sendMessage("Lỗi: Không phải phương trình!", data.threadID, data.messageID);
		} else if (!dataa.math.variants.length) {
			api.sendMessage("Lỗi: Phương trình không có lời giải!", data.threadID, data.messageID);
		} else {
			var response = "";
			response += "Phương trình: " + dataa.math.variants[0].texImage.replaced_formula;
			response += "\r\nĐáp án: " + (dataa.math.variants[0].answers[0].replaced_formula != "" ? dataa.math.variants[0].answers[0].replaced_formula : dataa.math.variants[0].answers[0].description);
			if (dataa.math.variants[0].answers[0].replaced_formula != "") {
				api.sendMessage(response, data.threadID, data.messageID);
			} else {
				var rt = {
						body: response,
						attachment: (await axios({
						    url: dataa.math.variants[0].answers[0].answer_url,
                            method: "GET", 
                            responseType: "stream"
                        })).data
					}
				console.log(rt)
				api.sendMessage(rt, data.threadID, data.messageID);
			}
		}
	}
}

module.exports = {
	math,
}