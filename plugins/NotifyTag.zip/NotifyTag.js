const fs = require("fs");
const path = require("path");

const pluginInfo = require("./plugin.json");
const viLang = require("./lang/vi_VN.json");
const enLang = require("./lang/en_US.json");

const defaultPluginConfig = {
    maxTopicsPerMessage: 1,
    skipSenderInHook: false,
    silentWhenNoSubscribers: true,
    maxMentionsPerMessage: 50
};

function getPluginConfig(customConfig) {
    const config = Object.assign({}, defaultPluginConfig);
    if (customConfig && typeof customConfig === "object") {
        for (let k in defaultPluginConfig) {
            if (customConfig[k] !== undefined) {
                config[k] = customConfig[k];
            }
        }
    }
    return config;
}

function ensureStore() {
    if (!global.data) {
        global.data = {};
    }
    if (!global.data.notifyTag) {
        global.data.notifyTag = {
            threads: {}
        };
    }
    if (!global.data.notifyTag.threads) {
        global.data.notifyTag.threads = {};
    }
}

function getThreadStore(threadID) {
    ensureStore();
    const tid = String(threadID);
    if (!global.data.notifyTag.threads[tid]) {
        global.data.notifyTag.threads[tid] = {
            topics: {},
            createdAt: Date.now(),
            updatedAt: Date.now()
        };
    }
    return global.data.notifyTag.threads[tid];
}

function getTopicStore(threadID, topic, createIfMissing = false) {
    const threadStore = getThreadStore(threadID);
    const normalized = normalizeTopic(topic);
    if (!threadStore.topics[normalized]) {
        if (!createIfMissing) return null;
        threadStore.topics[normalized] = {
            topic: normalized,
            users: {},
            createdAt: Date.now(),
            updatedAt: Date.now()
        };
    }
    return threadStore.topics[normalized];
}

function normalizeTopic(input) {
    if (typeof input !== "string") return "";
    let s = input.trim();
    if (s.startsWith("@")) {
        s = s.slice(1);
    }
    return s.toLowerCase().trim();
}

function isValidTopic(topic) {
    if (!topic) return false;
    const normalized = normalizeTopic(topic);
    if (!normalized) return false;
    if (normalized === "all" || normalized === "everyone" || normalized === "here") return false;
    return /^[a-z0-9_-]{2,32}$/i.test(normalized);
}

function extractHookTopics(body) {
    if (!body) return [];
    const topics = [];
    const regex = /(^|\s)@([a-zA-Z0-9_-]{2,32})(?=\s|$|[.,!?;:])/g;
    let match;
    regex.lastIndex = 0;
    while ((match = regex.exec(body)) !== null) {
        const topic = normalizeTopic(match[2]);
        if (isValidTopic(topic) && !topics.includes(topic)) {
            topics.push(topic);
        }
    }
    return topics;
}

function getThreadID(data) {
    return data ? (data.threadID || data.threadId) : undefined;
}

function getSenderID(data) {
    return data ? (data.senderID || data.senderId) : undefined;
}

function getPrefix() {
    return (global.config && global.config.facebook && global.config.facebook.prefix) || "/";
}

function getArgs(data) {
    return (data && Array.isArray(data.args)) ? data.args : [];
}

async function getThreadInfoSafe(api, threadID) {
    if (!threadID) return null;
    try {
        if (global.threadInfo && global.threadInfo[threadID]) {
            return global.threadInfo[threadID];
        }
        if (api && typeof api.getThreadInfo === "function") {
            const info = await api.getThreadInfo(threadID);
            if (info) {
                if (Array.isArray(info.adminIDs)) {
                    info.adminIDs = info.adminIDs
                        .map(item => (item && typeof item === "object") ? item.id : item)
                        .filter(Boolean)
                        .map(id => String(id));
                }
                if (global.threadInfo) {
                    global.threadInfo[threadID] = info;
                }
                return info;
            }
        }
    } catch (_) {}
    return null;
}

async function isGroupThread(data, api) {
    if (!data) return false;
    if (data.isGroup === true) return true;
    if (data.isGroup === false) return false;
    const threadID = getThreadID(data);
    if (!threadID) return false;
    const threadInfo = await getThreadInfoSafe(api, threadID);
    return threadInfo ? threadInfo.isGroup === true : false;
}

function extractFirstMention(data) {
    if (!data || !data.mentions) return null;
    const mentionIDs = Object.keys(data.mentions);
    if (mentionIDs.length === 0) return null;
    
    const targetID = mentionIDs[0];
    const rawName = data.mentions[targetID] || "";
    const targetName = String(rawName).replace("@", "").trim() || targetID;
    
    return {
        userID: targetID,
        name: targetName
    };
}

async function getDisplayName(userID, api, adv) {
    const sUid = String(userID);
    if (adv && typeof adv.getUserInfo === "function") {
        try {
            const info = await adv.getUserInfo(sUid);
            if (info && info.name) return info.name;
            if (info && info.fullName) return info.fullName;
        } catch (_) {}
    }
    if (api && typeof api.getUserInfo === "function") {
        try {
            const info = await api.getUserInfo(sUid);
            if (info && info[sUid]) {
                return info[sUid].name || info[sUid].fullName || sUid;
            }
        } catch (_) {}
    }
    return `User ${sUid}`;
}

function isBotAdmin(userID) {
    if (!userID) return false;
    const adminConfig = global.config && global.config.facebook && global.config.facebook.admin;
    if (!adminConfig) return false;
    const sUid = String(userID);
    if (Array.isArray(adminConfig)) {
        return adminConfig.map(id => String(id)).includes(sUid);
    }
    return String(adminConfig) === sUid;
}

function isThreadAdmin(userID, threadInfo) {
    if (!userID || !threadInfo || !Array.isArray(threadInfo.adminIDs)) return false;
    return threadInfo.adminIDs.includes(String(userID));
}

function canManageTopic(userID, threadInfo) {
    return isBotAdmin(userID) || isThreadAdmin(userID, threadInfo);
}

function buildPlainTextMessage(topic, users, adv) {
    const normalizedTopic = normalizeTopic(topic);
    const lang = (adv && adv.iso639) || global.config.bot_info.lang || "vi_VN";
    const template = lang === "vi_VN" ? "📢 Thông báo: {topic}\n\n" : "📢 Notification: {topic}\n\n";
    let body = template.replace("{topic}", normalizedTopic);
    
    const userNames = Object.values(users)
        .filter(u => u && u.name)
        .map(u => u.name)
        .join(", ");
        
    body += userNames;
    return body;
}

function buildMentionMessage(topic, users, adv, config) {
    const normalizedTopic = normalizeTopic(topic);
    const lang = (adv && adv.iso639) || global.config.bot_info.lang || "vi_VN";
    const template = lang === "vi_VN" ? "📢 Thông báo: {topic}\n\n" : "📢 Notification: {topic}\n\n";
    let body = template.replace("{topic}", normalizedTopic);
    
    const mentions = [];
    const maxMentions = (config && config.maxMentionsPerMessage) || 50;
    
    const userList = Object.values(users).filter(u => u && u.userID);
    const limit = Math.min(userList.length, maxMentions);
    
    for (let i = 0; i < limit; i++) {
        const user = userList[i];
        const tag = "@" + user.name;
        const fromIndex = body.length;
        
        body += tag;
        if (i < limit - 1) {
            body += " ";
        }
        
        mentions.push({
            tag,
            id: String(user.userID),
            fromIndex
        });
    }
    
    if (userList.length > maxMentions) {
        const diff = userList.length - maxMentions;
        const moreTemplate = lang === "vi_VN" 
            ? "\n...và {count} thành viên khác."
            : "\n...and {count} more members.";
        body += moreTemplate.replace("{count}", String(diff));
    }
    
    return { body, mentions };
}

function safeReply(data, api, adv, text, callback) {
    if (adv && typeof adv.reply === "function") {
        try {
            return adv.reply(text, callback);
        } catch (_) {}
    }
    if (adv && adv.ctx && typeof adv.ctx.reply === "function") {
        try {
            return adv.ctx.reply(text, callback);
        } catch (_) {}
    }
    const threadID = getThreadID(data);
    const messageID = data ? data.messageID : undefined;
    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](text, threadID, callback, messageID);
        } catch (_) {}
    }
    if (callback) safeCallback(callback, new Error("No reply mechanism available"));
}

function safeSend(data, api, adv, message, callback, options = {}) {
    if (adv && adv.ctx && typeof adv.ctx.send === "function") {
        try {
            return adv.ctx.send(message, options, callback);
        } catch (_) {}
    }
    if (adv && typeof adv.send === "function") {
        try {
            return adv.send(message, callback);
        } catch (_) {}
    }
    const threadID = getThreadID(data);
    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](message, threadID, callback);
        } catch (_) {}
    }
    if (callback) safeCallback(callback, new Error("No send mechanism available"));
}

function sendMentionMessage(data, api, adv, messageObject, callback) {
    const threadID = getThreadID(data);
    const messageID = data ? data.messageID : undefined;
    
    if (api && typeof api["send" + "Message"] === "function") {
        try {
            return api["send" + "Message"](messageObject, threadID, callback, messageID);
        } catch (err) {
            if (callback) callback(err);
        }
    } else if (adv && typeof adv.send === "function") {
        try {
            return adv.send(messageObject, callback);
        } catch (err) {
            if (callback) callback(err);
        }
    } else {
        if (callback) callback(new Error("No message sending API available"));
    }
}

function safeCallback(callback, err, result) {
    if (typeof callback === "function") {
        try {
            callback(err, result);
        } catch (_) {}
    }
}

function t(adv, key, map, fallback) {
    try {
        const template = adv && typeof adv.rlang === "function"
            ? adv.rlang(key)
            : fallback;

        const text = template || fallback || key;

        if (adv && typeof adv.replaceMap === "function" && map) {
            return adv.replaceMap(text, map);
        }

        if (!map) return text;

        return Object.keys(map).reduce((result, placeholder) => {
            return result.split(placeholder).join(String(map[placeholder]));
        }, text);
    } catch (_) {
        return fallback || key;
    }
}

function buildArgs(viArgs = {}, enArgs = {}) {
    const args = {};
    const placeholders = new Set([
        ...Object.keys(viArgs),
        ...Object.keys(enArgs)
    ]);
    for (let placeholder of placeholders) {
        args[placeholder] = {
            vi_VN: viArgs[placeholder] || "",
            en_US: enArgs[placeholder] || ""
        };
    }
    return args;
}

function buildLangMap() {
    const langMap = {};
    const keys = new Set([
        ...Object.keys(viLang),
        ...Object.keys(enLang)
    ]);

    for (let key of keys) {
        const viEntry = viLang[key] || {};
        const enEntry = enLang[key] || {};
        
        langMap[key] = {
            desc: viEntry.desc || enEntry.desc || "",
            vi_VN: viEntry.text || "",
            en_US: enEntry.text || "",
            args: buildArgs(viEntry.args, enEntry.args)
        };
    }
    return langMap;
}

function init() {
    return {
        ...pluginInfo,
        langMap: buildLangMap()
    };
}

async function notifyon(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        const senderID = getSenderID(data);
        if (!threadID || !senderID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const args = getArgs(data);
        const topicArg = args[1];
        if (!topicArg) {
            return safeReply(data, api, adv, t(adv, "topicRequired"));
        }

        const topic = normalizeTopic(topicArg);
        if (!isValidTopic(topic)) {
            return safeReply(data, api, adv, t(adv, "invalidTopic"));
        }

        const topicStore = getTopicStore(threadID, topic, true);
        if (topicStore.users[senderID]) {
            return safeReply(data, api, adv, t(adv, "registerAlready", { "{topic}": topic }));
        }

        const displayName = await getDisplayName(senderID, api, adv);
        topicStore.users[senderID] = {
            userID: senderID,
            name: displayName,
            registeredAt: Date.now(),
            registeredBy: senderID
        };
        topicStore.updatedAt = Date.now();
        getThreadStore(threadID).updatedAt = Date.now();

        return safeReply(data, api, adv, t(adv, "registerSuccess", { "{topic}": topic }));
    } catch (err) {
        console.error("notifyon error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

async function notifyoff(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        const senderID = getSenderID(data);
        if (!threadID || !senderID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const args = getArgs(data);
        const topicArg = args[1];
        if (!topicArg) {
            return safeReply(data, api, adv, t(adv, "topicRequired"));
        }

        const topic = normalizeTopic(topicArg);
        if (!isValidTopic(topic)) {
            return safeReply(data, api, adv, t(adv, "invalidTopic"));
        }

        const topicStore = getTopicStore(threadID, topic);
        if (!topicStore || !topicStore.users[senderID]) {
            return safeReply(data, api, adv, t(adv, "unregisterMissing", { "{topic}": topic }));
        }

        delete topicStore.users[senderID];
        topicStore.updatedAt = Date.now();
        getThreadStore(threadID).updatedAt = Date.now();

        return safeReply(data, api, adv, t(adv, "unregisterSuccess", { "{topic}": topic }));
    } catch (err) {
        console.error("notifyoff error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

async function notifylist(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        if (!threadID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const args = getArgs(data);
        const topicArg = args[1];
        if (!topicArg) {
            return safeReply(data, api, adv, t(adv, "topicRequired"));
        }

        const topic = normalizeTopic(topicArg);
        if (!isValidTopic(topic)) {
            return safeReply(data, api, adv, t(adv, "invalidTopic"));
        }

        const topicStore = getTopicStore(threadID, topic);
        if (!topicStore) {
            return safeReply(data, api, adv, t(adv, "listEmpty", { "{topic}": topic }));
        }

        let activeUsers = Object.values(topicStore.users).filter(Boolean);
        const threadInfo = await getThreadInfoSafe(api, threadID);
        if (threadInfo && Array.isArray(threadInfo.participantIDs)) {
            const activeIds = new Set(threadInfo.participantIDs.map(id => String(id)));
            activeUsers = activeUsers.filter(u => activeIds.has(String(u.userID)));
        }

        if (activeUsers.length === 0) {
            return safeReply(data, api, adv, t(adv, "listEmpty", { "{topic}": topic }));
        }

        const count = activeUsers.length;
        let output = t(adv, "listHeader", { "{topic}": topic, "{count}": String(count) });
        
        const limit = Math.min(count, 30);
        for (let i = 0; i < limit; i++) {
            const user = activeUsers[i];
            output += t(adv, "listLine", { "{index}": String(i + 1), "{name}": user.name }) + "\n";
        }

        if (count > 30) {
            output += t(adv, "listFooterMore", { "{count}": String(count - 30) });
        }

        return safeReply(data, api, adv, output.trim());
    } catch (err) {
        console.error("notifylist error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

async function notifytopics(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        if (!threadID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const threadStore = getThreadStore(threadID);
        const topics = Object.values(threadStore.topics).filter(Boolean);

        if (topics.length === 0) {
            return safeReply(data, api, adv, t(adv, "topicsEmpty"));
        }

        const threadInfo = await getThreadInfoSafe(api, threadID);
        const activeIds = threadInfo && Array.isArray(threadInfo.participantIDs)
            ? new Set(threadInfo.participantIDs.map(id => String(id)))
            : null;

        let output = t(adv, "topicsHeader");
        let idx = 1;
        for (let tStore of topics) {
            let activeCount = Object.keys(tStore.users).length;
            if (activeIds) {
                activeCount = Object.values(tStore.users).filter(u => u && activeIds.has(String(u.userID))).length;
            }
            output += t(adv, "topicsLine", {
                "{index}": String(idx++),
                "{topic}": tStore.topic,
                "{count}": String(activeCount)
            }) + "\n";
        }

        return safeReply(data, api, adv, output.trim());
    } catch (err) {
        console.error("notifytopics error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

async function notifyadd(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        const senderID = getSenderID(data);
        if (!threadID || !senderID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const args = getArgs(data);
        const topicArg = args[1];
        if (!topicArg) {
            return safeReply(data, api, adv, t(adv, "topicRequired"));
        }

        const topic = normalizeTopic(topicArg);
        if (!isValidTopic(topic)) {
            return safeReply(data, api, adv, t(adv, "invalidTopic"));
        }

        const target = extractFirstMention(data);
        if (!target) {
            return safeReply(data, api, adv, t(adv, "mentionRequired"));
        }

        const threadInfo = await getThreadInfoSafe(api, threadID);
        if (threadInfo && Array.isArray(threadInfo.participantIDs)) {
            const activeIds = threadInfo.participantIDs.map(id => String(id));
            if (!activeIds.includes(String(target.userID))) {
                const lang = (adv && adv.iso639) || global.config.bot_info.lang || "vi_VN";
                const errorMsg = lang === "vi_VN"
                    ? "Thành viên này hiện không có trong nhóm."
                    : "This member is not currently in the group.";
                return safeReply(data, api, adv, errorMsg);
            }
        }

        const topicStore = getTopicStore(threadID, topic, true);
        if (topicStore.users[target.userID]) {
            return safeReply(data, api, adv, t(adv, "addAlready", {
                "{name}": target.name,
                "{topic}": topic
            }));
        }

        topicStore.users[target.userID] = {
            userID: target.userID,
            name: target.name,
            registeredAt: Date.now(),
            registeredBy: senderID
        };
        topicStore.updatedAt = Date.now();
        getThreadStore(threadID).updatedAt = Date.now();

        return safeReply(data, api, adv, t(adv, "addSuccess", {
            "{name}": target.name,
            "{topic}": topic
        }));
    } catch (err) {
        console.error("notifyadd error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

async function notifyremove(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        const senderID = getSenderID(data);
        if (!threadID || !senderID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const threadInfo = await getThreadInfoSafe(api, threadID);
        if (!canManageTopic(senderID, threadInfo)) {
            return safeReply(data, api, adv, t(adv, "noPermission"));
        }

        const args = getArgs(data);
        const topicArg = args[1];
        if (!topicArg) {
            return safeReply(data, api, adv, t(adv, "topicRequired"));
        }

        const topic = normalizeTopic(topicArg);
        if (!isValidTopic(topic)) {
            return safeReply(data, api, adv, t(adv, "invalidTopic"));
        }

        const target = extractFirstMention(data);
        if (!target) {
            return safeReply(data, api, adv, t(adv, "mentionRequired"));
        }

        const topicStore = getTopicStore(threadID, topic);
        if (!topicStore || !topicStore.users[target.userID]) {
            return safeReply(data, api, adv, t(adv, "adminRemoveMissing", {
                "{name}": target.name,
                "{topic}": topic
            }));
        }

        delete topicStore.users[target.userID];
        topicStore.updatedAt = Date.now();
        getThreadStore(threadID).updatedAt = Date.now();

        return safeReply(data, api, adv, t(adv, "adminRemoveSuccess", {
            "{name}": target.name,
            "{topic}": topic
        }));
    } catch (err) {
        console.error("notifyremove error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

async function notifyclear(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        const senderID = getSenderID(data);
        if (!threadID || !senderID) {
            return safeReply(data, api, adv, t(adv, "missingContext"));
        }

        const isGroup = await isGroupThread(data, api);
        if (!isGroup) {
            return safeReply(data, api, adv, t(adv, "groupOnly"));
        }

        const threadInfo = await getThreadInfoSafe(api, threadID);
        if (!canManageTopic(senderID, threadInfo)) {
            return safeReply(data, api, adv, t(adv, "noPermission"));
        }

        const args = getArgs(data);
        const topicArg = args[1];
        if (!topicArg) {
            return safeReply(data, api, adv, t(adv, "topicRequired"));
        }

        const topic = normalizeTopic(topicArg);
        if (!isValidTopic(topic)) {
            return safeReply(data, api, adv, t(adv, "invalidTopic"));
        }

        const topicStore = getTopicStore(threadID, topic);
        if (!topicStore) {
            return safeReply(data, api, adv, t(adv, "clearSuccess", { "{count}": "0", "{topic}": topic }));
        }

        const count = Object.keys(topicStore.users).length;
        topicStore.users = {};
        topicStore.updatedAt = Date.now();
        getThreadStore(threadID).updatedAt = Date.now();

        return safeReply(data, api, adv, t(adv, "clearSuccess", { "{count}": String(count), "{topic}": topic }));
    } catch (err) {
        console.error("notifyclear error:", err);
        return safeReply(data, api, adv, t(adv, "unknownError"));
    }
}

function notifyhelp(data, api, e2ee, adv) {
    return safeReply(data, api, adv, t(adv, "help"));
}

async function chathook(data, api, e2ee, adv) {
    try {
        const threadID = getThreadID(data);
        if (!threadID) return;
        
        const isGroup = await isGroupThread(data, api);
        if (!isGroup) return;
        
        const body = data.body || (adv && adv.ctx && adv.ctx.body) || "";
        if (!body) return;
        
        const botID = typeof api.getCurrentUserID === "function" ? String(api.getCurrentUserID()) : null;
        if (botID && String(data.senderID) === botID) return;
        if (body.includes("📢 Thông báo:") || body.includes("📢 Notification:")) return;
        
        const topics = extractHookTopics(body);
        if (topics.length === 0) return;
        
        const config = getPluginConfig(adv ? adv.config : null);
        
        const topic = topics[0];
        const topicStore = getTopicStore(threadID, topic);
        if (!topicStore) return;
        
        let usersToMention = Object.values(topicStore.users).filter(Boolean);
        if (usersToMention.length === 0) return;
        
        if (config.skipSenderInHook && data.senderID) {
            const sSender = String(data.senderID);
            usersToMention = usersToMention.filter(u => String(u.userID) !== sSender);
        }
        
        const threadInfo = await getThreadInfoSafe(api, threadID);
        if (threadInfo && Array.isArray(threadInfo.participantIDs)) {
            const activeIds = new Set(threadInfo.participantIDs.map(id => String(id)));
            usersToMention = usersToMention.filter(u => activeIds.has(String(u.userID)));
        }
        
        if (usersToMention.length === 0) return;
        
        const ctx = adv && adv.ctx ? adv.ctx : { isE2EE: false };
        if (ctx.isE2EE) {
            const plainText = buildPlainTextMessage(topic, usersToMention, adv);
            return safeSend(data, api, adv, plainText, null, { immediate: true });
        } else {
            const mentionObject = buildMentionMessage(topic, usersToMention, adv, config);
            return sendMentionMessage(data, api, adv, mentionObject, (err) => {
                if (err) {
                    const plainText = buildPlainTextMessage(topic, usersToMention, adv);
                    safeReply(data, api, adv, plainText);
                }
            });
        }
    } catch (err) {
        console.error("NotifyTag chathook error:", err);
    }
}

module.exports = {
    init,
    notifyon,
    notifyoff,
    notifylist,
    notifytopics,
    notifyadd,
    notifyremove,
    notifyclear,
    notifyhelp,
    chathook
};
