
async function main(data, api, adv, chk) {
    const axios = require("axios");
    
    let link = chk ? await getLink(chk) : await getLink(data.args[1]);

    if (link.error) {
        console.error("Pinterest", link.error);
        return !chk ? api.sendMessage(link.error, data.threadID, data.messageID) : "";
    }

    let stream = (await axios({
        url: link.url,
        method: "GET",
        responseType: "stream"
    })).data

    //console.log(link);

    api.sendMessage({
        body: adv.replaceMap(adv.rlang("sendBody"), {
            "{0}": link.title,
            "{1}": link.desc
        }),
        attachment: stream
    }, data.threadID, data.messageID);
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function auto(data, api, {rlang, getThreadInfo}) {
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) { 
        let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs); 
        let check = adminL.indexOf(String(data.senderID)) != -1; 
        if(!check) return api.sendMessage(rlang("noPer"), data.threadID, data.messageID); 
    } 
    if(global.data.pinterest[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
        global.data.pinterest[data.threadID] = false;
        return api.sendMessage(rlang("Off"), data.threadID, data.messageID);
    }
 
    global.data.pinterest[data.threadID] = true;
    api.sendMessage(rlang("On"), data.threadID, data.messageID); 
}

async function chathook(data, api, adv) {
    !global.data.pinterest ? global.data.pinterest = {}:"";
    global.data.pinterest[data.threadID] == undefined ? global.data.pinterest[data.threadID] = true:"";

    if((data.type != "message" && data.type != "message_reply") || !global.data.pinterest[data.threadID] || data.body.indexOf(global.config.facebook.prefix) == 0) return;
    
    let mapLink = ["pin.it", "pinterest.com"];
    
    let args = data.body.split(" ");
    
    for(let i of args) {
        let ch = false;
        for(let j of mapLink) if(i.indexOf(j) != -1) {
            ch = true;
            break;
        }
        
        if(!ch) break;
        
        main(data, api, adv, i);
    }
}

async function getLink(link) {
    const { JSDOM } = require("jsdom");
    const fetch = require("node-fetch");

    var url = link;

    try {
        if (url.match("pin.it")) url = await expandURL(url);

        const { hostname, pathname } = new URL(url);
        const path = pathname.replace("/sent/", "");
        const finalUrl = `https://${hostname}${path}`;
        const response = await fetch(finalUrl);
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        const body = await response.text();
        let outUrl;
        let type = "video";
        try {
            const video = new JSDOM(body).window.document.getElementsByTagName(
                "video"
            )[0].src;
            outUrl = video.replace("/hls/", "/720p/").replace(".m3u8", ".mp4");
        } catch (_) {
            outUrl = new JSDOM(body).window.document.getElementsByTagName(
                "img"
            )[0];
            if (!outUrl) return {error: "The link does not exist, please try again with a new link!"};
            outUrl = outUrl.src;
            type = "image";
        }

        const title = new JSDOM(body).window.document.querySelector('div[data-test-id="pinTitle"] h1').innerHTML;
        var desc;
        try {
            desc = new JSDOM(body).window.document.querySelector('div[data-test-id="truncated-description"] div div span').innerHTML;
        } catch (_) {}

        //console.log(desc);

        return {
            type: type,
            url: outUrl,
            title: title,
            decs: desc
        };
    } catch (err) {
        return {
            error: err
        };
    }
}

async function expandURL(shortenURL) {
    const uri = new URL(shortenURL);
    const path = uri.pathname;
    const finalUrl = `https://api.pinterest.com/url_shortener${path}/redirect/`;
    try {
        let response = await fetch(finalUrl, {
            method: "HEAD",
            redirect: "manual",
        });
        let location = response.headers.get("location");
        return location;
    } catch (error) {
        console.error(error);
        return null;
    }
}

module.exports = {
    main,
    auto,
    chathook
}