
function pong(data, api, e2ee, adv){
    const timeStart = Date.now();
    adv.reply("Pinging...", (e, a) => {
        if (api.editMessage) api.editMessage(`Ping: ${Date.now() - timeStart}ms`, a.messageID);
        else adv.reply(`Ping: ${Date.now() - timeStart}ms`)
    });
}

function pongch(data, api, e2ee, adv){
    if(data.body == "ping" || data.body == "Ping"){
        adv.reply("‍Pong");
    } else if(data.body == "pong" || data.body == "Pong"){
        adv.reply("Amen, pong thì để tui nói, nói ping đê");
    }
}

module.exports = {
    pong,
    pongch,
};