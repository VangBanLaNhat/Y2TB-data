
function pong(data, api){
    const timeStart = Date.now();
    api.sendMessage("Pinging...", data.threadID, (e, a) => {
        if (api.editMessage) api.editMessage(`Ping: ${Date.now() - timeStart}ms`, a.messageID);
        else api.sendMessage(`Ping: ${Date.now() - timeStart}ms`, data.threadID, data.messageID)
    }, data.messageID);
}

function pongch(data, api){
    if(data.body == "ping" || data.body == "Ping"){
        api.sendMessage("‍Pong" , data.threadID, data.messageID);
    } else if(data.body == "pong" || data.body == "Pong"){
        api.sendMessage("Amen, pong thì để tui nói, nói ping đê" , data.threadID, data.messageID);
    }
}

module.exports = {
    pong,
    pongch,
};