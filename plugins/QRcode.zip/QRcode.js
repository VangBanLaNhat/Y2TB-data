var fs = require("fs");
var path = require("path");

function main(data, api, e2ee, adv){
    switch (data.args[1]) {
        case 'create':
            crqr(data, api, e2ee, adv);
            break;
        case 'scan':
            dcqr(data, api, e2ee, adv);
            break;
        default:
            adv.reply(`<create||scan>`);
            break;
    }
}

async function crqr(data, api, e2ee, adv){
    //var QRCode = require("qrcode");
    var axios = require("axios");
    var lang = global.lang.QRcode;
    var msg = data.args.slice(2).join(" ");
    if(msg){
        try{
            //var link = await QRCode.toDataURL(msg, {type:'terminal'});
            var link = `http://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(msg)}&size=1000x1000`
            console.log(link)
            var rt = {
                body: "Success:",
                attachment: (await axios({
                    url: link,
                    method: "GET", 
                    responseType: "stream"
                })).data
            }
            adv.reply(rt);
        } catch (e){
            adv.reply(e);
            console.error("QRcode", e)
        }
    }else{
        adv.reply(lang.nomsg[global.config.bot_info.lang]);
    }
}

async function dcqr(data, api, e2ee, adv){
    //var quirc = require("node-quirc");
    var axios = require("axios");
    
    var lang = global.lang.QRcode;
    if (data.messageReply) if(data.messageReply.attachments[0].url){
        try{
            var link = data.messageReply.attachments[0].url;
            
            /*var imgdl = (await axios({
                url: link,
                method: "GET",
                responseType: "stream"
            })).data
            var imgdl = require('sync-request')("GET", link).body;
            fs.writeFileSync(path.join(dircc, data.messageID + ".jpg"), imgdl);
            var img = fs.readFileSync(path.join(dircc, data.messageID + ".jpg"));*/
            try{
                //var rt = await quirc.decode(img);
                var rt = (await axios(`http://zxing.org/w/decode?u=${encodeURIComponent(link)}&full=true%20(code%20URL%20unescaped:%20${encodeURIComponent(link)})`)).data
                adv.reply("Scan completed: "+rt)
            } catch (e){
                adv.reply(lang.notqr[global.config.bot_info.lang])
                console.error("QRcode", e)
            }
            
        } catch (e){
            adv.reply(e);
            console.error("QRcode", e)
        }
    } else adv.reply(lang.notqr[global.config.bot_info.lang])
    else adv.reply(lang.noreply[global.config.bot_info.lang]);
}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return;
  } catch (ex) {
    return {
      err: ex
    };
  }
}

module.exports = {
    main
}