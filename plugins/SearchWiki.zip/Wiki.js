
function wiki(data, api, e2ee, adv) {
    if (data.body != "" ){
        var rt = "Searching..."
	    adv.reply(rt);
    }
	(async function () {
    var fetch = require("node-fetch");
    var path = require("path");
    var streamBuffers = require("stream-buffers")
		var sT = data.body;
		var sS = encodeURIComponent(sT)
		if (sT === '') {
			return "`"+global.config.facebook.prefix+ "wiki <keyword>`\r\n[Seach on Wikipedia]"
		} else {
			try {
				var api = `https://${global.config.bot_info.lang.split("_")[0]}.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&titles=${sS}`
				var img = `https://${global.config.bot_info.lang.split("_")[0]}.wikipedia.org/w/api.php?action=query&titles=${sS}&prop=pageimages&format=json&pithumbsize=720`
				console.log("Wiki", "Keyword: "+sT);
				var fetchdata = await fetch(api);
				var fetchimg = await fetch(img);
				var js = await fetchimg.text();
				var json = await fetchdata.text();
				var dbtm = `${js}`;
				var dbt = `${json}`;
				var suggestionData = JSON.parse(dbt);
				var pageid = Object.keys(suggestionData.query.pages)[0];
				var tI = suggestionData.query.pages[pageid].title;
				var eX = suggestionData.query.pages[pageid].extract;
				var title = tI.toString('utf-8');
				var text = eX.toString('utf-8');
				var imgD = JSON.parse(dbtm);
				var pgid = Object.keys(imgD.query.pages)[0];
				if (imgD.query.pages[pgid].thumbnail == undefined) {
				    return `Result: ${title}\n\n- ${text}`
				    adv.reply(rt);
				} else {
					var imgX = imgD.query.pages[pgid].thumbnail.source;
					var fetchimgD = await fetch(imgX);
					var buffer = await fetchimgD.buffer();
						var imagesx = new streamBuffers.ReadableStreamBuffer({
							frequency: 10,
							chunkSize: 1024
						});
						imagesx.path = 'image.png';
						imagesx.put(buffer);
						imagesx.stop();
						return {
								body: `Result: ${title}\n\n- ${text}`,
								attachment: ([imagesx])
							}
						adv.reply(rt);
				}
			} catch(er) {
				console.log(er)
				return "Data not found!"
				adv.reply(rt);
			}
		}
	})().then(function (returndata) {
		adv.reply(returndata);
	});
}
module.exports = {
	wiki,
}