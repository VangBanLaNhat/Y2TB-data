
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { spotifyDl, alldown } = require("@neelegirly/downloader");

async function main(data, api, e2ee, adv, chk, isAlbum) {
    const rawLink = chk ? chk : data.args[1];
    const link = normalizeSpotifyTrackUrl(rawLink);

    if (!isSpotifyTrackUrl(link)) {
        if (chk) return;
        return adv.reply(adv.rlang("illegal"));
    }

    let info;
    try {
        info = await resolveSpotifyData(link);
    } catch (error) {
        console.warn("Spotify", error);
        if (chk) return;
        return adv.reply(adv.rlang("illegal"));
    }

    const songUrl = extractSpotifyMediaUrl(info);
    if (songUrl) {
        const songTitle = extractSpotifyTitle(info);
        await sendFromDirectUrl(data, api, e2ee, adv, songUrl, songTitle, chk);
        return;
    }

    const fallbackOk = await fallbackWithSpottyDL(data, api, e2ee, adv, link, chk);
    if (fallbackOk) return;

    if (!chk) {
        adv.reply(extractSpotifyError(info) || "Spotify API is temporarily unavailable.");
    }
}

function isSpotifyTrackUrl(link) {
    if (typeof link !== "string") return false;
    return /open\.spotify\.com\/track\/[A-Za-z0-9]+/i.test(link.trim());
}

function normalizeSpotifyTrackUrl(link) {
    if (typeof link !== "string") return "";
    const trimmed = link.trim();
    if (!trimmed) return "";

    try {
        const parsed = new URL(trimmed);
        const isSpotifyHost = /(^|\.)spotify\.com$/i.test(parsed.hostname);
        if (!isSpotifyHost) return trimmed;

        const match = parsed.pathname.match(/\/track\/([A-Za-z0-9]+)/i);
        if (!match || !match[1]) return trimmed;
        return `https://open.spotify.com/track/${match[1]}`;
    } catch (_) {
        const match = trimmed.match(/open\.spotify\.com\/track\/([A-Za-z0-9]+)/i);
        if (!match || !match[1]) return trimmed;
        return `https://open.spotify.com/track/${match[1]}`;
    }
}

async function resolveSpotifyData(link) {
    const direct = await spotifyDl(link);
    if (direct && direct.status) return direct;

    const fallback = await alldown(link);
    if (fallback && fallback.status) return fallback;

    return direct || fallback;
}

function scoreSpotifyUrl(keyPath, url) {
    let score = 0;
    const key = (keyPath || "").toLowerCase();
    const lowerUrl = (url || "").toLowerCase();

    if (/audio|mp3|music|download|dl/.test(key)) score += 5;
    if (/\.mp3($|\?)/.test(lowerUrl)) score += 4;
    if (/audio|download|cdn/.test(lowerUrl)) score += 2;
    if (/image|cover|thumbnail|avatar/.test(key)) score -= 4;
    if (/\.jpg|\.jpeg|\.png|\.webp($|\?)/.test(lowerUrl)) score -= 5;

    return score;
}

function collectSpotifyUrls(node, keyPath, acc, depth) {
    if (depth > 5 || !node) return;

    if (typeof node === "string") {
        if (node.startsWith("http")) {
            acc.push({
                url: node,
                score: scoreSpotifyUrl(keyPath, node)
            });
        }
        return;
    }

    if (Array.isArray(node)) {
        for (let i = 0; i < node.length; i++) {
            collectSpotifyUrls(node[i], `${keyPath}[${i}]`, acc, depth + 1);
        }
        return;
    }

    if (typeof node === "object") {
        for (const key of Object.keys(node)) {
            collectSpotifyUrls(node[key], keyPath ? `${keyPath}.${key}` : key, acc, depth + 1);
        }
    }
}

function extractSpotifyMediaUrl(info) {
    if (!info || typeof info !== "object") return null;
    const root = info.data !== undefined ? info.data : info;

    const urls = [];
    collectSpotifyUrls(root, "", urls, 0);
    if (!urls.length) return null;

    urls.sort((a, b) => b.score - a.score);
    return urls[0].score >= 1 ? urls[0].url : null;
}

function extractSpotifyTitle(info) {
    if (!info || typeof info !== "object") return "Spotify track";
    const root = info.data !== undefined ? info.data : info;

    if (typeof root.title === "string" && root.title.trim()) return root.title.trim();
    if (typeof root.name === "string" && root.name.trim()) return root.name.trim();
    if (typeof root.song === "string" && root.song.trim()) return root.song.trim();
    if (typeof root.track === "string" && root.track.trim()) return root.track.trim();

    return "Spotify track";
}

function extractSpotifyError(info) {
    if (!info || typeof info !== "object") return null;
    return info.msg || info.error || null;
}

async function sendFromDirectUrl(data, api, e2ee, adv, songUrl, songTitle, chk) {
    let name = `${Date.now()}${data.messageID}.mp3`;
    let dir = path.join(__dirname, "cache", "spotify");
    ensureExists(dir);
    dir = path.join(dir, name);

    if (!chk) {
        adv.reply(adv.replaceMap(adv.rlang("downloading"), {
            "{0}": songTitle
        }));
    }

    try {
        const response = await axios({
            method: "get",
            url: songUrl,
            responseType: "stream"
        });

        await new Promise((resolve, reject) => {
            const stream = response.data.pipe(fs.createWriteStream(dir));
            stream.on("finish", resolve);
            stream.on("error", reject);
        });

        if (fs.statSync(dir).size > 26214400) {
            adv.reply(adv.rlang("more25mb"), () => fs.unlinkSync(dir));
            return false;
        }

        adv.reply({
            body: `Success: ${songTitle}`,
            attachment: fs.createReadStream(dir)
        }, () => fs.unlinkSync(dir));
        return true;
    } catch (err) {
        console.error("Spotify direct", err);
        if (fs.existsSync(dir)) fs.unlinkSync(dir);
        if (!chk) {
            adv.reply("Error: " + (err.message || String(err)));
        }
        return false;
    }
}

async function fallbackWithSpottyDL(data, api, e2ee, adv, spotifyUrl, chk) {
    let SpottyDL;
    try {
        SpottyDL = require("spottydl");
    } catch (_) {
        return false;
    }

    const ffmpeg = require("fluent-ffmpeg");
    const ffmpegPath = require("@ffmpeg-installer/ffmpeg").path;
    ffmpeg.setFfmpegPath(ffmpegPath);

    let getYoutubeClient;
    let buildVideoInfoOptions;
    let saveAudioSourceToFileWithRetry;
    try {
        ({
            getYoutubeClient,
            buildVideoInfoOptions
        } = require("../Youtube/lib/clients"));
        ({
            saveAudioSourceToFileWithRetry
        } = require("../Youtube/lib/stream"));
    } catch (e) {
        console.warn("Spotify fallback helpers", e);
        return false;
    }

    let info;
    try {
        info = await SpottyDL.getTrack(spotifyUrl);
    } catch (error) {
        console.warn("Spotify fallback", error);
        return false;
    }

    if (!info || !info.id) {
        return false;
    }

    const videoId = String(info.id).trim();
    const youtubeBaseConfig = global.configPl && global.configPl["YouTube"]
        ? global.configPl["YouTube"]
        : {};
    const youtubeConfig = Object.assign({}, youtubeBaseConfig, {
        disable_ytdl_fallback: true
    });

    let yt;
    try {
        yt = await getYoutubeClient(youtubeConfig);
    } catch (e) {
        console.warn("Spotify fallback getYoutubeClient", e);
        return false;
    }

    let ytInfo;
    try {
        ytInfo = await yt.getBasicInfo(videoId, buildVideoInfoOptions(youtubeConfig, "WEB"));
    } catch (_) {
        try {
            ytInfo = await yt.getBasicInfo(videoId, buildVideoInfoOptions(youtubeConfig, "ANDROID"));
        } catch (_) {}
    }

    const cacheDir = path.join(__dirname, "cache", "spotify");
    ensureExists(cacheDir);
    const id = `${Date.now()}${data.messageID}`;
    const sourcePath = path.join(cacheDir, `${id}.source`);
    const dir = path.join(cacheDir, `${id}.mp3`);

    if (!chk) {
        const title = `${info.title || "Spotify track"}${info.artist ? ` - ${info.artist}` : ""}`;
        adv.reply(adv.replaceMap(adv.rlang("downloading"), {
            "{0}": title
        }));
    }

    try {
        await saveAudioSourceToFileWithRetry(yt, ytInfo, videoId, sourcePath, youtubeConfig);
    } catch (err) {
        console.error("Spotify fallback source", err);
        try { if (fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
        return false;
    }

    return new Promise((resolve) => {
        ffmpeg(sourcePath)
            .noVideo()
            .audioCodec("libmp3lame")
            .audioBitrate(128)
            .format("mp3")
            .save(dir)
            .on("end", () => {
                try { if (fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
                if (fs.statSync(dir).size > 26214400) {
                    adv.reply(adv.rlang("more25mb"), () => fs.unlinkSync(dir));
                    resolve(true);
                    return;
                }

                const title = `${info.title || "Spotify track"}${info.artist ? ` by ${info.artist}` : ""}`;
                adv.reply({
                    body: `Success: ${title}`,
                    attachment: fs.createReadStream(dir)
                }, () => fs.unlinkSync(dir));
                resolve(true);
            })
            .on("error", (err) => {
                console.error("Spotify fallback ffmpeg", err);
                try { if (fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
                try { if (fs.existsSync(dir)) fs.unlinkSync(dir); } catch (_) {}
                resolve(false);
            });
    });
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function auto(data, api, e2ee, {rlang, getThreadInfo}) {
    if (global.config.facebook.admin.indexOf(data.senderID) == -1) {
        let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs);
        let check = adminL.indexOf(String(data.senderID)) != -1;
        if (!check) return adv.reply(rlang("noPer"));
    }
    if (global.data.spotify.autodown[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
        global.data.spotify.autodown[data.threadID] = false;
        return adv.reply(rlang("autoOff"));
    }

    global.data.spotify.autodown[data.threadID] = true;
    adv.reply(rlang("autoOn"));
}

async function album(data, api, e2ee, {rlang, getThreadInfo}) {
    if (global.config.facebook.admin.indexOf(data.senderID) == -1) {
        let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs);
        let check = adminL.indexOf(String(data.senderID)) != -1;
        if (!check) return adv.reply(rlang("noPer"));
    }
    if (global.data.spotify.album[data.threadID] || (data.args[1] && data.args[1].toLowerCase() == "off")) {
        global.data.spotify.album[data.threadID] = false;
        return adv.reply(rlang("albumOff"));
    }

    global.data.spotify.album[data.threadID] = true;
    adv.reply(rlang("albumOn"));
}

async function chathook(data, api, e2ee, adv) {
    !global.data.spotify ? global.data.spotify = {}: "";
    !global.data.spotify.autodown ? global.data.spotify.autodown = {}: "";
    global.data.spotify.autodown[data.threadID] == undefined ? global.data.spotify.autodown[data.threadID] = true: "";
    !global.data.spotify.album ? global.data.spotify.album = {}: "";
    global.data.spotify.album[data.threadID] == undefined ? global.data.spotify.album[data.threadID] = false: "";

    if ((data.type != "message" && data.type != "message_reply") || !global.data.spotify.autodown[data.threadID] || data.body.indexOf(global.config.facebook.prefix) == 0) return;
    
    if (data.body.indexOf("spotify.com") == -1) return;
    
    var args = data.body.split(" ");
    
    for (let i of args) {
        if (i.indexOf("spotify.com") == -1) continue;
        
        // Check if it's a track link (spottydl handles individual tracks)
        if (i.indexOf("/track/") !== -1) {
            main(data, api, e2ee, adv, i);
        }
    }
}

// Functions support

function ensureExists(path, mask) {
    var fs = require('fs');
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(path, {
            mode: mask,
            recursive: true
        });
        return;
    } catch (ex) {
        return {
            err: ex
        };
    }
}

module.exports = {
    main,
    auto,
    album,
    chathook
}