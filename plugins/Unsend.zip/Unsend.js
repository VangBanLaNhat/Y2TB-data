
function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function main(data, api, e2ee, adv) {
    var lang = global.lang.Unsend;
    var l = global.config.bot_info.lang;
    if (data.messageReply){
        try{
            var grinfo = await api.getThreadInfo(data.threadID);
            var listadgr = normalizeAdminIDs(grinfo.adminIDs);
        } catch (err) {
            var listadgr = []
            console.error("Unsend", err)
        }
        if (listadgr.indexOf(data.senderID) != -1) {
            adv.unsend(data.messageReply.messageID, (e)=>{
                if(e) adv.send(lang.umm[l]);
            });
        } else if (global.config.facebook.admin.indexOf(data.senderID) != -1) {
            adv.unsend(data.messageReply.messageID, (e)=>{
                if(e) adv.send(lang.umm[l]);
            });
        } else adv.reply(lang.noad[l]);
    } else adv.reply(lang.nmsg[l]);
}

module.exports = {
    main
}