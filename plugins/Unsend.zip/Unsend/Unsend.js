
function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function main(data, api) {
    var lang = global.lang.Unsend;
    var l = global.config.bot_info.lang;
    if (data.messageReply){
        try{
            var grinfo = await api.getThreadInfo(data.threadID);
            var listadgr = normalizeAdminIDs(grinfo.adminIDs);
        } catch (err) {
            var listadgr = []
            console.error("Unsend", err)
        }
        if (listadgr.indexOf(data.senderID) != -1) {
            api.unsendMessage(data.messageReply.messageID, (e)=>{
                if(e) api.sendMessage(lang.umm[l], data.threadID, data.messageID)
                else api.sendMessage(lang.cl[l].replace("{0}", "Admin group"), data.threadID, data.messageID);
            })
        } else if (global.config.facebook.admin.indexOf(data.senderID) != -1) {
            api.unsendMessage(data.messageReply.messageID, (e)=>{
                if(e) api.sendMessage(lang.umm[l], data.threadID, data.messageID);
                else api.sendMessage(lang.cl[l].replace("{0}", "Admin BotChat"), data.threadID, data.messageID);
            })
        } else api.sendMessage(lang.noad[l], data.threadID, data.messageID);
    } else api.sendMessage(lang.nmsg[l], data.threadID, data.messageID);
}

module.exports = {
    main
}