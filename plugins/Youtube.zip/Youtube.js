var path = require("path");
const axios = require("axios");
const {
    extractVideoId,
    getDurationSeconds,
    normalizeAdminIDs
} = require("./lib/helpers");
const {
    buildVideoInfoOptions,
    getYoutubeClient,
    searchYoutubeVideos
} = require("./lib/clients");
const {
    saveAudioSourceToFileWithRetry,
    saveVideoSourceToFileWithRetry
} = require("./lib/stream");

async function fetchThumbnailAttachments(thumbUrls) {
    const urls = Array.from(new Set((thumbUrls || []).filter(Boolean))).slice(0, 6);
    if (!urls.length) return null;

    const results = await Promise.allSettled(
        urls.map((url) => axios({
            url,
            method: "GET",
            responseType: "stream"
        }))
    );

    const attachments = results
        .filter((item) => item.status === "fulfilled" && item.value && item.value.data)
        .map((item) => item.value.data);

    if (!attachments.length) return [];
    return attachments;
}

function isE2EEThreadFromAdv(adv, threadID) {
    if (!adv || !adv.e2ee || typeof adv.e2ee.isE2EEThread !== "function") return false;
    return adv.e2ee.isE2EEThread(threadID);
}

function safeUnsend(api, adv, threadID, messageID) {
    if (!messageID) return;
    if (isE2EEThreadFromAdv(adv, threadID)) return;
    const ids = Array.isArray(messageID) ? messageID : [messageID];
    for (const id of ids) {
        try {
            const res = adv.unsend(id, () => {});
            if (res && typeof res.catch === "function") {
                res.catch(() => {});
            }
        } catch (_) {}
    }
}

async function sendSearchTextThenImages(data, api, e2ee, adv, body, thumbUrls, onMessageSent) {
    const canSendImages = !isE2EEThreadFromAdv(adv, data.threadID);
    adv.reply({ body }, async (err, info) => {
        if (info && info.messageId && !info.messageID) {
            info.messageID = info.messageId;
        }
        if (info && typeof onMessageSent === "function") onMessageSent(info);
        if (!canSendImages) return;
        try {
            const attachments = await fetchThumbnailAttachments(thumbUrls);
            if (!attachments || !attachments.length) return;
            for (const attachment of attachments) {
                await new Promise((resolve) => {
                    adv.send({ attachment }, (err, imgInfo) => {
                        if (imgInfo && imgInfo.messageId && !imgInfo.messageID) {
                            imgInfo.messageID = imgInfo.messageId;
                        }
                        if (imgInfo && typeof onMessageSent === "function") onMessageSent(imgInfo);
                        resolve();
                    });
                });
            }
        } catch (_) {}
    });
}

function createFfmpegProgressLogger(label) {
    let lastLogAt = 0;
    return function onProgress(progress) {
        const now = Date.now();
        if (now - lastLogAt < 1000) return;
        lastLogAt = now;

        const parts = [label];
        if (progress && Number.isFinite(progress.percent)) {
            parts.push(`${progress.percent.toFixed(1)}%`);
        }
        if (progress && progress.timemark) {
            parts.push(`t=${progress.timemark}`);
        }
        if (progress && progress.targetSize) {
            parts.push(`size=${progress.targetSize}KB`);
        }
        const line = parts.join(" ");
        if (typeof console.rewrite === "function") {
            console.rewrite("YouTube", line);
        } else {
            console.log(line);
        }
    };
}

async function ytmp4(data, api, e2ee, adv) {
    let { rlang, replaceMap } = adv;
    if (data.args[1] == undefined) return adv.reply(rlang("noMSG"));

    if (data.args.length == 2 && (data.args[1].indexOf("youtube.com") != -1 || data.args[1].indexOf("youtu.be") != -1)) return downmp4(data, api, e2ee, adv, data.args[1]);

    //search

    if (global.temp.youtube.ytmp4[data.threadID][data.senderID]) {
        const state = global.temp.youtube.ytmp4[data.threadID][data.senderID];
        safeUnsend(api, adv, data.threadID, state.MIDs || state.MID);
        delete global.temp.youtube.ytmp4[data.threadID][data.senderID];
    }

    let msg = data.body;
    const items = await searchYoutubeVideos(msg, 12, adv.config);
    let thumbUrls = [];
    var listURL = [];
    var res = ``;
    let y = 1;
    items.forEach((x) => {
        if (y > 6) return;
        if (!x.duration) return;
        if (!x.durationSeconds || x.durationSeconds > 6 * 60) return;
        if (!x.thumbUrl) return;
        thumbUrls.push(x.thumbUrl);
        res += `${y}. ${x.title} (${x.duration}):
${x.url}
`;
        y++;
        listURL.push(x.url);
    });
    var bodyText = "‍‍‍‍‍‍‍‍‍‍" + replaceMap(rlang("ytrs"), { "{0}": res });
    sendSearchTextThenImages(data, api, e2ee, adv, bodyText, thumbUrls, (a) => {
        if (!a || !a.messageID) return;
        let state = global.temp.youtube.ytmp4[data.threadID][data.senderID];
        if (!state) {
            state = {
                MID: a.messageID,
                MIDs: [a.messageID],
                list: listURL
            };
            global.temp.youtube.ytmp4[data.threadID][data.senderID] = state;
        } else {
            state.MIDs.push(a.messageID);
        }
    });
}

async function ytmp3(data, api, e2ee, adv) {
    let { rlang, replaceMap } = adv;
    if (data.args[1] == undefined) return adv.reply(rlang("noMSG"));

    if (data.args.length == 2 && (data.args[1].indexOf("youtube.com") != -1 || data.args[1].indexOf("youtu.be") != -1)) return downmp3(data, api, e2ee, adv, data.args[1]);

    //search

    if (global.temp.youtube.ytmp3[data.threadID][data.senderID]) {
        const state = global.temp.youtube.ytmp3[data.threadID][data.senderID];
        safeUnsend(api, adv, data.threadID, state.MIDs || state.MID);
        delete global.temp.youtube.ytmp3[data.threadID][data.senderID];
    }

    let msg = data.body;
    const items = await searchYoutubeVideos(msg, 12, adv.config);
    let thumbUrls = [];
    var listURL = [];
    var res = ``;
    let y = 1;
    items.forEach((x) => {
        if (y > 6) return;
        if (!x.duration) return;
        if (!x.durationSeconds || x.durationSeconds > 10 * 60) return;
        if (!x.thumbUrl) return;
        thumbUrls.push(x.thumbUrl);
        res += `${y}. ${x.title} (${x.duration}):
${x.url}
`;
        y++;
        listURL.push(x.url);
    });
    var bodyText = "‍‍‍‍‍‍‍‍‍‍" + replaceMap(rlang("ytrs"), { "{0}": res });
    sendSearchTextThenImages(data, api, e2ee, adv, bodyText, thumbUrls, (a) => {
        if (!a || !a.messageID) return;
        let state = global.temp.youtube.ytmp3[data.threadID][data.senderID];
        if (!state) {
            state = {
                MID: a.messageID,
                MIDs: [a.messageID],
                list: listURL
            };
            global.temp.youtube.ytmp3[data.threadID][data.senderID] = state;
        } else {
            state.MIDs.push(a.messageID);
        }
    });
}

async function ytauto(data, api, e2ee, adv) {
    var {rlang, replaceMap, getThreadInfo} = adv;
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) {
        let adminL = normalizeAdminIDs((await getThreadInfo(data.threadID)).adminIDs);
        let check = adminL.indexOf(String(data.senderID)) != -1;
        if(!check) return adv.reply(rlang("noPer"));
    }
    let type = data.args[1];
    if(type != "auto" && type != "mp3" && type != "mp4" && type != "off") return adv.reply(replaceMap(rlang("adh"), {"{prefix}": global.config.facebook.prefix}));

    global.data.youtube.autodown[data.threadID] = type;

    if(type == "off") return adv.reply(rlang("autoOff"));

    adv.reply(replaceMap(rlang("autoOn"), {"{type}": type}));
}

async function chathook(data, api, e2ee, adv) {
    !global.temp.youtube ? global.temp.youtube = {} : "";
    !global.data.youtube ? global.data.youtube = {} : "";
    !global.temp.youtube.ytmp3 ? global.temp.youtube.ytmp3 = {} : "";
    !global.temp.youtube.ytmp3[data.threadID] ? global.temp.youtube.ytmp3[data.threadID] = {} : "";
    !global.temp.youtube.ytmp4 ? global.temp.youtube.ytmp4 = {} : "";
    !global.temp.youtube.ytmp4[data.threadID] ? global.temp.youtube.ytmp4[data.threadID] = {} : "";
    !global.data.youtube.autodown ? global.data.youtube.autodown = {} : "";
    !global.data.youtube.autodown[data.threadID] ? global.data.youtube.autodown[data.threadID] = adv.config.auto_download : "";

    if((data.type == "message" || data.type == "message_reply") && global.data.youtube.autodown[data.threadID] != "off" && data.body.indexOf("‍‍‍‍‍‍‍‍‍‍") != 0 && data.body.indexOf(global.config.facebook.prefix) != 0) {
        let args = data.body.split(" ");
        for(let i of args) {
            if(i.indexOf("youtube.com") != -1 || i.indexOf("youtu.be") != -1){
                const videoId = extractVideoId(i);
                if(!videoId) continue;

                if(global.data.youtube.autodown[data.threadID] == "auto"){
                    try{
                        const yt = await getYoutubeClient(adv.config);
                        const info = await yt.getBasicInfo(videoId, buildVideoInfoOptions(adv.config, 'WEB'));
                        const durationSec = getDurationSeconds(info);
                        return durationSec / 60 > 2 ? downmp3(data, api, e2ee, adv, i):downmp4(data, api, e2ee, adv, i);
                    } catch(e){continue;}
                }

                return global.data.youtube.autodown[data.threadID] == "mp3" ? downmp3(data, api, e2ee, adv, i):global.data.youtube.autodown[data.threadID] == "mp4" ? downmp4(data, api, e2ee, adv, i):"";
            }
        }
    }

    const isReply = data.type == "message_reply" || (data.type == "e2ee_message" && data.messageReply);
    if (!isReply || !global.temp.youtube || (!global.temp.youtube.ytmp3 && !global.temp.youtube.ytmp4)) return;
    if (!global.temp.youtube.ytmp3[data.threadID] && !global.temp.youtube.ytmp4[data.threadID]) return;

    const replyMessageId = data.messageReply ? (data.messageReply.messageID || data.messageReply.messageId) : null;

    if (global.temp.youtube.ytmp3[data.threadID][data.senderID] && replyMessageId == global.temp.youtube.ytmp3[data.threadID][data.senderID].MID) {
        let { rlang, replaceMap } = adv;
        const state = global.temp.youtube.ytmp3[data.threadID][data.senderID];
        let nb = Math.trunc(Number(data.body));
        if (!nb || nb < 1 || nb > state.list.length) return adv.reply(rlang("NaN"));
        nb--;

        safeUnsend(api, adv, data.threadID, state.MIDs || state.MID);

        downmp3(data, api, e2ee, adv, state.list[nb]);
        delete global.temp.youtube.ytmp3[data.threadID][data.senderID];
    } 
    if (global.temp.youtube.ytmp4[data.threadID][data.senderID] && replyMessageId == global.temp.youtube.ytmp4[data.threadID][data.senderID].MID) {
        let { rlang, replaceMap } = adv;
        const state = global.temp.youtube.ytmp4[data.threadID][data.senderID];
        let nb = Math.trunc(Number(data.body));
        if (!nb || nb < 1 || nb > state.list.length) return adv.reply(rlang("NaN"));
        nb--;

        safeUnsend(api, adv, data.threadID, state.MIDs || state.MID);

        downmp4(data, api, e2ee, adv, state.list[nb]);
        delete global.temp.youtube.ytmp4[data.threadID][data.senderID];
    }
}

async function downmp3(data, api, e2ee, adv, link) {
    var { rlang, replaceMap, config } = adv;
    var ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
    var ffmpeg = require('fluent-ffmpeg');
    var fs = require("fs");
    ffmpeg.setFfmpegPath(ffmpegPath);

    try {
        const yt = await getYoutubeClient(config);
        const videoId = extractVideoId(link) || link;
        if (!videoId) throw new Error("Invalid YouTube link");
        let info;
        try {
            info = await yt.getBasicInfo(videoId, buildVideoInfoOptions(config, 'WEB'));
        } catch (_) {
            try {
                info = await yt.getBasicInfo(videoId, buildVideoInfoOptions(config, 'ANDROID'));
            } catch (_) {}
        }
        if (!info) {
            try {
                info = await yt.getInfo(videoId, buildVideoInfoOptions(config, 'WEB'));
            } catch (_) {}
        }
        if (!info) throw new Error("Unable to fetch video info");
        const durationSec = getDurationSeconds(info);
        if (info?.basic_info?.is_live) {
            adv.reply(rlang("isLive"));
            return;
        }
        if (durationSec / 60 > 10) {
            adv.reply(replaceMap(rlang("more"), { "{m}": 10 }));
            return;
        }
        ensureExists(path.join(__dirname, "cache", "ytmp3"));
        const id = `${videoId}-${Date.now()}`;
        let sourcePath = path.join(__dirname, "cache", "ytmp3", id + ".source")
        let dirr = path.join(__dirname, "cache", "ytmp3", id + ".mp3")

        await saveAudioSourceToFileWithRetry(yt, info, videoId, sourcePath, config);

        let map = {
            "{0}": info?.basic_info?.title || "YouTube"
        }
        adv.reply(replaceMap(rlang("downloading"), map));

        const onConvertProgress = createFfmpegProgressLogger("ytmp3 convert");

        ffmpeg(sourcePath)
            .noVideo()
            .audioCodec('libmp3lame')
            .audioBitrate(128)
            .format('mp3')
            .save(dirr)
            .on('progress', onConvertProgress)
            .on('end', () => {
                if (typeof console.rewriteDone === "function") {
                    console.rewriteDone("YouTube", "ytmp3 convert done");
                } else {
                    console.log("ytmp3 convert done");
                }
                try { if (fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
                if (fs.statSync(dirr).size > 26214400) 
                    adv.reply(rlang("more25mb"), () => fs.unlinkSync(dirr))
                else adv.reply({
                    attachment: fs.createReadStream(dirr)
                }, () => {
                    try { if (fs.existsSync(dirr)) fs.unlinkSync(dirr); } catch (_) {}
                })
            })
            .on('error', (e) => {
                console.error("ytmp3 ffmpeg", e);
                try { if (fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
                try { if (fs.existsSync(dirr)) fs.unlinkSync(dirr); } catch (_) {}
                adv.reply(e && e.message ? e.message : rlang("error"));
            });
    } catch (err) {
        console.error("ytmp3", err && err.message ? err.message : err);
        adv.reply(err && err.message ? err.message : String(err))
    }
}

async function downmp4(data, api, e2ee, adv, link) {
    var { rlang, replaceMap, config } = adv;
    var ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
    var ffmpeg = require('fluent-ffmpeg');
    var fs = require("fs");
    ffmpeg.setFfmpegPath(ffmpegPath);
    let sourcePath = null;
    let dirMp4 = null;

    try {
        const yt = await getYoutubeClient(config);
        const videoId = extractVideoId(link) || link;
        if (!videoId) throw new Error("Invalid YouTube link");
        let info;
        try {
            info = await yt.getBasicInfo(videoId, buildVideoInfoOptions(config, 'WEB'));
        } catch (_) {
            try {
                info = await yt.getBasicInfo(videoId, buildVideoInfoOptions(config, 'ANDROID'));
            } catch (_) {}
        }
        if (!info) {
            try {
                info = await yt.getInfo(videoId, buildVideoInfoOptions(config, 'WEB'));
            } catch (_) {}
        }
        if (!info) throw new Error("Unable to fetch video info");
        ensureExists(path.join(__dirname, "cache", "ytmp4"));
        const id = `${videoId}-${Date.now()}`;
        sourcePath = path.join(__dirname, "cache", "ytmp4", `${id}.source`);
        dirMp4 = path.join(__dirname, "cache", "ytmp4", `${id}.mp4`);
        if (info?.basic_info?.is_live) {
            adv.reply(rlang("isLive"));
            return;
        }
        const durationSec = getDurationSeconds(info);
        if (durationSec / 60 > 6) {
            adv.reply(replaceMap(rlang("more"), { "{m}": 6 }));
            return;
        }

        let map = {
            "{0}": info?.basic_info?.title || "YouTube"
        }
        adv.reply(replaceMap(rlang("downloading"), map));

        await saveVideoSourceToFileWithRetry(yt, info, videoId, sourcePath, config);
        const onConvertProgress = createFfmpegProgressLogger("ytmp4 convert");
        ffmpeg(sourcePath)
            .videoCodec('libx264')
            .audioCodec('aac')
            .format('mp4')
            .save(dirMp4)
            .on('progress', onConvertProgress)
            .on('end', () => {
            if (typeof console.rewriteDone === "function") {
                console.rewriteDone("YouTube", "ytmp4 convert done");
            } else {
                console.log("ytmp4 convert done");
            }
            try { if (sourcePath && fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
            if (fs.statSync(dirMp4).size > 26214400) 
                adv.reply(rlang("more25mb"), () => fs.unlinkSync(dirMp4))
            else adv.reply({
                attachment: fs.createReadStream(dirMp4)
            }, () => {
                try { if (fs.existsSync(dirMp4)) fs.unlinkSync(dirMp4); } catch (_) {}
            })
        })
            .on('error', (e) => {
                console.error("ytmp4 ffmpeg", e);
                try { if (sourcePath && fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath); } catch (_) {}
                try { if (fs.existsSync(dirMp4)) fs.unlinkSync(dirMp4); } catch (_) {}
                adv.reply(e && e.message ? e.message : rlang("error"));
            });
    } catch (err) {
        console.error("ytmp4", err && err.message ? err.message : err);
        try {
            if (sourcePath && fs.existsSync(sourcePath)) fs.unlinkSync(sourcePath);
            if (dirMp4 && fs.existsSync(dirMp4)) fs.unlinkSync(dirMp4);
        } catch (_) {}
        adv.reply(err && err.message ? err.message : String(err));
    }
}

var search = async function (data, api, e2ee, adv) {
    let { rlang, replaceMap, config } = adv;
    var msg = data.body
    if (msg) {
        const items = await searchYoutubeVideos(msg, 6, config);
        let thumbUrls = [];
        var res = ``
        let y = 1;
        items.forEach((x) => {
            if (x.thumbUrl) thumbUrls.push(x.thumbUrl);
            res += `${y}. ${x.title} (${x.duration || "LIVE"}):
${x.url}
`;
            y++;
        });
        var bodyText = "‍‍‍‍‍‍‍‍‍‍" + replaceMap(rlang("srs"), { "{0}": res });
        sendSearchTextThenImages(data, api, e2ee, adv, bodyText, thumbUrls);
    }
    else {
        adv.reply(rlang("noMSG"));
    };
}

function ensureExists(path, mask) {
    var fs = require('fs');
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(path, {
            mode: mask,
            recursive: true
        });
        return;
    } catch (ex) {
        return {
            err: ex
        };
    }
}

module.exports = {
    ytmp4,
    ytmp3,
    chathook,
    ytauto,
    search
};
