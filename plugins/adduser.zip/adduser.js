const { error } = require("npmlog");

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === "object") ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

async function cmd1(data, api, e2ee, adv) {
    const {rlang, replaceMap} = adv;
    const axios = require("axios");

    async function getFacebookUID(link, api, data) {
        if (!link) {
            return adv.reply(rlang("noLink"));
        }
        const apiUrl = "https://fbuid.mktsoftware.net/api/v1/fbprofile?url=" + link;
        try {
            const response = await axios.get(apiUrl);
            const uid = response.data.uid;
            try {
                let res = await api.getThreadInfo(data.threadID)
                for (let i in res.participantIDs) {
                    let x = res.participantIDs[i];
                    if (x == uid) {
                        return adv.reply(rlang("present"))
                    }
                }
                var adminis = false;
                for (let x of normalizeAdminIDs(res.adminIDs)) {
                    if (x == api.getCurrentUserID()) {
                        return adminis = true
                    }
                }
                if (adminis == false && res.approvalMode == true) {
                    try {
                        await new Promise((resolve, reject) => {
                            api.addUserToGroup(uid, data.threadID, (err) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve();
                                }
                            });
                        });
                        adv.reply(rlang("addPending"));

                    } catch (error) {
                        console.error("adduser", error);
                        const errorMessage = error.message ? error.message : rlang("cantAdd");
                        adv.reply(errorMessage);
                    }
                    return;
                }
            } catch {
                console.log(error)
            }
            try {
                await new Promise((resolve, reject) => {
                    api.addUserToGroup(uid, data.threadID, (err) => {
                        if (err) {
                            reject(err);
                        } else {
                            resolve();
                        }
                    });
                });
                return adv.reply("Đã thêm vào nhóm thành công!");

            } catch (error) {
                console.error("Lỗi thêm vào nhóm:", error);
                const errorMessage = error.message ? error.message : rlang("cantAdd");
                adv.reply(errorMessage);
            }

        } catch (error) {
            console.error("adduser", error);
            const errorMessage = error.message ? error.message : rlang("invalidUser");
            adv.reply(errorMessage);
        }
    }

    const link = data.args[1];
    const bieuThucURL = new RegExp(
        "^(?:http(s)?:\\/\\/)?([\\w.-]+(?:\\.[\\w\\.-]+)+)([\\w-._~:/?#[\\]@!$&'()*+,;=]*)",
        "i"
    );
    if (bieuThucURL.test(link)) {
        return getFacebookUID(link, api, data);
    } else if (/^\d+$/.test(link)) {
        return getFacebookUID("https://www.facebook.com/" + link, api, data);
    } else {
        return adv.reply(rlang("noLink"));
    }


}


module.exports = {
    cmd1,
};