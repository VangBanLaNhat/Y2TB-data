
async function mainv1(data, api, adv) {
	//console.log(adv.config.apiKey);
	let {config, rlang} = adv;
	if(config.apiKey == "" || !config.apiKey) return api.sendMessage(rlang("nokey"), data.threadID, data.messageID);
	if(data.body == "") return api.sendMessage(rlang("noinput"), data.threadID, data.messageID);
	!global.data.openai ? global.data.openai = {}:"";
	!global.data.openai.chatgpt ? global.data.openai.chatgpt = {}:"";
	!global.data.openai.chatgpt[data.threadID] ? global.data.openai.chatgpt[data.threadID] = []:"";
	const { Configuration, OpenAI } = require("openai");
	/*const configuration = new Configuration({
		apiKey: config.apiKey,
	});*/
	const openai = new OpenAI ({
		apiKey: config.apiKey
	});
	
	try{
		/*global.data.openai.chatgpt[data.threadID].push({
			"role": "user",
			"content": data.body
		});*/
		console.log(data.body);
		let api_res = await openai.chat.completions.create({
			model: "gpt-3.5-turbo",
			prompt: data.body,
			temperature: 0.7
			//max_tokens: 2049
		})
		
		//global.data.openai.chatgpt[data.threadID].push(api_res.data.choices[0].message);
		//console.log(api_res.data.choices[0].text);
		api.sendMessage(api_res.choices[0].text.toString(), data.threadID, data.messageID);
	} catch(e){
		console.log(e);
		/*console.error("ChatGPT", e.error.message);
		
		return api.sendMessage(e.error.message, data.threadID, data.messageID);*/
	}
}

async function main(data, api, adv, ii) {
	//console.log(adv.config.apiKey);
	let {config, rlang} = adv;
	if(config.apiKey == "" || !config.apiKey) return api.sendMessage(rlang("nokey"), data.threadID, data.messageID);
	if(data.body == "") return api.sendMessage(rlang("noinput"), data.threadID, data.messageID);
	!global.data.openai ? global.data.openai = {}:"";
	!global.data.openai.chatgpt ? global.data.openai.chatgpt = {}:"";
	!global.data.openai.chatgpt[data.threadID] ? global.data.openai.chatgpt[data.threadID] = []:"";
	
	!global.openai ? global.openai = {}:"";
	!global.openai.timeout ? global.openai.timeout = {}:"";
	!global.openai.timeout.chatgpt ? global.openai.timeout.chatgpt = {}:"";
	
	const { Configuration, OpenAI } = require("openai");
	/*const configuration = new Configuration({
		apiKey: config.apiKey,
	});*/
	const openai = new OpenAI ({
		apiKey: config.apiKey
	});
	
	if(!global.openai.timeout.chatgpt[data.threadID])
		global.openai.timeout.chatgpt[data.threadID] = setTimeout(function() {
				global.data.openai.chatgpt[data.threadID] = [];
				api.sendMessage("Deleted chat data with ChatGPT in this Thread", data.threadID, data.messageID);
		}, 1*30*60*1000);
	
	try{
		global.data.openai.chatgpt[data.threadID].push({
			"role": "user",
			"content": data.body
		});
		//console.log(data.body);
		let api_res = await openai.chat.completions.create({
			model: "gpt-3.5-turbo-16k",
			messages: global.data.openai.chatgpt[data.threadID],
			max_tokens: 2049 - data.body.length
		})
		
		if(api_res.choices[0].message.content.toString().length <= 1000){
			global.data.openai.chatgpt[data.threadID].push(api_res.choices[0].message);
		}
		//console.log(api_res.data.choices[0].text);
		api.sendMessage(api_res.choices[0].message.content.toString(), data.threadID, data.messageID);
	} catch(e){
		console.log(e)
		if(e.error){
			console.error("ChatGPT", e.error.message);
		
			return api.sendMessage(e.error.message, data.threadID, data.messageID);
		}
		
		ii = !ii?0:ii;
		if(ii > 20) {
			console.error("ChatGPT", e);
			return api.sendMessage(e, data.threadID, data.messageID);
		}
		global.data.openai.chatgpt[data.threadID].shift();
		global.data.openai.chatgpt[data.threadID].shift();
		return main(data, api, adv, ii+1);
	}
}

function del(data, api, adv){
	let {rlang} = adv;
	!global.data.openai ? global.data.openai = {}:"";
	!global.data.openai.chatgpt ? global.data.openai.chatgpt = {}:"";
	global.data.openai.chatgpt[data.threadID] = [];
	try{
		clearTimeout(global.openai.timeout.chatgpt[data.threadID]);
	} catch(_){};
	api.sendMessage(rlang("deldata"), data.threadID, data.messageID);
}

function ensureExists(path, mask) {
	if (typeof mask != 'number') {
		mask = 0o777;
	}
	try {
		fs.mkdirSync(path, {
			mode: mask,
			recursive: true
		});
		return;
	} catch (ex) {
		return {
			err: ex
		};
	}
}

module.exports = {
	del,
	main,
	mainv1,
};
