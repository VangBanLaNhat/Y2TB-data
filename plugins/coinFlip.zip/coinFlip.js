
function isE2EEThread(adv, threadID) {
    if (!adv || !adv.e2ee || typeof adv.e2ee.isE2EEThread !== "function") return false;
    return adv.e2ee.isE2EEThread(threadID);
}

function sendText(api, adv, threadID, text, replyMessageID, callback) {
    if (adv && adv.e2ee && typeof adv.e2ee.sendText === "function") {
        adv.e2ee.sendText(threadID, text, replyMessageID)
            .then((res) => { if (typeof callback === "function") callback(null, res); })
            .catch((err) => { if (typeof callback === "function") callback(err); });
        return;
    }
    return adv.reply(text, callback);
}

function main(data, api, e2ee, adv) {
    let { rlang, replaceMap } = adv;
	if (!global.data.economy) return adv.reply("The Economy plugin has never been installed. Please ask your BotChat admin to install the Economy plugin to use this command!");
	
	let type = data.args[1];
	let bet = Number(data.args[2]);
	
	switch (type) {
	    case 's':
	    case 't':
	        type = 0;
	        break;
	    case 'n':
	    case 'h':
	        type = 1;
	        break;
	    default:
            return adv.reply(replaceMap(rlang("wrong"), {
                "{prefix}": global.config.facebook.prefix
            }))
	}
    !global.data.economy[data.senderID] ? global.data.economy[data.senderID] = {coin: 0}:"";
    if (bet && bet < 0) bet = 0;
    if (bet && bet > global.data.economy[data.senderID].coin) return adv.reply(replaceMap(rlang("nem"), {
        "{money}": global.data.economy[data.senderID].coin+global.data.economyConfig.icon
    }));
    if (!bet) bet = 0;
    
    let res = randomInt(0, 1);
    if (res == type) global.data.economy[data.senderID].coin += bet;
    else global.data.economy[data.senderID].coin -= bet;
    
    let arr = rlang("order").split('|');
    
    let map = {
        "{isWin}": (res == type ? arr[0]:arr[1]) + (bet > 0 ? " "+bet+global.data.economyConfig.icon:""),
        "{res}": arr[2+res],
        "{money}": global.data.economy[data.senderID].coin+global.data.economyConfig.icon
    }
    
    sendText(api, adv, data.threadID, rlang("tossing"), data.messageID, (e, a) => setTimeout(() => {
            if (!isE2EEThread(adv, data.threadID) && api.editMessage && a && a.messageID) {
                api.editMessage(replaceMap(rlang("res"), map), a.messageID);
            } else {
                sendText(api, adv, data.threadID, replaceMap(rlang("res"), map), data.messageID);
            }
        }, 2 * 1000)
    )
}

// Functions support

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Module exports

module.exports = {
    main
};