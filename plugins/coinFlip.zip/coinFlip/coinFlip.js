
function main(data, api, {rlang, replaceMap}) {
	if (!global.data.economy) return api.sendMessage("The Economy plugin has never been installed. Please ask your BotChat admin to install the Economy plugin to use this command!", data.threadID, data.messageID);
	
	let type = data.args[1];
	let bet = Number(data.args[2]);
	
	switch (type) {
	    case 's':
	    case 't':
	        type = 0;
	        break;
	    case 'n':
	    case 'h':
	        type = 1;
	        break;
	    default:
            return api.sendMessage(replaceMap(rlang("wrong"), {
                "{prefix}": global.config.facebook.prefix
            }), data.threadID, data.messageID)
	}
    !global.data.economy[data.senderID] ? global.data.economy[data.senderID] = {coin: 0}:"";
    if (bet && bet < 0) bet = 0;
    if (bet && bet > global.data.economy[data.senderID].coin) return api.sendMessage(replaceMap(rlang("nem"), {
        "{money}": global.data.economy[data.senderID].coin+global.data.economyConfig.icon
    }), data.threadID, data.messageID);
    if (!bet) bet = 0;
    
    let res = randomInt(0, 1);
    if (res == type) global.data.economy[data.senderID].coin += bet;
    else global.data.economy[data.senderID].coin -= bet;
    
    let arr = rlang("order").split('|');
    
    let map = {
        "{isWin}": (res == type ? arr[0]:arr[1]) + (bet > 0 ? " "+bet+global.data.economyConfig.icon:""),
        "{res}": arr[2+res],
        "{money}": global.data.economy[data.senderID].coin+global.data.economyConfig.icon
    }
    
    api.sendMessage(rlang("tossing"), data.threadID, (e, a)=>setTimeout(()=>{
            if(api.editMessage) api.editMessage(replaceMap(rlang("res"), map), a.messageID);
            else api.sendMessage(replaceMap(rlang("res"), map), data.threadID, data.messageID);
        }, 2*1000)
    , data.messageID)
}

// Functions support

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Module exports

module.exports = {
    main
};