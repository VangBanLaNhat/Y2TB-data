const fs = require('fs');
const path = require('path');
const axios = require('axios');

const CACHE_DIR = path.join(__dirname, 'cache', 'groupManager');

function ensureExists(dirPath, mask) {
    if (typeof mask !== 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(dirPath, {
            mode: mask,
            recursive: true
        });
    } catch (ex) {
        return {
            err: ex
        };
    }
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === 'object') ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

function replaceMap(str, map) {
    let out = String(str || '');
    if (!map || typeof map !== 'object') return out;
    for (const key in map) {
        out = out.replaceAll(key, String(map[key]));
    }
    return out;
}

function t(adv, key, map) {
    try {
        if (adv && typeof adv.rlang === 'function') {
            return replaceMap(adv.rlang(key), map);
        }
    } catch (_) { }
    return replaceMap(key, map);
}

function getConfig(config) {
    const fallback = {
        allowMemberSelfNickname: true,
        requireAdminForGroupActions: true,
        requireAdminToChangeOtherNickname: true
    };

    if (!config || typeof config !== 'object') return fallback;

    return {
        allowMemberSelfNickname: config.allowMemberSelfNickname !== false,
        requireAdminForGroupActions: config.requireAdminForGroupActions !== false,
        requireAdminToChangeOtherNickname: config.requireAdminToChangeOtherNickname !== false
    };
}

function isGroupMessage(data) {
    if (typeof data.isGroup === 'boolean') return data.isGroup;
    return String(data.threadID) !== String(data.senderID);
}

function getMentionID(data) {
    if (!data || !data.mentions || typeof data.mentions !== 'object') return '';
    const ids = Object.keys(data.mentions);
    return ids.length ? ids[0] : '';
}

function getMentionName(data, mentionID) {
    if (!mentionID || !data || !data.mentions) return 'user';
    return data.mentions[mentionID].name || data.mentions[mentionID] || 'user';
}

function hasBotAdminPermission(senderID) {
    return Array.isArray(global.config.facebook.admin)
        && global.config.facebook.admin.indexOf(String(senderID)) !== -1;
}

function isThreadAdmin(userID, threadInfo) {
    const adminIDs = normalizeAdminIDs(threadInfo && threadInfo.adminIDs);
    return adminIDs.indexOf(String(userID)) !== -1;
}

async function getThreadInfoSafe(data, api, e2ee, adv) {
    try {
        if (adv && typeof adv.getThreadInfo === 'function') {
            return await adv.getThreadInfo(data.threadID);
        }
    } catch (_) { }

    try {
        return await api.getThreadInfo(data.threadID);
    } catch (_) {
        return null;
    }
}

async function getPermissionContext(data, api, e2ee, adv) {
    const threadInfo = await getThreadInfoSafe(data, api, e2ee, adv);
    if (!threadInfo) {
        return {
            ok: false,
            msg: t(adv, 'threadInfoError')
        };
    }

    const senderIsAdmin = hasBotAdminPermission(data.senderID) || isThreadAdmin(data.senderID, threadInfo);
    const botIsAdmin = isThreadAdmin(api.getCurrentUserID(), threadInfo);

    return {
        ok: true,
        threadInfo,
        senderIsAdmin,
        botIsAdmin
    };
}

function getArgText(data, startIndex) {
    if (!data || !Array.isArray(data.args)) return '';
    return data.args.slice(startIndex).join(' ').trim();
}

function buildGmUsage(adv) {
    return t(adv, 'gmUsage', {
        '{prefix}': global.config.facebook.prefix
    });
}

function toSubcommandData(data) {
    if (!data || !Array.isArray(data.args)) return data;
    return {
        ...data,
        args: [data.args[0], ...data.args.slice(2)]
    };
}

async function main(data, api, e2ee, adv) {
    const action = Array.isArray(data.args) && data.args[1]
        ? String(data.args[1]).toLowerCase()
        : '';

    if (!action || action === 'help' || action === 'h') {
        return adv.reply(buildGmUsage(adv));
    }

    const subData = toSubcommandData(data);
    switch (action) {
        case 'name':
        case 'rename':
            return changeGroupName(subData, api, adv);

        case 'nick':
        case 'nickname':
            return changeNickName(subData, api, adv);

        case 'img':
        case 'image':
        case 'avatar':
            return changeGroupImage(subData, api, adv);

        case 'emoji':
            return changeGroupEmoji(subData, api, adv);

        case 'kick':
        case 'out':
            return removeUser(subData, api, adv);

        case 'qtv':
        case 'admin':
            return addAdmin(subData, api, adv);

        default:
            return adv.reply(t(adv, 'gmUnknownAction', {
                '{action}': action,
                '{usage}': buildGmUsage(adv),
                '{prefix}': global.config.facebook.prefix
            }));
    }
}

async function changeNickName(data, api, e2ee, adv) {
    if (!isGroupMessage(data)) {
        return adv.reply(t(adv, 'groupOnly'));
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, e2ee, adv);
    if (!permission.ok) return adv.reply(permission.msg);

    const mentionID = getMentionID(data);
    let nickname = getArgText(data, 1);

    if (mentionID) {
        const mentionName = getMentionName(data, mentionID);
        nickname = nickname.replace(mentionName, '').trim();
    }

    if (!nickname) {
        return adv.reply(t(adv, 'nicknameUsage', {
            '{prefix}': global.config.facebook.prefix
        }));
    }

    if (!mentionID && !cfg.allowMemberSelfNickname && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }

    if (mentionID && cfg.requireAdminToChangeOtherNickname && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }

    const targetID = mentionID || data.senderID;
    try {
        await api.changeNickname(nickname, data.threadID, targetID);
        if (!mentionID) {
            return adv.reply(t(adv, 'nicknameUpdatedSelf', {
                '{name}': nickname
            }));
        }

        return adv.reply(t(adv, 'nicknameUpdatedTarget', {
            '{user}': getMentionName(data, mentionID),
            '{name}': nickname
        }));
    } catch (err) {
        console.error('groupManager changeNickName', err);
        return adv.reply(t(adv, 'nicknameFailed'));
    }
}

async function changeGroupName(data, api, e2ee, adv) {
    if (!isGroupMessage(data)) {
        return adv.reply(t(adv, 'groupOnly'));
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, e2ee, adv);
    if (!permission.ok) return adv.reply(permission.msg);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }

    const name = getArgText(data, 1);
    if (!name) {
        return adv.reply(t(adv, 'nameUsage', {
            '{prefix}': global.config.facebook.prefix
        }));
    }

    try {
        await api.setTitle(name, data.threadID);
        return adv.reply(t(adv, 'nameUpdated', {
            '{name}': name
        }));
    } catch (err) {
        console.error('groupManager changeGroupName', err);
        return adv.reply(t(adv, 'nameFailed'));
    }
}

function getReplyPhoto(data) {
    if (!data || data.type !== 'message_reply' || !data.messageReply) return null;
    const atts = Array.isArray(data.messageReply.attachments) ? data.messageReply.attachments : [];
    return atts.find((item) => item && item.type === 'photo' && item.url);
}

async function downloadFile(url, destPath) {
    const response = await axios({
        method: 'get',
        url,
        responseType: 'stream',
        timeout: 120000
    });

    await new Promise((resolve, reject) => {
        const writer = fs.createWriteStream(destPath);
        response.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
        response.data.on('error', reject);
    });
}

async function changeGroupImage(data, api, e2ee, adv) {
    if (!isGroupMessage(data)) {
        return adv.reply(t(adv, 'groupOnly'));
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, e2ee, adv);
    if (!permission.ok) return adv.reply(permission.msg);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }

    const replyPhoto = getReplyPhoto(data);
    if (!replyPhoto) {
        if (data.type !== 'message_reply') {
            return adv.reply(t(adv, 'imageReplyRequired', {
                '{prefix}': global.config.facebook.prefix
            }));
        }
        return adv.reply(t(adv, 'imageOnly'));
    }

    ensureExists(CACHE_DIR);
    const tempPath = path.join(CACHE_DIR, `${data.threadID}_${Date.now()}.jpg`);

    try {
        await downloadFile(replyPhoto.url, tempPath);
        await api.changeGroupImage(fs.createReadStream(tempPath), data.threadID);
        return adv.reply(t(adv, 'imageUpdated'));
    } catch (err) {
        console.error('groupManager changeGroupImage', err);
        return adv.reply(t(adv, 'imageFailed'));
    } finally {
        try {
            if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        } catch (_) { }
    }
}

async function changeGroupEmoji(data, api, e2ee, adv) {
    if (!isGroupMessage(data)) {
        return adv.reply(t(adv, 'groupOnly'));
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, e2ee, adv);
    if (!permission.ok) return adv.reply(permission.msg);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }

    const emoji = getArgText(data, 1);
    if (!emoji) {
        return adv.reply(t(adv, 'emojiUsage', {
            '{prefix}': global.config.facebook.prefix
        }));
    }

    try {
        await api.changeThreadEmoji(emoji, data.threadID);
        return adv.reply(t(adv, 'emojiUpdated', {
            '{emoji}': emoji
        }));
    } catch (err) {
        console.error('groupManager changeGroupEmoji', err);
        return adv.reply(t(adv, 'emojiFailed'));
    }
}

async function removeUser(data, api, e2ee, adv) {
    if (!isGroupMessage(data)) {
        return adv.reply(t(adv, 'groupOnly'));
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, e2ee, adv);
    if (!permission.ok) return adv.reply(permission.msg);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }
    if (!permission.botIsAdmin) {
        return adv.reply(t(adv, 'botNotAdmin'));
    }

    const mentionID = getMentionID(data);
    if (!mentionID) {
        return adv.reply(t(adv, 'kickUsage', {
            '{prefix}': global.config.facebook.prefix
        }));
    }

    try {
        await api.removeUserFromGroup(mentionID, data.threadID);
        return adv.reply(t(adv, 'kickDone', {
            '{user}': getMentionName(data, mentionID)
        }));
    } catch (err) {
        console.error('groupManager removeUser', err);
        return adv.reply(t(adv, 'kickFailed'));
    }
}

async function addAdmin(data, api, e2ee, adv) {
    if (!isGroupMessage(data)) {
        return adv.reply(t(adv, 'groupOnly'));
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, e2ee, adv);
    if (!permission.ok) return adv.reply(permission.msg);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return adv.reply(t(adv, 'noPermission'));
    }
    if (!permission.botIsAdmin) {
        return adv.reply(t(adv, 'botNotAdmin'));
    }

    const action = (Array.isArray(data.args) && data.args[1] ? data.args[1].toLowerCase() : '');
    const mentionID = getMentionID(data);
    if ((action !== 'add' && action !== 'remove') || !mentionID) {
        return adv.reply(t(adv, 'adminUsage', {
            '{prefix}': global.config.facebook.prefix
        }));
    }

    const targetIsAdmin = isThreadAdmin(mentionID, permission.threadInfo);
    if (action === 'add' && targetIsAdmin) {
        return adv.reply(t(adv, 'targetAlreadyAdmin'));
    }
    if (action === 'remove' && !targetIsAdmin) {
        return adv.reply(t(adv, 'targetNotAdmin'));
    }

    try {
        await api.changeAdminStatus(data.threadID, mentionID, action === 'add');
        if (action === 'add') {
            return adv.reply(t(adv, 'adminAdded', {
                '{user}': getMentionName(data, mentionID)
            }));
        }
        return adv.reply(t(adv, 'adminRemoved', {
            '{user}': getMentionName(data, mentionID)
        }));
    } catch (err) {
        console.error('groupManager addAdmin', err);
        return adv.reply(t(adv, 'adminChangeFailed'));
    }
}

async function np(data, api, e2ee, adv) {
    if (data.type === 'read_receipt') return;
    if (data.type === 'typ') return;
}

module.exports = {
    main,
    np,
    changeNickName,
    changeGroupName,
    changeGroupImage,
    changeGroupEmoji,
    removeUser,
    addAdmin
};