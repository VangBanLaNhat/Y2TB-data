const fs = require('fs');
const path = require('path');
const axios = require('axios');

const CACHE_DIR = path.join(__dirname, 'cache', 'groupManager');

function ensureExists(dirPath, mask) {
    if (typeof mask !== 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(dirPath, {
            mode: mask,
            recursive: true
        });
    } catch (ex) {
        return {
            err: ex
        };
    }
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === 'object') ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

function replaceMap(str, map) {
    let out = String(str || '');
    if (!map || typeof map !== 'object') return out;
    for (const key in map) {
        out = out.replaceAll(key, String(map[key]));
    }
    return out;
}

function t(adv, key, map) {
    try {
        if (adv && typeof adv.rlang === 'function') {
            return replaceMap(adv.rlang(key), map);
        }
    } catch (_) { }
    return replaceMap(key, map);
}

function getConfig(config) {
    const fallback = {
        allowMemberSelfNickname: true,
        requireAdminForGroupActions: true,
        requireAdminToChangeOtherNickname: true
    };

    if (!config || typeof config !== 'object') return fallback;

    return {
        allowMemberSelfNickname: config.allowMemberSelfNickname !== false,
        requireAdminForGroupActions: config.requireAdminForGroupActions !== false,
        requireAdminToChangeOtherNickname: config.requireAdminToChangeOtherNickname !== false
    };
}

function isGroupMessage(data) {
    if (typeof data.isGroup === 'boolean') return data.isGroup;
    return String(data.threadID) !== String(data.senderID);
}

function getMentionID(data) {
    if (!data || !data.mentions || typeof data.mentions !== 'object') return '';
    const ids = Object.keys(data.mentions);
    return ids.length ? ids[0] : '';
}

function getMentionName(data, mentionID) {
    if (!mentionID || !data || !data.mentions) return 'user';
    return data.mentions[mentionID].name || data.mentions[mentionID] || 'user';
}

function hasBotAdminPermission(senderID) {
    return Array.isArray(global.config.facebook.admin)
        && global.config.facebook.admin.indexOf(String(senderID)) !== -1;
}

function isThreadAdmin(userID, threadInfo) {
    const adminIDs = normalizeAdminIDs(threadInfo && threadInfo.adminIDs);
    return adminIDs.indexOf(String(userID)) !== -1;
}

async function getThreadInfoSafe(data, api, adv) {
    try {
        if (adv && typeof adv.getThreadInfo === 'function') {
            return await adv.getThreadInfo(data.threadID);
        }
    } catch (_) { }

    try {
        return await api.getThreadInfo(data.threadID);
    } catch (_) {
        return null;
    }
}

async function getPermissionContext(data, api, adv) {
    const threadInfo = await getThreadInfoSafe(data, api, adv);
    if (!threadInfo) {
        return {
            ok: false,
            msg: t(adv, 'threadInfoError')
        };
    }

    const senderIsAdmin = hasBotAdminPermission(data.senderID) || isThreadAdmin(data.senderID, threadInfo);
    const botIsAdmin = isThreadAdmin(api.getCurrentUserID(), threadInfo);

    return {
        ok: true,
        threadInfo,
        senderIsAdmin,
        botIsAdmin
    };
}

function getArgText(data, startIndex) {
    if (!data || !Array.isArray(data.args)) return '';
    return data.args.slice(startIndex).join(' ').trim();
}

function buildGmUsage(adv) {
    return t(adv, 'gmUsage', {
        '{prefix}': global.config.facebook.prefix
    });
}

function toSubcommandData(data) {
    if (!data || !Array.isArray(data.args)) return data;
    return {
        ...data,
        args: [data.args[0], ...data.args.slice(2)]
    };
}

async function main(data, api, adv) {
    const action = Array.isArray(data.args) && data.args[1]
        ? String(data.args[1]).toLowerCase()
        : '';

    if (!action || action === 'help' || action === 'h') {
        return api.sendMessage(buildGmUsage(adv), data.threadID, data.messageID);
    }

    const subData = toSubcommandData(data);
    switch (action) {
        case 'name':
        case 'rename':
            return changeGroupName(subData, api, adv);

        case 'nick':
        case 'nickname':
            return changeNickName(subData, api, adv);

        case 'img':
        case 'image':
        case 'avatar':
            return changeGroupImage(subData, api, adv);

        case 'emoji':
            return changeGroupEmoji(subData, api, adv);

        case 'kick':
        case 'out':
            return removeUser(subData, api, adv);

        case 'qtv':
        case 'admin':
            return addAdmin(subData, api, adv);

        default:
            return api.sendMessage(t(adv, 'gmUnknownAction', {
                '{action}': action,
                '{usage}': buildGmUsage(adv),
                '{prefix}': global.config.facebook.prefix
            }), data.threadID, data.messageID);
    }
}

async function changeNickName(data, api, adv) {
    if (!isGroupMessage(data)) {
        return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, adv);
    if (!permission.ok) return api.sendMessage(permission.msg, data.threadID, data.messageID);

    const mentionID = getMentionID(data);
    let nickname = getArgText(data, 1);

    if (mentionID) {
        const mentionName = getMentionName(data, mentionID);
        nickname = nickname.replace(mentionName, '').trim();
    }

    if (!nickname) {
        return api.sendMessage(t(adv, 'nicknameUsage', {
            '{prefix}': global.config.facebook.prefix
        }), data.threadID, data.messageID);
    }

    if (!mentionID && !cfg.allowMemberSelfNickname && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }

    if (mentionID && cfg.requireAdminToChangeOtherNickname && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }

    const targetID = mentionID || data.senderID;
    try {
        await api.changeNickname(nickname, data.threadID, targetID);
        if (!mentionID) {
            return api.sendMessage(t(adv, 'nicknameUpdatedSelf', {
                '{name}': nickname
            }), data.threadID, data.messageID);
        }

        return api.sendMessage(t(adv, 'nicknameUpdatedTarget', {
            '{user}': getMentionName(data, mentionID),
            '{name}': nickname
        }), data.threadID, data.messageID);
    } catch (err) {
        console.error('groupManager changeNickName', err);
        return api.sendMessage(t(adv, 'nicknameFailed'), data.threadID, data.messageID);
    }
}

async function changeGroupName(data, api, adv) {
    if (!isGroupMessage(data)) {
        return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, adv);
    if (!permission.ok) return api.sendMessage(permission.msg, data.threadID, data.messageID);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }

    const name = getArgText(data, 1);
    if (!name) {
        return api.sendMessage(t(adv, 'nameUsage', {
            '{prefix}': global.config.facebook.prefix
        }), data.threadID, data.messageID);
    }

    try {
        await api.setTitle(name, data.threadID);
        return api.sendMessage(t(adv, 'nameUpdated', {
            '{name}': name
        }), data.threadID, data.messageID);
    } catch (err) {
        console.error('groupManager changeGroupName', err);
        return api.sendMessage(t(adv, 'nameFailed'), data.threadID, data.messageID);
    }
}

function getReplyPhoto(data) {
    if (!data || data.type !== 'message_reply' || !data.messageReply) return null;
    const atts = Array.isArray(data.messageReply.attachments) ? data.messageReply.attachments : [];
    return atts.find((item) => item && item.type === 'photo' && item.url);
}

async function downloadFile(url, destPath) {
    const response = await axios({
        method: 'get',
        url,
        responseType: 'stream',
        timeout: 120000
    });

    await new Promise((resolve, reject) => {
        const writer = fs.createWriteStream(destPath);
        response.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
        response.data.on('error', reject);
    });
}

async function changeGroupImage(data, api, adv) {
    if (!isGroupMessage(data)) {
        return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, adv);
    if (!permission.ok) return api.sendMessage(permission.msg, data.threadID, data.messageID);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }

    const replyPhoto = getReplyPhoto(data);
    if (!replyPhoto) {
        if (data.type !== 'message_reply') {
            return api.sendMessage(t(adv, 'imageReplyRequired', {
                '{prefix}': global.config.facebook.prefix
            }), data.threadID, data.messageID);
        }
        return api.sendMessage(t(adv, 'imageOnly'), data.threadID, data.messageID);
    }

    ensureExists(CACHE_DIR);
    const tempPath = path.join(CACHE_DIR, `${data.threadID}_${Date.now()}.jpg`);

    try {
        await downloadFile(replyPhoto.url, tempPath);
        await api.changeGroupImage(fs.createReadStream(tempPath), data.threadID);
        return api.sendMessage(t(adv, 'imageUpdated'), data.threadID, data.messageID);
    } catch (err) {
        console.error('groupManager changeGroupImage', err);
        return api.sendMessage(t(adv, 'imageFailed'), data.threadID, data.messageID);
    } finally {
        try {
            if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        } catch (_) { }
    }
}

async function changeGroupEmoji(data, api, adv) {
    if (!isGroupMessage(data)) {
        return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, adv);
    if (!permission.ok) return api.sendMessage(permission.msg, data.threadID, data.messageID);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }

    const emoji = getArgText(data, 1);
    if (!emoji) {
        return api.sendMessage(t(adv, 'emojiUsage', {
            '{prefix}': global.config.facebook.prefix
        }), data.threadID, data.messageID);
    }

    try {
        await api.changeThreadEmoji(emoji, data.threadID);
        return api.sendMessage(t(adv, 'emojiUpdated', {
            '{emoji}': emoji
        }), data.threadID, data.messageID);
    } catch (err) {
        console.error('groupManager changeGroupEmoji', err);
        return api.sendMessage(t(adv, 'emojiFailed'), data.threadID, data.messageID);
    }
}

async function removeUser(data, api, adv) {
    if (!isGroupMessage(data)) {
        return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, adv);
    if (!permission.ok) return api.sendMessage(permission.msg, data.threadID, data.messageID);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }
    if (!permission.botIsAdmin) {
        return api.sendMessage(t(adv, 'botNotAdmin'), data.threadID, data.messageID);
    }

    const mentionID = getMentionID(data);
    if (!mentionID) {
        return api.sendMessage(t(adv, 'kickUsage', {
            '{prefix}': global.config.facebook.prefix
        }), data.threadID, data.messageID);
    }

    try {
        await api.removeUserFromGroup(mentionID, data.threadID);
        return api.sendMessage(t(adv, 'kickDone', {
            '{user}': getMentionName(data, mentionID)
        }), data.threadID, data.messageID);
    } catch (err) {
        console.error('groupManager removeUser', err);
        return api.sendMessage(t(adv, 'kickFailed'), data.threadID, data.messageID);
    }
}

async function addAdmin(data, api, adv) {
    if (!isGroupMessage(data)) {
        return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
    }

    const cfg = getConfig(adv && adv.config);
    const permission = await getPermissionContext(data, api, adv);
    if (!permission.ok) return api.sendMessage(permission.msg, data.threadID, data.messageID);
    if (cfg.requireAdminForGroupActions && !permission.senderIsAdmin) {
        return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
    }
    if (!permission.botIsAdmin) {
        return api.sendMessage(t(adv, 'botNotAdmin'), data.threadID, data.messageID);
    }

    const action = (Array.isArray(data.args) && data.args[1] ? data.args[1].toLowerCase() : '');
    const mentionID = getMentionID(data);
    if ((action !== 'add' && action !== 'remove') || !mentionID) {
        return api.sendMessage(t(adv, 'adminUsage', {
            '{prefix}': global.config.facebook.prefix
        }), data.threadID, data.messageID);
    }

    const targetIsAdmin = isThreadAdmin(mentionID, permission.threadInfo);
    if (action === 'add' && targetIsAdmin) {
        return api.sendMessage(t(adv, 'targetAlreadyAdmin'), data.threadID, data.messageID);
    }
    if (action === 'remove' && !targetIsAdmin) {
        return api.sendMessage(t(adv, 'targetNotAdmin'), data.threadID, data.messageID);
    }

    try {
        await api.changeAdminStatus(data.threadID, mentionID, action === 'add');
        if (action === 'add') {
            return api.sendMessage(t(adv, 'adminAdded', {
                '{user}': getMentionName(data, mentionID)
            }), data.threadID, data.messageID);
        }
        return api.sendMessage(t(adv, 'adminRemoved', {
            '{user}': getMentionName(data, mentionID)
        }), data.threadID, data.messageID);
    } catch (err) {
        console.error('groupManager addAdmin', err);
        return api.sendMessage(t(adv, 'adminChangeFailed'), data.threadID, data.messageID);
    }
}

async function np(data, api, adv) {
    if (data.type === 'read_receipt') return;
    if (data.type === 'typ') return;
}

module.exports = {
    main,
    np,
    changeNickName,
    changeGroupName,
    changeGroupImage,
    changeGroupEmoji,
    removeUser,
    addAdmin
};