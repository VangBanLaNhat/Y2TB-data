
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const CACHE_ROOT = path.join(__dirname, 'cache', 'joinnoti');
const DEFAULT_TEXT = 'Chào mừng {name} đến với {threadName}. Bạn là thành viên thứ {count}.';

function ensureExists(dirPath, mask) {
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(dirPath, {
            mode: mask,
            recursive: true
        });
        return;
    } catch (ex) {
        return {
            err: ex
        };
    }
}

function normalizeAdminIDs(adminIDs) {
    if (!Array.isArray(adminIDs)) return [];
    return adminIDs
        .map((item) => (item && typeof item === 'object') ? item.id : item)
        .filter(Boolean)
        .map((id) => String(id));
}

function t(adv, key, map) {
    let text = key;
    try {
        text = adv.rlang(key);
    } catch (_) {
        text = key;
    }

    if (map && adv && typeof adv.replaceMap === 'function') {
        try {
            text = adv.replaceMap(text, map);
        } catch (_) { }
    }

    return text;
}

function getPluginConfig(config) {
    const fallback = {
        enabledByDefault: true,
        defaultMessage: DEFAULT_TEXT,
        sendDefaultTextWhenNoAttachment: true,
        skipBotJoinMessage: true,
        maxAttachmentSizeMB: 25
    };

    if (!config || typeof config !== 'object') return fallback;

    return {
        enabledByDefault: config.enabledByDefault !== false,
        defaultMessage: typeof config.defaultMessage === 'string' && config.defaultMessage.trim()
            ? config.defaultMessage.trim()
            : DEFAULT_TEXT,
        sendDefaultTextWhenNoAttachment: config.sendDefaultTextWhenNoAttachment !== false,
        skipBotJoinMessage: config.skipBotJoinMessage !== false,
        maxAttachmentSizeMB: Number.isFinite(Number(config.maxAttachmentSizeMB))
            ? Number(config.maxAttachmentSizeMB)
            : 25
    };
}

function initStore() {
    if (!global.data.joinnoti || typeof global.data.joinnoti !== 'object') {
        global.data.joinnoti = {};
    }

    if (!global.data.joinnoti.threads || typeof global.data.joinnoti.threads !== 'object') {
        global.data.joinnoti.threads = {};
    }
}

function getThreadState(threadID, config) {
    initStore();
    const cfg = getPluginConfig(config);
    const key = String(threadID);

    if (!global.data.joinnoti.threads[key] || typeof global.data.joinnoti.threads[key] !== 'object') {
        global.data.joinnoti.threads[key] = {
            enabled: cfg.enabledByDefault,
            text: '',
            attachmentPath: '',
            attachmentType: ''
        };
    }

    const state = global.data.joinnoti.threads[key];
    if (typeof state.enabled !== 'boolean') state.enabled = cfg.enabledByDefault;
    if (typeof state.text !== 'string') state.text = '';
    if (typeof state.attachmentPath !== 'string') state.attachmentPath = '';
    if (typeof state.attachmentType !== 'string') state.attachmentType = '';

    return state;
}

async function isThreadAdmin(data, adv) {
    if (Array.isArray(global.config.facebook.admin) && global.config.facebook.admin.indexOf(data.senderID) !== -1) {
        return true;
    }

    try {
        const threadInfo = await adv.getThreadInfo(data.threadID);
        const adminIDs = normalizeAdminIDs(threadInfo && threadInfo.adminIDs);
        return adminIDs.indexOf(String(data.senderID)) !== -1;
    } catch (_) {
        return false;
    }
}

function isGroupMessage(data) {
    if (typeof data.isGroup === 'boolean') return data.isGroup;
    return String(data.threadID) !== String(data.senderID);
}

function getAttachmentExt(attachment) {
    const type = attachment && attachment.type;
    const map = {
        photo: '.jpg',
        animated_image: '.gif',
        video: '.mp4',
        audio: '.mp3',
        sticker: '.png',
        file: '.bin'
    };

    let ext = map[type] || '.bin';

    if (attachment && typeof attachment.filename === 'string') {
        const filenameExt = path.extname(attachment.filename);
        if (filenameExt && filenameExt.length <= 10) {
            ext = filenameExt;
        }
    }

    return ext;
}

function isSupportedAttachment(attachment) {
    if (!attachment || typeof attachment !== 'object') return false;
    if (!attachment.url) return false;
    const allowed = ['photo', 'animated_image', 'video', 'audio', 'sticker', 'file'];
    return allowed.indexOf(attachment.type) !== -1;
}

function resolveAttachmentPath(storedPath) {
    if (!storedPath || typeof storedPath !== 'string') return '';
    if (path.isAbsolute(storedPath)) return storedPath;
    return path.join(__dirname, storedPath);
}

function buildWelcomeText(template, dataMap) {
    let text = String(template || '').trim();
    if (!text) return '';
    for (const key in dataMap) {
        text = text.replaceAll(key, String(dataMap[key]));
    }
    return text;
}

function getAction(data) {
    if (!data || !Array.isArray(data.args)) return '';
    return (data.args[1] || '').toLowerCase();
}

function usageText(prefix) {
    return [
        `${prefix}joinnoti status`,
        `${prefix}joinnoti on/off`,
        `${prefix}joinnoti text <nội dung>`,
        `${prefix}joinnoti resettext`,
        `${prefix}joinnoti attachment (reply ảnh/video/file)`,
        `${prefix}joinnoti clearattachment`
    ].join('\n');
}

async function saveAttachmentFromReply(data, state) {
    const replyAttachments = data && data.messageReply && Array.isArray(data.messageReply.attachments)
        ? data.messageReply.attachments
        : [];
    const attachment = replyAttachments.find(isSupportedAttachment);
    if (!attachment) return null;

    const ext = getAttachmentExt(attachment);
    const threadDir = path.join(CACHE_ROOT, String(data.threadID));
    ensureExists(threadDir);
    const destination = path.join(threadDir, `welcome${ext}`);

    if (state.attachmentPath) {
        const oldPath = resolveAttachmentPath(state.attachmentPath);
        try {
            if (oldPath && fs.existsSync(oldPath) && oldPath !== destination) {
                fs.unlinkSync(oldPath);
            }
        } catch (_) { }
    }

    const response = await axios({
        method: 'get',
        url: attachment.url,
        responseType: 'stream',
        timeout: 120000
    });

    await new Promise((resolve, reject) => {
        const writer = fs.createWriteStream(destination);
        response.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
        response.data.on('error', reject);
    });

    state.attachmentPath = path.relative(__dirname, destination).replace(/\\/g, '/');
    state.attachmentType = attachment.type || '';

    return destination;
}

function buildStatusText(adv, data, state) {
    const prefix = global.config.facebook.prefix;
    const status = state.enabled ? t(adv, 'statusOn') : t(adv, 'statusOff');
    const attachment = state.attachmentPath ? t(adv, 'attachmentSet') : t(adv, 'attachmentUnset');
    const textState = state.text && state.text.trim()
        ? state.text.trim()
        : t(adv, 'defaultTextShort');

    return t(adv, 'statusMessage', {
        '{status}': status,
        '{attachment}': attachment,
        '{text}': textState,
        '{usage}': usageText(prefix),
        '{prefix}': prefix
    });
}

async function main(data, api, adv) {
    try {
        if (!isGroupMessage(data)) {
            return api.sendMessage(t(adv, 'groupOnly'), data.threadID, data.messageID);
        }

        const cfg = getPluginConfig(adv.config);
        const state = getThreadState(data.threadID, cfg);
        const action = getAction(data);

        if (!action || action === 'status' || action === 'help') {
            return api.sendMessage(buildStatusText(adv, data, state), data.threadID, data.messageID);
        }

        const allowedAction = ['on', 'off', 'text', 'resettext', 'attachment', 'update', 'clearattachment', 'removeattachment'];
        if (allowedAction.indexOf(action) === -1) {
            return api.sendMessage(buildStatusText(adv, data, state), data.threadID, data.messageID);
        }

        const hasPermission = await isThreadAdmin(data, adv);
        if (!hasPermission) {
            return api.sendMessage(t(adv, 'noPermission'), data.threadID, data.messageID);
        }

        if (action === 'on') {
            state.enabled = true;
            return api.sendMessage(t(adv, 'turnedOn'), data.threadID, data.messageID);
        }

        if (action === 'off') {
            state.enabled = false;
            return api.sendMessage(t(adv, 'turnedOff'), data.threadID, data.messageID);
        }

        if (action === 'text') {
            const content = data.args.slice(2).join(' ').trim();
            if (!content) {
                return api.sendMessage(t(adv, 'missingText', {
                    '{prefix}': global.config.facebook.prefix
                }), data.threadID, data.messageID);
            }

            state.text = content;
            return api.sendMessage(t(adv, 'textUpdated', { '{text}': content }), data.threadID, data.messageID);
        }

        if (action === 'resettext') {
            state.text = '';
            return api.sendMessage(t(adv, 'textReset'), data.threadID, data.messageID);
        }

        if (action === 'clearattachment' || action === 'removeattachment') {
            if (state.attachmentPath) {
                const attachmentPath = resolveAttachmentPath(state.attachmentPath);
                try {
                    if (attachmentPath && fs.existsSync(attachmentPath)) {
                        fs.unlinkSync(attachmentPath);
                    }
                } catch (_) { }
            }

            state.attachmentPath = '';
            state.attachmentType = '';
            return api.sendMessage(t(adv, 'attachmentCleared'), data.threadID, data.messageID);
        }

        if (action === 'attachment' || action === 'update') {
            if (data.type !== 'message_reply' || !data.messageReply) {
                return api.sendMessage(t(adv, 'replyAttachmentRequired', {
                    '{prefix}': global.config.facebook.prefix
                }), data.threadID, data.messageID);
            }

            if (!Array.isArray(data.messageReply.attachments) || !data.messageReply.attachments.length) {
                return api.sendMessage(t(adv, 'replyAttachmentRequired', {
                    '{prefix}': global.config.facebook.prefix
                }), data.threadID, data.messageID);
            }

            const hasSupported = data.messageReply.attachments.some(isSupportedAttachment);
            if (!hasSupported) {
                return api.sendMessage(t(adv, 'invalidAttachmentType'), data.threadID, data.messageID);
            }

            try {
                const savedPath = await saveAttachmentFromReply(data, state);
                if (!savedPath) {
                    return api.sendMessage(t(adv, 'invalidAttachmentType'), data.threadID, data.messageID);
                }

                return api.sendMessage({
                    body: t(adv, 'attachmentUpdated'),
                    attachment: fs.createReadStream(savedPath)
                }, data.threadID, data.messageID);
            } catch (err) {
                console.error('joinnoti save attachment', err);
                return api.sendMessage(t(adv, 'saveAttachmentFailed'), data.threadID, data.messageID);
            }
        }

        return api.sendMessage(buildStatusText(adv, data, state), data.threadID, data.messageID);
    } catch (error) {
        console.error('joinnoti main', error);
        return api.sendMessage(t(adv, 'unknownError'), data.threadID, data.messageID);
    }
}

async function send(data, api, adv) {
    try {
        if (data.type !== 'event') return;
        if (data.logMessageType !== 'log:subscribe') return;
        if (!data.logMessageData || !Array.isArray(data.logMessageData.addedParticipants)) return;

        const cfg = getPluginConfig(adv.config);
        const state = getThreadState(data.threadID, cfg);
        if (!state.enabled) return;

        const botID = String(api.getCurrentUserID());
        const newMembers = data.logMessageData.addedParticipants.filter((item) => {
            if (!item || !item.userFbId) return false;
            if (cfg.skipBotJoinMessage && String(item.userFbId) === botID) return false;
            return true;
        });

        if (!newMembers.length) return;

        let threadInfo = null;
        try {
            threadInfo = await adv.getThreadInfo(data.threadID);
        } catch (_) { }

        const names = newMembers
            .map((item) => item.fullName || `UID ${item.userFbId}`)
            .join(', ');
        const threadName = (threadInfo && (threadInfo.threadName || threadInfo.name)) || 'nhóm';
        const count =
            (threadInfo && Array.isArray(threadInfo.participantIDs) && threadInfo.participantIDs.length)
            || (Array.isArray(data.participantIDs) ? data.participantIDs.length : 0)
            || '?';

        const template = (state.text && state.text.trim()) || cfg.defaultMessage || DEFAULT_TEXT;
        const welcomeText = buildWelcomeText(template, {
            '{name}': names,
            '{threadName}': threadName,
            '{count}': count
        });

        const payload = {};
        const attachmentPath = resolveAttachmentPath(state.attachmentPath);

        if (attachmentPath && fs.existsSync(attachmentPath)) {
            try {
                const maxBytes = Number(cfg.maxAttachmentSizeMB) > 0
                    ? Number(cfg.maxAttachmentSizeMB) * 1024 * 1024
                    : 0;
                const stat = fs.statSync(attachmentPath);
                if (!maxBytes || stat.size <= maxBytes) {
                    payload.attachment = fs.createReadStream(attachmentPath);
                }
            } catch (err) {
                console.error('joinnoti read attachment', err);
            }
        }

        // Only send text when group has not set attachment.
        if (!payload.attachment && cfg.sendDefaultTextWhenNoAttachment !== false) {
            payload.body = welcomeText;
        }

        if (!payload.attachment && !payload.body) return;

        api.sendMessage(payload, data.threadID, (err) => {
            if (!err) return;
            console.error('joinnoti send', err);

            if (!payload.body && welcomeText) {
                api.sendMessage(welcomeText, data.threadID);
            }
        });
    } catch (error) {
        console.error('joinnoti event', error);
    }
}

module.exports = {
    main,
    send
};
