
/*async function neko(data, api) {
    const akaneko = require('akaneko');
    const path = require("path");
    const streamBuffers = require("stream-buffers");
    
    var fetch = require("node-fetch");
    let link = await akaneko.neko();
    console.log(link);

    var fetchimage = await fetch(link);
    var buffer = await fetchimage.buffer();
    var imagesx = new streamBuffers.ReadableStreamBuffer({
        frequency: 10,
        chunkSize: 1024
    });
    imagesx.path = path.join(__dirname, "cache", "jpgAnime", data.messageID+".jpg");
    imagesx.put(buffer);
    imagesx.stop();

    api.sendMessage({ attachment: [imagesx] }, data.threadID, data.messageID);
}*/

async function main(data, api){
    const path = require("path");
    const streamBuffers = require("stream-buffers");
    const fetch = require("node-fetch");
    const random = require("random");
    const Api = "https://raw.githubusercontent.com/HerokeyVN/API_Date/main/18plus.json";
    ensureExists(path.join(__dirname, "cache", "nude"));
    
    let json = await fetch(Api);
    json = await json.json();
    
    let link = json[random.int(0, json.length-1)];
    
    let imagesx = new streamBuffers.ReadableStreamBuffer({
        frequency: 10,
        chunkSize: 1024
    });
    imagesx.path = path.join(__dirname, "cache", "nude", data.messageID+".jpg");
    try {
        var fetchimage = await fetch(link);
        var buffer = await fetchimage.buffer();
        imagesx.put(buffer);
    } catch (_) {
        return 0;
    }
    
    imagesx.stop();

    api.sendMessage({ attachment: [imagesx] }, data.threadID, data.messageID).catch(error => {
        api.sendMessage(error.message, data.threadID, data.messageID)
        console.error(error.message);
    });;
}

function ensureExists(path, mask) {
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(path, {
            mode: mask,
            recursive: true
        });
        return;
    } catch (ex) {
        return {
            err: ex
        };
    }
}

module.exports = {
    main,
};
