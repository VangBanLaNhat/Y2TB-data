let autoRestartTimer = null;
const MIN_AUTORESTART_MINUTES = 31;
const DEFAULT_RANDOM_MAX_MINUTES = 120;

function getRandomAutorestartMinutes(maxMinutes = DEFAULT_RANDOM_MAX_MINUTES) {
    const safeMax = Math.max(MIN_AUTORESTART_MINUTES, Math.floor(Number(maxMinutes) || DEFAULT_RANDOM_MAX_MINUTES));
    return Math.floor(Math.random() * (safeMax - MIN_AUTORESTART_MINUTES + 1)) + MIN_AUTORESTART_MINUTES;
}

function resolveAutorestartState() {
    if (global.data.autorestart === undefined && global.data.autorestartMode === undefined) {
        global.data.autorestartMode = "random";
        global.data.autorestartRandomMax = DEFAULT_RANDOM_MAX_MINUTES;
    }

    if (global.data.autorestartMode === "random") {
        const minutes = getRandomAutorestartMinutes(global.data.autorestartRandomMax);
        global.data.autorestart = minutes;
        if (!Number.isFinite(global.data.autorestartRandomMax) || global.data.autorestartRandomMax < MIN_AUTORESTART_MINUTES) {
            global.data.autorestartRandomMax = DEFAULT_RANDOM_MAX_MINUTES;
        }
        return {
            mode: "random",
            minutes,
            maxMinutes: global.data.autorestartRandomMax
        };
    }

    return {
        mode: "fixed",
        minutes: Number(global.data.autorestart)
    };
}

function getLangText(pluginName, key, code, fallback) {
    try {
        const pluginLang = global.lang && global.lang[pluginName];
        if (!pluginLang || !pluginLang[key]) return fallback;
        return (
            pluginLang[key][code] ||
            pluginLang[key].vi_VN ||
            pluginLang[key].en_US ||
            fallback
        );
    } catch (_) {
        return fallback;
    }
}

function getAdvLangText(adv, key, fallback) {
    return getLangText(
        adv.pluginName,
        key,
        adv.iso639 || global.config?.bot_info?.lang || "en_US",
        fallback
    );
}

function onload(info){
    const state = resolveAutorestartState();
    const minutes = Number(state.minutes);
    if (!Number.isFinite(minutes) || minutes <= 0) return;

    if (autoRestartTimer) clearTimeout(autoRestartTimer);

    const code = global.config?.bot_info?.lang || "en_US";
    const cmd = Object.keys(info.commandList || {})[0] || "autorestart";
    const cmdHelp = info.commandList?.[cmd]?.help?.[code]
        || info.commandList?.[cmd]?.help?.vi_VN
        || info.commandList?.[cmd]?.help?.en_US
        || "";
    const cmdUsage = `${global.config?.facebook?.prefix || ""}${cmd}${cmdHelp ? ` ${cmdHelp}` : ""}`;

    const timeoutTemplate = getLangText(
        info.pluginName,
        "timeout",
        code,
        "Will restart in {0} minutes. To edit auto-reboot time, use \"{1}\""
    );
    const timeoutRandomTemplate = getLangText(
        info.pluginName,
        "timeoutRandom",
        code,
        "Random mode selected {0} minutes for this boot (range {2}-{3} minutes). To edit auto-reboot time, use \"{1}\""
    );
    const rebootMessage = getLangText(info.pluginName, "reboot", code, "Start Reboot!");
    const timeoutMessage = state.mode === "random" ? timeoutRandomTemplate : timeoutTemplate;

    console.warn(
        info.pluginName,
        String(timeoutMessage)
            .replaceAll("{0}", String(minutes))
            .replaceAll("{1}", cmdUsage)
            .replaceAll("{2}", String(MIN_AUTORESTART_MINUTES))
            .replaceAll("{3}", String(state.maxMinutes || DEFAULT_RANDOM_MAX_MINUTES))
    );

    autoRestartTimer = setTimeout(() => {
        console.warn(info.pluginName, rebootMessage);
        process.exit(7378278);
    }, minutes * 60 * 1000);
}

function main(data, api, e2ee, adv){
    let {rlang, replaceMap} = adv;
    
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) return adv.reply(rlang("noPermission"));

    const modeArg = String(data.args[1] || "").toLowerCase();
    if (modeArg === "random") {
        const requestedMax = data.args[2] === undefined ? DEFAULT_RANDOM_MAX_MINUTES : Number(data.args[2]);
        if (!Number.isFinite(requestedMax) || requestedMax < MIN_AUTORESTART_MINUTES) {
            return adv.reply(replaceMap(getAdvLangText(
                adv,
                "settingErrRandom",
                "Random mode syntax: autorestart random [max]. Max must be at least {0} minutes. If omitted, default max is {1} minutes."
            ), {
                "{0}": MIN_AUTORESTART_MINUTES,
                "{1}": DEFAULT_RANDOM_MAX_MINUTES
            }));
        }

        global.data.autorestartMode = "random";
        global.data.autorestartRandomMax = Math.floor(requestedMax);
        global.data.autorestart = getRandomAutorestartMinutes(global.data.autorestartRandomMax);

        return adv.reply(replaceMap(getAdvLangText(
            adv,
            "settingRandom",
            "Enabled random auto-restart mode. On each boot, the bot will pick a random restart time from {0} to {1} minutes."
        ), {
            "{0}": MIN_AUTORESTART_MINUTES,
            "{1}": global.data.autorestartRandomMax
        }));
    }

    let time = Number(data.args[1]);
    if(!Number.isFinite(time) || time < 0 || (time !== 0 && time < 5)) return adv.reply(rlang("settingErr"));

    global.data.autorestartMode = "fixed";
    delete global.data.autorestartRandomMax;
    global.data.autorestart = time;

    if(time == 0) return adv.reply(rlang("off"));

    let map = {
        "{0}": time
    }
    adv.reply(replaceMap(rlang("setting"), map));
}

function restart(data, api, e2ee, adv){
    let {rlang} = adv;
    
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) return adv.reply(rlang("noPermission"));
    global.data.restart = {
    	threadID: data.threadID,
    	senderID: data.senderID,
    	messageID: data.messageID
    }
    
    process.exit(7378278);
}

function login(api, adv){
	if(!global.data.restart) return;
	
	
    let {rlang, replaceMap} = adv;
    
	if(!global.temp.loadPlugin.stderr){
		console.log(rlang("restarted"));
		adv.reply(rlang("restarted"));
		return delete global.data.restart;
	}
	
	let str = "";
	
	for(let i of global.temp.loadPlugin.stderr)
		str += "\n\""+i.plugin+"\": "+i.error;
	
    //console.log(replaceMap(rlang(restartedErr), {"{0}": str}));
	adv.reply(replaceMap(rlang("restartedErr"), {"{0}": str}));
	delete global.data.restart;
}

module.exports = {
    onload,
    main,
    restart,
    login,
};
