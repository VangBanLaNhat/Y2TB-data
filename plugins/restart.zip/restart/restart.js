
let autoRestartTimer = null;

function getLangText(pluginName, key, code, fallback) {
    try {
        const pluginLang = global.lang && global.lang[pluginName];
        if (!pluginLang || !pluginLang[key]) return fallback;
        return (
            pluginLang[key][code] ||
            pluginLang[key].vi_VN ||
            pluginLang[key].en_US ||
            fallback
        );
    } catch (_) {
        return fallback;
    }
}

function onload(info){
    const config = 60;
    if (global.data.autorestart === undefined) global.data.autorestart = config;

    const minutes = Number(global.data.autorestart);
    if (!Number.isFinite(minutes) || minutes <= 0) return;

    if (autoRestartTimer) clearTimeout(autoRestartTimer);

    const code = global.config?.bot_info?.lang || "en_US";
    const cmd = Object.keys(info.commandList || {})[0] || "autorestart";
    const cmdHelp = info.commandList?.[cmd]?.help?.[code]
        || info.commandList?.[cmd]?.help?.vi_VN
        || info.commandList?.[cmd]?.help?.en_US
        || "";
    const cmdUsage = `${global.config?.facebook?.prefix || ""}${cmd}${cmdHelp ? ` ${cmdHelp}` : ""}`;

    const timeoutTemplate = getLangText(
        info.pluginName,
        "timeout",
        code,
        "Will restart in {0} minutes. To edit auto-reboot time, use \"{1}\""
    );
    const rebootMessage = getLangText(info.pluginName, "reboot", code, "Start Reboot!");

    console.warn(
        info.pluginName,
        String(timeoutTemplate)
            .replaceAll("{0}", String(minutes))
            .replaceAll("{1}", cmdUsage)
    );

    autoRestartTimer = setTimeout(() => {
        console.warn(info.pluginName, rebootMessage);
        process.exit(7378278);
    }, minutes * 60 * 1000);
}

function main(data, api, adv){
    let {rlang, replaceMap} = adv;
    
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) return api.sendMessage(rlang("noPermission"), data.threadID, data.messageID);
    
    let time = Number(data.args[1]);
    if(!Number.isFinite(time) || time < 0 || (time !== 0 && time < 5)) return api.sendMessage(rlang("settingErr"), data.threadID, data.messageID);
    
    global.data.autorestart = time;
    
    if(time == 0) return api.sendMessage(rlang("off"), data.threadID, data.messageID);
    
    let map = {
        "{0}": time
    }
    api.sendMessage(replaceMap(rlang("setting"), map), data.threadID, data.messageID);
}

function restart(data, api, adv){
    let {rlang} = adv;
    
    if(global.config.facebook.admin.indexOf(data.senderID) == -1) return api.sendMessage(rlang("noPermission"), data.threadID, data.messageID);
    global.data.restart = {
    	threadID: data.threadID,
    	senderID: data.senderID,
    	messageID: data.messageID
    }
    
    process.exit(7378278);
}

function login(api, adv){
	if(!global.data.restart) return;
	
	
    let {rlang, replaceMap} = adv;
    
	if(!global.temp.loadPlugin.stderr){
		console.log(rlang("restarted"));
		api.sendMessage(rlang("restarted"), global.data.restart.threadID, global.data.restart.messageID);
		return delete global.data.restart;
	}
	
	let str = "";
	
	for(let i of global.temp.loadPlugin.stderr)
		str += "\n\""+i.plugin+"\": "+i.error;
	
    //console.log(replaceMap(rlang(restartedErr), {"{0}": str}));
	api.sendMessage(replaceMap(rlang("restartedErr"), {"{0}": str}), global.data.restart.threadID, global.data.restart.messageID);
	delete global.data.restart;
}

module.exports = {
    onload,
    main,
    restart,
    login,
};
